#include <cstdio>
 #include <cstring>
 #include <algorithm>
 
 #define FOR(x, n) for(int x = 0; x < n; x++)
 
 using namespace std;
 
 int DP[500][500];
 
 int main() {
 	int T, D, I, M, N, a, ans, nCase = 1;
 	
 	scanf("%d\n", &T);
 	
 	while(T--) {
 		scanf("%d %d %d %d\n", &D, &I, &M, &N);
 		
 		memset(DP, -1, sizeof(DP));
 		memset(DP[0], 0, sizeof(DP[0]));
 		
 		FOR(i, N) {
 			scanf("%d", &a);
 			
 			FOR(prev, 256) {
 				// delete case
 				if(DP[i+1][prev] == -1 || DP[i+1][prev] > DP[i][prev] + D)
 					DP[i+1][prev] = DP[i][prev] + D;
 					
 				if(M) {
 					// prepernd case
 					if(DP[i+1][a] == -1 || DP[i+1][a] > DP[i][prev] + I * ((abs(prev - a)-1)/M))
 						DP[i+1][a] = DP[i][prev] + I * ((abs(prev - a)-1)/M);
 				}
 				
 				FOR(curr, 256) {
 					// edit case
 					if(abs(curr - prev) > M) continue;
 					
 					if(DP[i+1][curr] == -1 || DP[i+1][curr] > DP[i][prev] + abs(a - curr))
 						DP[i+1][curr] = DP[i][prev] + abs(a - curr);
 				}
 			}
 		}
 		
 		ans = 1 << 30;
 		
 		FOR(i, 256) {
 			if(DP[N][i] > -1)
 				ans = min(ans, DP[N][i]);
 		}
 		
 		printf("Case #%d: %d\n", nCase++, ans);
 	}
 }
