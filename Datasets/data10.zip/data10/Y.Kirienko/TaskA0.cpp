#include <fstream>
 using namespace std;
 ifstream fin("a-small.in");
 ofstream fout("a-small.out");
 bool proverka(int A1, int B1, int A2, int B2)
 {
 	if(A1<A2 && B1>B2)
 		return true;
 	if(A1>A2 && B1<B2)
 		return true;
 	return false;
 }
 int main()
 {
 	int T, i, e, j, R;
 	fin>>T;
 	for(i=0;i<T;++i)
 	{
 		R = 0;
 		int N;
 		fin>>N;
 		int* A = new int[N];
 		int* B = new int[N];
 		for(e = 0;e<N;++e)
 			fin>>A[e]>>B[e];
 		for(e=0;e<N-1;++e)
 			for(j=e+1;j<N;++j)
 				if(proverka(A[e], B[e], A[j], B[j]))
 					R++;
 		delete[] A;
 		delete[] B;
 		fout<<"Case #"<<i+1<<": "<<R<<endl;
 	}
 	return 0;
 }