#include <iostream>
 #include <vector>
 #include <map>
 #include <set>
 #include <algorithm>
 #include <cmath>
 #include <sstream>
 #include <cstdio>
 #include <cstdlib>
 #include <cstring>
 #include <memory>
 #define sz size()
 #define mp make_pair
 #define pb push_back
 #define vi vector<int>
 #define fu(i,n) for(int i=0; i<(n); i++)
 #define ALL(a) (a).begin(),(a).end()
 #define cl(a,co) memset(a,co,sizeof a)
 #define un(a) sort(ALL(a)),a.erase( unique(ALL(a)), a.end() )
 typedef long long ll;
 //istringstream is(s); is >> a;
 
 using namespace std;
 
 int ileTestow;
 
 int main(){
 
 	scanf("%d",&ileTestow);
 
 	for(int q=1; q<=ileTestow; q++){
 		printf("Case #%d: ",q);
 		
 		int n,k;
 		scanf("%d%d",&n,&k);
 		
 		ll pot = 1;
 		while( n-- ) pot *= 2;				
 				
 		if( k % pot == pot-1 ) printf("ON\n");
 		else printf("OFF\n");
 	}
 
 	return 0;
 }
