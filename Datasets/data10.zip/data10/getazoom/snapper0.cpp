//============================================================================
 // Name        : test.cpp
 // Author      : gunjesh
 // Version     :
 // Copyright   : Your copyright notice
 // Description : Hello World in C++, Ansi-style
 //============================================================================
 
 #include <iostream>
 #include <vector>
 #include <map>
 using namespace std;
 
 int main() {
 	//read input from file...
 	int noOfSnappers;
 	int noOfClick;
 	int noOfTest;
 	bool bulb = false;
 	cin >> noOfTest;
 	for(int i=0; i < noOfTest; i++)
 	{
 		bulb=false;
 //		int index = 0;
 		cin >> noOfSnappers>> noOfClick;
 		bool status[noOfSnappers+2][2];
 //		for(int k = 0 ; k <= noOfSnappers+1 ; k++)
 	//		cout << k << "init : state = " << status[k][0] << " power =" << status[k][1] <<endl;
 
 		for(int ii=0; ii < noOfSnappers+2;ii++)
 		{
 			status[ii][0]=false;
 			status[ii][1]=false;
 		}
 //		for(int k = 0 ; k <= noOfSnappers+1 ; k++)
 	//						cout << k << "initeeeed tate = " << status[k][0] << " power =" << status[k][1] <<endl;
 
 		status[0][0]=true;
 		status[0][1]=true;
 		for(int j = 0 ; j < noOfClick ; j++)
 		{
 			//update status for each click.
 			//int last = 0;
 			for(int k = 1; k <= noOfSnappers+1;k++)
 			{
 				if(status[k-1][1])
 		 		{//toggle k state
 					if(status[k][0])
 						status[k][0]=false;
 					else
 						status[k][0]=true;
 				}
 				else
 				{
 //					last = k;
 
 					break;
 				}
 			}
 	//		for(int k = 0 ; k <= noOfSnappers+1 ; k++)
 		//				cout << k << "BEFORE : state = " << status[k][0] << " power =" << status[k][1] <<endl;
 
 			//cout <<  "last :" << last <<endl;
 
 
 			for(int k = 0; k <= noOfSnappers;k++)
 			{
 
 				if(status[k][0])
 				{//toggle k state
 					status[k][1] = true;
 				}
 				else
 				{
 					for(int l =k;l <= noOfSnappers;l++)
 						status[l][1]=false;
 					break;
 				}
 			}
 
 //			for(int k = 0 ; k <= noOfSnappers+1 ; k++)
 	//					cout << k << "AFTER : state = " << status[k][0] << " power =" << status[k][1] <<endl;
 
 		}
 //		for(int k = 0 ; k <= noOfSnappers+1 ; k++)
 	//		cout << k << ": state = " << status[k][0] << " power =" << status[k][1] <<endl;
 
 	//	cout <<  status[noOfSnappers][0] ;
 	//	cout <<status[noOfSnappers][1];
 	//	cout << status[noOfSnappers][0] & status[noOfSnappers][1];
 	//	cout << status[noOfSnappers][0] && status[noOfSnappers][1];
 		bulb = status[noOfSnappers][0] && status[noOfSnappers][1];
 		//Resolution
 
 
 
 		//output to file
 		cout <<"Case #" << i+1 <<": ";
 		if(bulb)
 			cout << "ON" << endl;
 		else
 			cout << "OFF" << endl;
 
 	}
 
 	return 0;
 
 
 }
