﻿// try.cpp : Defines the entry point for the console application.
 //
 
 #pragma warning (disable:4996)
 #include "stdafx.h"
 
 #include<stdio.h>
 #include<iostream>
 #include <string>
 #include<vector>
 #include <algorithm>
 using namespace std;
 int main()
 {
 	freopen("D-small-attempt0.in", "r", stdin);
 	freopen("D_small_out.txt", "w", stdout);
 
 
 	int tk, tk1 = 0;
 	cin >> tk;
 	while (tk--)
 	{
 		tk1++;
 		int x,r,c;
 		cin >> x >> r >> c;
 		string ans;
 		if (x >= 4)
 		{
 			ans = "RICHARD";
 		}
 		else if (x == 1){
 			ans = "GABRIEL";
 		}
 		else if (x == 2)
 		{
 			if ((r*c) % 2 == 0)
 			{
 				ans = "GABRIEL";
 			}
 			else {
 				ans = "RICHARD";
 			}
 		}
 		else {
 			if ((r % 3 == 0 && c % 2 == 0) || (r % 2 == 0 && c % 3 == 0))
 			{
 				ans = "GABRIEL";
 			}
 			else {
 				ans = "RICHARD";
 			}
 		}
 		cout << "Case #" << tk1 << ": " << ans << endl;
 	}
 	return 0;
 }