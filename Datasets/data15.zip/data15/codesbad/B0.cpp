#include <bits/stdc++.h>
 using namespace std;
 
 int K, L, S;
 string s1, s2;
 vector<string> sols;
 
 void doit(int depth,string s) {
 	//cout << s << endl;
 	if (depth == S) {
 		sols.push_back(s);
 		return ;
 	}
 	//cout << s << endl;
 	for(int i=0;i<K;i++)
 		doit(depth+1, s+s1[i]);
 }
 int tot=0;
 int getMax() {
 	int mx=0;
 	tot = 0;
 	for(int i=0;i<sols.size();i++) {
 
 		int place = -1;
 		int nTimes =0;
 		while ((place = sols[i].find(s2,place+1))!=std::string::npos) {
 			nTimes++;
 
 		}
 		//cout << sols[i] << " " << nTimes<<endl;
 		mx=max(mx,nTimes);
 		tot+=nTimes;
 	}
 	return mx;
 }
 
 
 int main() {
 	int T; cin >> T;
 	for(int caseNum=1; caseNum<=T; caseNum++) {
 		cin >> K >> L >> S;
 		cin >> s1 >> s2;
 		sols.clear();
 		//map<char,int>s1Map, s2Map;
 		//for(auto &x:s1) s1Map[x]++;
 		//for(auto &x:s2) s2Map[x]++;
 		doit(0,"");
 		//cout << "done " << endl;
 		int mx = getMax();
 		int nvalid = tot;
 
 		double ans = mx-(nvalid+0.)/sols.size();
 		cout << "Case #"<<caseNum<<": " << ans << endl;
 	}
 	return 0;
 }