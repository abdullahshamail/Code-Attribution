#include<stdio.h>
 #include<vector>
 #include<bitset>
 #include<utility>
 #include<string>
 #include<string.h>
 #include<algorithm>
 #include<set>
 #include<map>
 #include<math.h>
 #include<iostream>
 #include<conio.h>
 using namespace std;
 
 #define max(a,b) (a>=b?a:b)
 #define min(a,b) (a<=b?a:b)
 #define all(X) (X.begin(),X.end())
 #define allr(X) (X.rbegin(),X.rend())
 #define mp make_pair
 #define pb push_back
 #define disp(X,Y) for(int ab=0;ab<Y;ab++){cout<<X[ab]<<" ";}cout<<endl<<endl;
 
 long long t=1,tests,i,j,L,tim,N,C,sum,curr,total,k;
 vector<long long> cval,a,sm;
 
 int main()
 {
     freopen("B-small-attempt2.in","r",stdin);
     freopen("B-small-2.out","w",stdout);
     cin>>tests;
     while(t<=tests)
     {
          cin>>L>>tim>>N>>C;         
          cval.clear();
          a.clear();
          for(i=0;i<C;i++)
          {
               long long temp;
               cin>>temp;
               cval.pb(temp);
          }
          j=0;         
          for(i=0;i<N;i++)
          {
              a.pb(cval[j]);
              j=(j+1)%C;
          }
          //disp(a,N);
          sum=0;
          curr=0;
          i=0;
          while(sum<tim)
          {
               sum+=a[i]*2;
               i++;
               curr=i;
          }   
          total=0;  
          j=0;
          sm.clear();
          for(k=curr;k<N;k++)
          {
              sm.pb(a[k]);
          }
          sort(sm.rbegin(),sm.rend());
          //cout<<sm[0]<<" "<<tim-(sum-a[i-1]*2)<<endl;
          if(L>0)
          {
          if(sum!=tim && ((N-curr<=L) || (!((a[i-1]-(tim-(sum-a[i-1]*2)))<sm[N-curr-1]))) )
          {    
               i--;                      
               sum-=a[i]*2;              
               total+=a[i]-(tim-sum)/2;
               sum+=(tim-sum);
               j++;
          }    
          }    
          total+=sum;      
          //disp(sm,N-curr);    
          for(i=0;i<N-curr && j<L;i++,j++)
          {
              total+=sm[i];
          }
          if(i<N-curr)
          {
              for(;i<N-curr;i++)
              {
                   total+=sm[i]*2;
              }
          }   
          printf("Case #");   
          cout<<t<<": "<<total<<endl;
                    
          t++;
     }
     getch();
 }
