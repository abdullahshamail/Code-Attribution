#include <string.h>
 #include <iostream>
 #include <fstream>
 #include <iomanip>
 #define MaxNum 2000
 #define SliptChar " "
 using namespace std;
 int main(int argc,char *argv[])
 {
 	char case_str[MaxNum]={0};	
 	int total_test_case = 0;
 	char* input_file = "..\\request.txt";
 	fstream fs (input_file,ios::in);
 	fstream fso ("..\\output.txt",ios::out);
 	if (!fs)
 	{
 		cout<<"ȡļ"<<endl;
 		return 0;
 	}
 	fs.getline(case_str,MaxNum);
 	total_test_case = atoi(case_str);
 	for(int i = 1 ; i<=total_test_case ;i++)
 	{
 		int total_num = 0;
 		int tmp_num= 0;
 		double swap_count = 0.0000001;
 		char* p;
 		fs.getline(case_str,MaxNum);
 		total_num = atoi(case_str);
 		int* num_arr = new int[total_num];
 		fs.getline(case_str,MaxNum);
 		p = strtok(case_str,SliptChar);
 		for(int j = 0 ; j< total_num ; j++)
 		{
 			num_arr[j]= atoi(p);
 			p = strtok(NULL,SliptChar);
 		}
 		//ð
 		for(int k = total_num; k > 1 ; k--)
 		{
 			for(int j=0 ; j< (k-1) ; j++)
 			{
 				if(num_arr[j]>num_arr[j+1])
 				{
 					tmp_num = num_arr[j];
 					num_arr[j] = num_arr[j+1];
 					num_arr[j+1] = tmp_num;
 					swap_count = swap_count + 1.0;
 				}
 			}
 
 		}
 		delete num_arr;
 		float swap_count_f = swap_count * 2.000000 ;
 
 		fso<<"Case #"<<i<<": "<<setiosflags(ios::fixed)<<setprecision(6)<<(swap_count*2)<<endl;
 		cout<<"Case #"<<i<<": "<<setiosflags(ios::fixed)<<setprecision(6)<<(swap_count*2)<<endl;
 	}
 	int a;
 	cin>>a;
 	return 0;
 }