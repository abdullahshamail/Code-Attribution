#include <iostream>
 #include <vector>
 #include <stdio.h>
 #include <string>
 #include <cmath>
 #include <algorithm>
 #include <set>
 
 using namespace std;
 
 struct tt
 {
 	int x, y;
 };
 
 
 int main()
 {
 	freopen("A-small.in", "r", stdin);
 	freopen("A-small.out", "w", stdout);
 	int r;
 	cin >> r;
 	for (int y = 1; y <= r; y++)
 	{
 		int p, k, l;
 		cin >> p >> k >> l;
 		vector<int> v(l);
 		for (int i = 0; i < l; i++)
 			cin >> v[i];
 		sort(v.begin(), v.end());
 		int cnt = 0;
 		int j = 0;
 		int t = 1;
 		for (int i = l-1; i >= 0; i--)
 		{
 			if (j == k)
 			{
 				t++;
 				j = 0;
 			}
 			cnt += v[i] * t;
 			j++;
 		}
 
 		cout << "Case #" << y << ": " << cnt << endl;
 	}
 	return 0;
 }
 
