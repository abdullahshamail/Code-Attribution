#include <iostream>
 #include <cstdio>
 #include <algorithm>
 #define MAXM 10000
 using namespace std;
 
 int n, m[MAXM];
 
 int solveA() {
 	int res = 0;
 
 	for(int i = 0; i < n-1; i++)
 		if(m[i] - m[i+1] >= 0) res += m[i] - m[i+1];
 
 	return res;
 }
 
 int solveB() {
 	if(n == 2) return max(m[0] - m[1], 0);
 
 	int rate = m[n-2] - m[n-1];
 	int res = 0;
 
 	for(int i = 0; i < n-1; i++) {
 		res += max(min(rate, m[i]), 0);
 	}
 
 	return res;
 }
 
 int main() {
 	int tc;
 	scanf("%d", &tc);
 
 	for(int t = 1; t <= tc; t++) {
 		scanf("%d", &n);
 		for(int i = 0; i < n; i++) scanf("%d", &m[i]);
 
 		printf("Case #%d: %d %d\n", t, solveA(), solveB());
 	}
 
 	return 0;
 }
 
 
 
 
