#include <algorithm>
 #include <cassert>
 #include <cctype>
 #include <cmath>
 #include <cstdio>
 #include <cstdlib>
 #include <cstring>
 #include <ctime>
 #include <deque>
 #include <functional>
 #include <iomanip>
 #include <iostream>
 #include <map>
 #include <numeric>
 #include <queue>
 #include <set>
 #include <sstream>
 #include <stack>
 #include <string>
 #include <utility>
 #include <vector>
 
 using namespace std;
 
 const int M = 10000+5;
 double cache[M][M];
 bool seen[M][M];
 double f(int a, int n) {
   if (a == 0 && n == 0) return 1;
   if (a == 0) return 1;
   if (a > n) return 0;
   if (!seen[a][n]) {
     seen[a][n] = true;
     double r = f(a, n-1)*0.5;
     double b = f(a-1, n-1)*0.5;
     cache[a][n] = (r + b);
   }
   return cache[a][n];
 }
 
 void solve() {
   int n, x, y;
   scanf("%d%d%d", &n, &x, &y);
   int r = 0;
   int a = 0;
   int inc = 0;
   while ((abs(x)+abs(y))/2 > r) {
     a += (inc+inc+1);
     if (n < a) {
       printf("0.0\n");
       return;
     }
     inc += 2;
     r++;
   }
   if (n >= (a+inc+inc+1)) {
     printf("1.0\n");
     return;
   }
   if (x == 0) {
     if (n == a+inc+inc+1) {
       printf("1.0\n");
     } else {
       printf("0.0\n");
     }
     return;
   }
   int left = n - a;
   double P = 1;
   for (int i = 0; i < left; i++) {
     P *= 0.5;
   }
   printf("%.9lf\n", f(y+1, left));
 }
 
 int main() {
   int T;
   scanf("%d", &T);
   for (int i = 1; i <= T; i++) {
     printf("Case #%d: ", i);
     solve();
   }
   return 0;
 }
 
