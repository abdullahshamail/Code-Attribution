#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define TAM 1024
 
 int main(){
   int nt;
   int R,k,n;
   int peso[TAM];
 
   scanf("%d",&nt);
   for(int t = 1 ; t <= nt;t++){
     scanf("%d %d %d",&R,&k,&n);
 
     for(int i = 0 ; i < n;i++)
       scanf("%d",&peso[i]);
 
     printf("Case #%d: ",t);
     
     int ans = 0;
     int id = 0;
     for(int i = 0 ; i < R;i++){
       int parcial = 0;
       int j = 0;
       while(j<n && parcial + peso[id] <= k){
 	parcial += peso[id];
 	//printf("%d ",peso[id]);
 	ans += peso[id];
 	id = (id + 1)%n;
 	j++;
       }
       //printf("\n");
     }
     printf("%d\n",ans);
   }
   return 0;
 }
