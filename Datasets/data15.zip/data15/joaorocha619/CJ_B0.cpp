#include <iostream>
 #include <stdio.h>
 #include <math.h>
 #include <set>
 
 using namespace std;
 
 int Mp(int n, int k) {
     return int(ceil((float)n/k));
 }
 
 int m(int n) {
     return int(floor(sqrt(n))) ;
 }
 
 multiset<int> diners;
 
 int check(int j, multiset<int>::reverse_iterator it){
     int part=Mp(*it,j);
     int ma=part;
     int macs=*it;
     multiset<int>::reverse_iterator it2=it;
     for (multiset<int>::reverse_iterator it1=++it2;it1!=diners.rend();++it1) {
                 int l=1;
                 while(Mp(*it1,l)>part) {
                     macs=min(macs,check(l,it1)+j-1);
                     l++;
                 }
                 ma+=l-1;
     }
     return min(ma+j-1,macs);
 }
 
 int main() {
     int T;
     scanf("%d",&T);
     for (int i=1; i<=T; i++) {
         diners.clear();
         int D;
         scanf("%d",&D);
         for (int j=0; j<D; j++) {
             int d;
             scanf("%d",&d);
             diners.insert(d);
         }
         int beg=*(--diners.end());
         int ma=beg;
         if (diners.size()==1) {
             printf("Case #%d: %d \n",i,Mp(beg,m(beg))+m(beg)-1);
             continue;
         }
         for(int j=1; j<=m(beg);j++) {
             int k=check(j,diners.rbegin());
             if (k<ma) {
                 ma=k;
             }
         }
         printf("Case #%d: %d \n",i,ma);
     }
     return 0;
 }
