#include <iostream>
 
 using	namespace	std;
 
 static const int maxn = 500;
 
 int	c[maxn + 1][maxn + 1];
 int	f[maxn + 1][maxn + 1];
 
 void	init()
 {
 	c[0][0] = 1;
 	c[1][0] = c[1][1] = 1;
 	for (int m = 2; m <= maxn; ++m)
 	{
 		c[m][0] = 1;
 		for (int n = 1; n <= m; ++n)
 			c[m][n] = (c[m][n - 1] + c[m - 1][n - 1]) % 100003;
 	}
 
 	f[2][1] = 1; // 2
 
 	// 3
 	// 2 3
 	//
 	// 4
 	// 2 4
 	// 2 3 4
 	//
 	// 5
 	// 2 5
 	// 3 4 5
 	// 2 3 5
 	// 2 3 4 5
 	for (int i = 3; i <= maxn; ++i)
 	{
 		f[i][1] = 1;
 		for (int j = 2; j <= i - 1; ++j)
 		{
 			f[i][j] = 0;
 			for (int k = 1; k <= j - 1; ++k)
 			{
 				int	a = i - j - 1;
 				int	b = j - k - 1;
 				if (b > a)	continue;
 				f[i][j] += f[j][k] * c[a][b] % 100003;
 				f[i][j] %= 100003;
 			}
 		}
 	}
 }
 
 void	solve()
 {
 	int	n;
 	cin >> n;
 	int	ans = 0;
 	for (int i = 1; i < n; ++i)
 		ans = (ans + f[n][i]) % 100003;
 	cout << ans << endl;
 }
 
 int	main()
 {
 	init();
 	int	t;
 	cin >> t;
 	for (int i = 1; i <= t; ++i)
 	{
 		cout << "Case #" << i << ": ";
 		solve();
 	}
 	return	0;
 }
 
