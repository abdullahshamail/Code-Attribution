#include <fstream>
 #include <iostream>
 #include<cassert>
 #include<cmath>
 #include<limits>
 #include<sstream>
 #include<string>
 using namespace std;
 
 string reverse(string str)
 {
 	int i=0,j=0,num=0;
 	string tmp=str;
 	num=str.length();
 	for (i=num-1;i>=0;i--)
 	{
 		str.at(j)=tmp.at(i);
 		j++;
 	}
 	return str;
 }
 
 string searchcstr(string s,string dst,int n)
 {
 	int start1,start2;
 	string ins=s.substr(2,1);
 	string finds=s.substr(0,2);
 	string revs=reverse(finds);
 	start1=dst.find(finds);
 	start2=dst.rfind(revs);
 	
 	if (start1!=string::npos && start2!=string::npos)
 	{
 		if (start1>=start2)
 		{
 			dst.erase(start2,2);
 			//start2-=1;
 			dst.insert(start2,ins);
 
 		}
 		else
 		{
 			dst.erase(start1,2);
 			//start1-=1;
 			dst.insert(start1,ins);
 
 		}
 		
 		
 	}
 	else if (start1!=string::npos)
 	{
 		dst.erase(start1,2);
 		//start1-=1;
 		dst.insert(start1,ins);
 		
 		
 	}
 	else if (start2!=string::npos)
 	{
 		dst.erase(start2,2);
 		//start2-=1;
 		dst.insert(start2,ins);
 
 
 	}
 	
 //	string revs(finds.end(),finds.begin());
 	
 //	start2=dst.find(finds);
 	
 	return dst;
 
 /*
 	
 	if ((s[0]==dst[n-1]&&s[1]=dst[n-2])||(s[0]=dst[n-2]&&s[1]=dst[n-1]))
 	{
 		dst[n-2]=s[2];
 		dst[n-1]='\0';
 		
 	}
 */	
 	
 		
 	
 
 }
 
 string searchdstr(string s,string dst,int n)
 {
 	int pos1=0,pos2=0,i,num;
 	pos1=dst.find(s.at(0));
 	pos2=dst.find(s.at(1));
 
 	if(pos1==string::npos||pos2==string::npos)
 	{
 		return dst;
 	}
 	else if(pos1>=pos2)
 	{
 		num=pos1-pos2;
 		dst.erase(pos2,num+1);
 	}
 	else if(pos1<pos2)
 	{
 		num=pos2-pos1;
 		dst.erase(pos1,num+1);
 	}
 	return dst;
 	/*
 	while(s[0]!=dst[pos1] &&pos1<n)
 	{
 		pos1++;
 		
 	}
 	while(s[1]!=dst[pos2] &&pos2<n)
 	{
 		pos2++;
 		
 	}
 	if(pos1==n||pos2==n)
 	{
 		return dst;
 	}
 	else if (pos1>=pos2)
 	{
 		for(i=pos1+1;i<n-1;i++)
 			restr[i]=dst[i];
 
 	}
 	else if (pos1<pos2)
 	{
 		for(i=pos2+1;i<n-1;i++)
 			restr[i]=dst[i];
 
 	}
 */
 
 
 
 } 
 int main()
 {
 	ifstream in("B-small-attempt1.in");
 	ofstream out("output.out");
 	int T,c,d,N;
 	char cstr[4],dstr[3],nstr[101];
 	int m,i,j;
 	string cstring,dstring,nstring;
 	in>>T;
 	for(m=0;m<T;m++)
 	{
 		in>>c;
 		if(c==1)
 		{
 			in>>cstr[0]>>cstr[1]>>cstr[2];
 
 		}
 		else if (c==0)
 		{
 			cout<<"no chac"<<endl;
 			cstr[0]=cstr[1]=cstr[2]=0;
 
 
 		}
 		cstr[3]='\0';
 		in>>d;
 		if (d==1)
 		{
 			in>>dstr[0]>>dstr[1];
 		}
 		else if (d==0)
 		{
 			cout<<"d no chac"<<endl;
 			dstr[0]=dstr[1]=0;
 		}
 		dstr[2]='\0';
 		in>>N;
 		for (i=0;i<N;i++)
 		{
 			in>>nstr[i];
 		}
 		nstr[i]='\0';
 		nstring=nstr;
 		cstring=cstr;
 		dstring=dstr;
 		string rcstring,rdstring;
 		
 		if (dstring.length()!=0)
 		{
 			nstring=searchdstr(dstring,nstring,N);
 			/*
 			while (rdstring!=nstring)
 			{
 				N=rdstring.length();
 				nstring=rdstring;
 				rdstring=searchdstr(dstring,rdstring,N);
 
 			}*/
 		}
 		
 
 		N=nstring.length();
 
 
 		if (cstring.length()!=0)
 		{
 			nstring=searchcstr(cstring,nstring,N);
 			/*
 			while (rcstring!=nstring)
 			{
 				N=rcstring.length();
 				nstring=rcstring;
 				rcstring=searchcstr(cstring,rcstring,N);
 			}*/
 
 		}
 		
 
 		
 
 		int numl=nstring.length();
 		out<<"Case #"<<m+1<<": "<<"[";
 		for (i=0;i<numl;i++)
 		{
 			out<<nstring.at(i);
 			if (i!=numl-1)
 			{
 				out<<",";
 			}
 		}
 		out<<"]"<<endl;
 
 	}
 }
 
 
 
