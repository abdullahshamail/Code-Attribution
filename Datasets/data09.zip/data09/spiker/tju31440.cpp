#include <cstdio>
 #include <string>
 #include <vector>
 #include <algorithm>
 #include <cmath>
 #include <memory.h>
 using namespace std;
 int main(void)
 {
 	int n,m,t,q,x,i,j,k,r;
 	vector<vector<int>> a,c;
 	vector<int> b;
 	freopen("rr1.in","r",stdin);
 	freopen("rr1.out","w",stdout);
 	scanf("%d",&t);
 	for (q=1;q<=t;q++)
 	{
 		a.clear();
 		c.clear();
 		scanf("%d%d",&n,&m);
 		for (i=0;i<n;i++)
 		{
 			b.clear();
 			for (j=0;j<m;j++)
 			{
 				scanf("%d",&x);
 				b.push_back(x);
 			}
 			a.push_back(b);
 		}
 		sort(a.begin(),a.end());
 		c.push_back(a[0]);
 		for (i=1;i<n;i++)
 		{
 			for (j=0;j<c.size();j++)
 			{
 				r=1;
 				for (k=0;k<m;k++)
 					if (a[i][k]<=c[j][k])
 					{
 						r=0;
 						break;
 					}
 				if (r)
 				{
 					for (k=0;k<m;k++)
 						c[j][k]=a[i][k];
 					break;
 				}
 			}
 			if (!r)
 				c.push_back(a[i]);
 		}
 		printf("Case #%d: %d\n",q,c.size());
 	}
 	fclose(stdout);
 	return 0;
 }
 
 
 
