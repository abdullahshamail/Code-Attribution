//goro sort
 #include<iostream>
 #include <iomanip>
 #include<vector>
 #include<set>
 #include<map>
 
 using namespace std;
 
 typedef vector<int> IntVec;
 typedef set<int> IntSet;
 typedef vector<IntSet> IntGroups;
 typedef map<int, double> Factorialmap;
 
 int main()
 {
     Factorialmap gFactMap;
     double val = 1;
     gFactMap[0]=1;
     for(int i =1; i<= 1000; ++i)
     {
        val *= i;
        gFactMap[i] = val;       
     }
     
     Factorialmap gNoNoAtPos; //number of combinations where no number at it's index
     gNoNoAtPos[0] = 0;
     gNoNoAtPos[1] = 0;
     for(int i =2; i<= 1000; ++i) 
     {
        gNoNoAtPos[i] = gFactMap[i]; //all permutations - iCj* (i-j) numbers not as position.
        gNoNoAtPos[i] -= 1;  // all i numbers at place 
        
        for(int j=1; j<i-1; ++j) //choose j: 1 to i-1 number at place, rest i-j not at place
        {
           gNoNoAtPos[i] -=  (gNoNoAtPos[i-j]*gFactMap[i])/(gFactMap[j]* gFactMap[i-j]); 
        }     
     }
     
     
     Factorialmap gProbMap;
     gProbMap[1]=1;
     int count=0;
     //while(count<1)
     {
         for(int i = 2; i<= 1000; ++i) //group size i
         {
             double prev = 0;    
             prev += 1.0/gFactMap[i];   //probability of all numbers at index
             
             //iCj ways to choose j numbers: 1 to i-1 at index
             //the total number of  combinations for the rest i-j so that none is at index
             //i! total permutations 
             //probability of sorting the rest prob[i-j]
             for(int j=1; j<i; ++j)
             {
                 prev +=  (gProbMap[i-j]*gNoNoAtPos[i-j])/(gFactMap[j]*gFactMap[i-j]); 
             } 
             
             //double delta = prob*gNoNoAtPos[i]/gFactMap[i];
             //prob = prev + prob*c ==> prob = prev*(1-c)
             gProbMap[i] = prev*(1- ((gNoNoAtPos[i]-1)/gFactMap[i]));
         }
         //++count;
     }
     
     
     int T;
     cin >> T;
     for(int n =0; n<T; ++n)
     {
        int k;
        cin>>k;
        IntVec numbers;
        IntVec grouped;  grouped.resize(k);
        IntVec indexes;  indexes.resize(k);
        for(int i=0; i<k; ++i)
        {
            int temp;
            cin>>temp;
            numbers.push_back(temp-1);  
            grouped[i] = 0; 
            indexes[temp-1] = i;  
        }  
        
        IntGroups groups;
        for(int i=0; i< numbers.size(); ++i)
        {
            if(!grouped[i])
            {    
                 IntSet group;
                 int num = numbers[i];
                 while(group.find(num) == group.end())
                 {
                    group.insert(num);
                    grouped[indexes[num]] = 1;
                    num = numbers[num];    
                 }
                 groups.push_back(group);
            }       
        }
        
        IntVec vals;
        for(int i=0; i< groups.size(); ++i)
        {
             if(groups[i].size()!=1)   
               vals.push_back(groups[i].size());
        }
        sort(vals.begin(), vals.end());
        
        double val=0;       
        for(int i=0; i<vals.size(); ++i)
        {
            val += 1/gProbMap[vals[i]];     
        }
        
        cout << "Case #" <<n+1<<": "<< setiosflags(ios::fixed) << setprecision(6) << val <<"\n"; 
     }
 }
