
#include <bits/stdc++.h>
 using namespace std;
 
 
#define ReplacementFor_rep(ReplacementFor_i, ReplacementFor_from, ReplacementFor_to) for (int ReplacementFor_i = ReplacementFor_from; ReplacementFor_i < int(ReplacementFor_to); ++ReplacementFor_i)
 
#define ReplacementFor_trav(a, x) for (auto& a : x)
 
#define all(x) x.begin(), x.end()
 
#define ReplacementFor_sz(x) (int)(x).size()
 typedef long long ReplacementFor_ll;
 typedef pair<int, int> ReplacementFor_pii;
 typedef vector<int> ReplacementFor_vi;
 
 void ReplacementFor_solve() {
 	string ReplacementFor_num;
 	cin >> ReplacementFor_num;
 	char ReplacementFor_lo = ((char)(0x1f36+1528-0x24fe));
 	ReplacementFor_rep(ReplacementFor_i,0,ReplacementFor_sz(ReplacementFor_num)) {
 		if (ReplacementFor_lo > ReplacementFor_num[ReplacementFor_i]) {
 			for (int ReplacementFor_j = ReplacementFor_i-1; ReplacementFor_j >= 0; --ReplacementFor_j) {
 				if (ReplacementFor_j == 0 || ReplacementFor_num[ReplacementFor_j] > ReplacementFor_num[ReplacementFor_j-1]) {
 					ReplacementFor_num[ReplacementFor_j]--;
 					ReplacementFor_rep(k,ReplacementFor_j+1,ReplacementFor_sz(ReplacementFor_num)) ReplacementFor_num[k] = ((char)(0x625+2637-0x1039));
 					break;
 				}
 			}
 			break;
 		}
 		else {
 			ReplacementFor_lo = ReplacementFor_num[ReplacementFor_i];
 		}
 	}
 	while (ReplacementFor_num[0] == ((char)(0xf0+2978-0xc62))) ReplacementFor_num.erase(ReplacementFor_num.begin());
 	cout << ReplacementFor_num << endl;
 }
 
 int main() {
 	cin.sync_with_stdio(false);
 	cin.exceptions(cin.failbit | cin.eofbit | cin.badbit);
 	cin.tie(0);
 	int T;
 	cin >> T;
 	ReplacementFor_rep(ReplacementFor_i,0,T) {
 		cout << "Case #" << ReplacementFor_i+1 << ": ";
 		ReplacementFor_solve();
 	}
 }
#include <bits/stdc++.h>
 using namespace std;
 
 
#define ReplacementFor_rep(ReplacementFor_i, ReplacementFor_from, ReplacementFor_to) for (int ReplacementFor_i = ReplacementFor_from; ReplacementFor_i < int(ReplacementFor_to); ++ReplacementFor_i)
 
#define ReplacementFor_trav(a, x) for (auto& a : x)
 
#define all(x) x.begin(), x.end()
 
#define ReplacementFor_sz(x) (int)(x).size()
 typedef long long ReplacementFor_ll;
 typedef pair<int, int> ReplacementFor_pii;
 typedef vector<int> ReplacementFor_vi;
 
 void ReplacementFor_solve() {
 	string ReplacementFor_num;
 	cin >> ReplacementFor_num;
 	char ReplacementFor_lo = ((char)(0xc74+3975-0x1bcb));
 	ReplacementFor_rep(ReplacementFor_i,0,ReplacementFor_sz(ReplacementFor_num)) {
 		if (ReplacementFor_lo > ReplacementFor_num[ReplacementFor_i]) {
 			for (int ReplacementFor_j = ReplacementFor_i-1; ReplacementFor_j >= 0; --ReplacementFor_j) {
 				if (ReplacementFor_j == 0 || ReplacementFor_num[ReplacementFor_j] > ReplacementFor_num[ReplacementFor_j-1]) {
 					ReplacementFor_num[ReplacementFor_j]--;
 					ReplacementFor_rep(k,ReplacementFor_j+1,ReplacementFor_sz(ReplacementFor_num)) ReplacementFor_num[k] = ((char)(0x1b81+1200-0x1ff8));
 					break;
 				}
 			}
 			break;
 		}
 		else {
 			ReplacementFor_lo = ReplacementFor_num[ReplacementFor_i];
 		}
 	}
 	while (ReplacementFor_num[0] == ((char)(0x144a+769-0x171b))) ReplacementFor_num.erase(ReplacementFor_num.begin());
 	cout << ReplacementFor_num << endl;
 }
 
 int main() {
 	cin.sync_with_stdio(false);
 	cin.exceptions(cin.failbit | cin.eofbit | cin.badbit);
 	cin.tie(0);
 	int T;
 	cin >> T;
 	ReplacementFor_rep(ReplacementFor_i,0,T) {
 		cout << "Case #" << ReplacementFor_i+1 << ": ";
 		ReplacementFor_solve();
 	}
 }
#include <bits/stdc++.h>
 using namespace std;
 
 
#define ReplacementFor_rep(ReplacementFor_i, ReplacementFor_from, ReplacementFor_to) for (int ReplacementFor_i = ReplacementFor_from; ReplacementFor_i < int(ReplacementFor_to); ++ReplacementFor_i)
 
#define ReplacementFor_trav(a, x) for (auto& a : x)
 
#define all(x) x.begin(), x.end()
 
#define ReplacementFor_sz(x) (int)(x).size()
 typedef long long ReplacementFor_ll;
 typedef pair<int, int> ReplacementFor_pii;
 typedef vector<int> ReplacementFor_vi;
 
 void ReplacementFor_solve() {
 	string ReplacementFor_num;
 	cin >> ReplacementFor_num;
 	char ReplacementFor_lo = ((char)(0x1751+60-0x175d));
 	ReplacementFor_rep(ReplacementFor_i,0,ReplacementFor_sz(ReplacementFor_num)) {
 		if (ReplacementFor_lo > ReplacementFor_num[ReplacementFor_i]) {
 			for (int ReplacementFor_j = ReplacementFor_i-1; ReplacementFor_j >= 0; --ReplacementFor_j) {
 				if (ReplacementFor_j == 0 || ReplacementFor_num[ReplacementFor_j] > ReplacementFor_num[ReplacementFor_j-1]) {
 					ReplacementFor_num[ReplacementFor_j]--;
 					ReplacementFor_rep(k,ReplacementFor_j+1,ReplacementFor_sz(ReplacementFor_num)) ReplacementFor_num[k] = ((char)(0x157+3719-0xfa5));
 					break;
 				}
 			}
 			break;
 		}
 		else {
 			ReplacementFor_lo = ReplacementFor_num[ReplacementFor_i];
 		}
 	}
 	while (ReplacementFor_num[0] == ((char)(0xc09+4638-0x1df7))) ReplacementFor_num.erase(ReplacementFor_num.begin());
 	cout << ReplacementFor_num << endl;
 }
 
 int main() {
 	cin.sync_with_stdio(false);
 	cin.exceptions(cin.failbit | cin.eofbit | cin.badbit);
 	cin.tie(0);
 	int T;
 	cin >> T;
 	ReplacementFor_rep(ReplacementFor_i,0,T) {
 		cout << "Case #" << ReplacementFor_i+1 << ": ";
 		ReplacementFor_solve();
 	}
 }

