#include <stdio.h>
 #include <stdlib.h>
 #define INF 1000000000
 int t;
 int teams;
 int tmp;
 int p;
 int mi;
 int miss[1001];
 int rounds[15][1000];
 int win[15][15][1000];
 int ans;
 int nums;
 main()
 {
  freopen("B-small-attempt2.in","r",stdin);
  freopen("B-small.out","w",stdout);
  scanf("%d",&t);
  for(int i=1;i<=t;i++)
  {
   scanf("%d",&p);
   teams=(1<<p);
   //printf("%d\n",teams);
    for(int j=1;j<=teams;j++)
    {
     scanf("%d",&miss[j]);
    }
    tmp=teams;
    for(int j=1;j<=p;j++)
    {
     for(int k=1;k<=(tmp/2);k++)
     {
      scanf("%d",&rounds[j][k]);
     // printf("%d ",rounds[j][k]);
      //st[j][k]=((k-1)*nums)+1;
      //ed[j][k]=(k*nums);
     }
    // printf("\n");
     tmp=tmp/2;
    }
    tmp=teams;
    for(int j=0;j<=10;j++)
    {
     for(int k=0;k<=10;k++)
     {
      for(int l=0;l<=1000;l++)
      {
       win[j][k][l]=INF;
      }
     }
    }
    for(int k=1;k<=teams;k++)
    {
     win[0][miss[k]][k]=0;
    }
    tmp=teams;
    for(int j=1;j<=p;j++)
    {
     for(int k=1;k<=(tmp/2);k++)
     {
      for(int l=0;l<=p;l++)
      {
       for(int q=0;q<=p;q++)
       {
 
         mi=l;
         if(q<mi){mi=q;}
         if(win[j][mi][k]>win[j-1][l][(k*2)-1]+win[j-1][q][(k*2)]+rounds[j][k]){win[j][mi][k]=win[j-1][l][(k*2)-1]+win[j-1][q][(k*2)]+rounds[j][k];}
         if(mi>0)
         {
          if(win[j][mi-1][k]>win[j-1][l][(k*2)-1]+win[j-1][q][(k*2)]){win[j][mi-1][k]=win[j-1][l][(k*2)-1]+win[j-1][q][(k*2)];}
         }
        
       }
      }
     }
     tmp=tmp/2;
    }
    ans=INF;
    for(int j=0;j<=p;j++)
    {
     if(win[p][j][1]<ans){ans=win[p][j][1];}
    }
    printf("Case #%d: %d\n",i,ans);
  }
  //system("pause");
  return 0;
 }
