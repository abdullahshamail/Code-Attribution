#include <algorithm>
 #include <cassert>
 #include <cmath>
 #include <cstdio>
 #include <cstring>
 #include <map>
 #include <set>
 #include <string>
 #include <vector>
 
 using namespace std;
 
 #define sz(a) ((int)((a).size()))
 #define forn(i, n) for (int i = 0; i < (n); i++)
 #define forr(i, n) for (int i = (n) - 1; i >= 0; i--)
 #define foreach(i, a) for (typeof((a).begin()) i = (a).begin(); i != (a).end(); ++i)
 #define eprintf(...) {fprintf(stderr,__VA_ARGS__);fflush(stderr);}
 typedef pair<int, int> ii;
 typedef long long LL;
 
 char tmp[510];
 int n, m;
 int a[510][510];
 // si[i][j] -- a[0][j], a[1][j], ..., a[i][j]
 // sj[i][j] -- a[i][0], a[i][1], ..., a[i][j]
 
 int main() {
     int tests;
     scanf("%d\n", &tests);
     for (int test = 1; test <= tests; test++) {
         printf("Case #%d: ", test);
         int D;
         scanf("%d%d%d\n", &n, &m, &D);
         forn(i, n) {
             gets(tmp);
             forn(j, m) a[i][j] = D + (tmp[j] - '0');
         }
         LL ans = -1;
         forn(i, n) forn(j, m) {
             LL maxk = max(max(i, j), max(n - i - 1, m - j - 1));
             for (LL k = 1; k <= maxk; k++) {
                 LL vx = 0, vy = 0;
                 for (int dx = -k; dx <= k; dx++) {
                     for (int dy = -k; dy <= k; dy++) {
                         if ((dx == k || dx == -k) && (dy == k || dy == -k)) continue;
                         vx += a[i+dx][j+dy] * dx;
                         vy += a[i+dx][j+dy] * dy;
                     }
                 }
                 if (!vx && !vy) ans = max(ans, 2*k+1);
             }
         }
         if (ans < 0) printf("IMPOSSIBLE\n");
             else printf("%I64d\n", ans);
     }
     
     return 0;
 }
