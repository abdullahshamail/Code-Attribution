#include <iostream>
 using namespace std;
 
 int seq=-1;
 int posi=0;
 char ans[100][100];
 enum {NORTH,SOUTH,WEST,EAST};
 int tome(int data[100][100],int i,int j,int h,int w,int dir)
 {
 	if(dir == NORTH)
 	{
 		if((data[i][j]<data[i-1][j])&&(j==0||data[i][j]<data[i-1][j-1])&&(j==w||data[i][j]<data[i-1][j+1])&&(i-1==0||data[i][j]<data[i-2][j]))
 			return 1;
 		//жͬµ˳
 	}
 	if(dir == SOUTH)
 	{
 		if((data[i][j]<data[i+1][j])&&(j==0||data[i][j]<=data[i+1][j-1])&&(j==w||data[i][j]<=data[i+1][j+1])&&(i+1==h||data[i][j]<=data[i+2][j]))
 			return 1;
 	}
 	if(dir == WEST)
 	{
 		if((data[i][j]<data[i][j-1])&&(i==0||data[i][j]<data[i-1][j-1])&&(i==h||data[i][j]<=data[i+1][j-1])&&(j-1==0||data[i][j]<data[i][j-2]))
 			return 1;
 	}
 	if(dir == EAST)
 	{
 		if((data[i][j]<data[i][j+1])&&(i==0||data[i][j]<data[i-1][j+1])&&(i==h||data[i][j]<=data[i+1][j+1])&&(j+1==w||data[i][j]<=data[i][j+2]))
 			return 1;
 	}
 	return 0;
 }
 void msearch(int data[100][100],int i,int j,int h,int w)
 {
 	int tmp;
 	if(i!=0)
 	{
 		tmp=tome(data,i,j,h,w,NORTH);
 		if(tmp==1)
 		{
 			ans[i-1][j]='a'+seq;
 		//	cout<<"NORTH "<<i-1<<" , "<<j<<endl;
 			if(i-1==0&&j==0)
 				posi=seq;
 			msearch(data,i-1,j,h,w);
 		}
 	}
 	if(i!=h)
 	{
 		tmp = tome(data,i,j,h,w,SOUTH);
 		if(tmp == 1)
 		{
 			ans[i+1][j]='a'+seq;
 		//	cout<<"SOUTH "<<i+1<<" , "<<j<<endl;
 			msearch(data,i+1,j,h,w);
 		}
 	}
 	if(j!=0)
 	{
 		tmp = tome(data,i,j,h,w,WEST);
 		if(tmp == 1)
 		{
 			ans[i][j-1]='a'+seq;
 		//	cout<<"WEST "<<i<<" , "<<j-1<<endl;
 			if(i==0&&j-1==0)
 				posi=seq;
 			msearch(data,i,j-1,h,w);
 		}
 	}
 	if(j!=w)
 	{
 		tmp = tome(data,i,j,h,w,EAST);
 		if(tmp == 1)
 		{
 			ans[i][j+1]='a'+seq;
 		//		cout<<"EAST "<<i<<" , "<<j+1<<endl;
 			msearch(data,i,j+1,h,w);
 		}
 	}
 }
 
 int main()
 {
 	int map,h,w,data[100][100];
 	int i,l,c;
 	cin>>map;
 
 	for(i=0;i<map;i++)
 	{
 		cin>>h>>w;
 		h--;
 		w--;
         for(l=0;l<=h;l++)
 			for(c=0;c<=w;c++)
 				cin>>data[l][c];
 		for(l=0;l<=h;l++)
 			for(c=0;c<=w;c++)
 			{
 				if((l==0||data[l][c]<=data[l-1][c])&&(c==0||data[l][c]<=data[l][c-1])&&(l==h||data[l][c]<=data[l+1][c])&&(c==w||data[l][c]<=data[l][c+1]))
 				 //ҵһsink
 				{
 					seq++;
 					ans[l][c]='a'+seq;
              //       cout<<"sink "<<l<<" , "<<c<<endl;
 					msearch(data,l,c,h,w);
 				}
 			}
 		if(posi != 0)
 		{
 			 for(l=0;l<=h;l++)
 				for(c=0;c<=w;c++)
 				{
 					if(ans[l][c]<'a'+posi)
 						ans[l][c]++;
 					else if(ans[l][c]=='a'+posi)
 						ans[l][c]='a';
 				}
 		}
 		cout<<"Case #"<<i+1<<":"<<endl;
 		for(l=0;l<=h;l++)
 		{
 			for(c=0;c<=w;c++)
 				cout<<ans[l][c]<<" ";
 			cout<<endl;
 		}
 
 	  posi=0;
 	  seq=-1;
 	}
 
 	return 0;
 }
