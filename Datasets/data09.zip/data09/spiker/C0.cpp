#include <cstdio>
 #include <string>
 #include <vector>
 #include <algorithm>
 #include <cmath>
 #include <memory.h>
 using namespace std;
 int main(void)
 {
 	freopen("r1.in","r",stdin);
 	freopen("r1.out","w",stdout);
 	int t,q,w,n,r,i,j,sum,pr[10009],ma,mi,vk1,vk2,nt[1000],kl1,kl2,su,no,pp;
 	scanf("%d",&t);
 	vector<int> v;
 	for (q=1;q<=t;q++)
 	{
 		v.clear();
 		memset(pr,0,sizeof(pr));
 		pr[0]=1;
 		scanf("%d%d",&n,&w);
 		pr[n+1]=1;
 		for (i=0;i<w;i++)
 		{
 			scanf("%d",&r);
 			v.push_back(r);
 		}
 		sort(v.begin(),v.end());
 		sum=0;
 		memset(nt,0,sizeof(nt));
 		for (pp=0;pp<v.size();pp++)
 		{
 			mi=100000000;
 			for (i=0;i<v.size();i++)
 			if (!nt[i])
 			{
 				kl1=0;
 				j=v[i]-1;
 				while (!pr[j])
 				{
 					kl1++;
 					j--;
 				}
 				j=v[i]+1;
 				kl2=0;
 				while (!pr[j])
 				{
 					kl2++;
 					j++;
 				}
 				if (abs(kl1-kl2)<mi)
 				{
 					mi=abs(kl1-kl2);
 					no=i;
 					su=kl1+kl2;
 				}
 			}
 			sum+=su;
 			pr[v[no]]=1;
 			nt[no]=1;
 		}
 		printf("Case #%d: %d\n",q,sum);
 	}
 	fclose(stdout);
 	return 0;
 }
