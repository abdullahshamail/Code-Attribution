#include <queue>
 #include <algorithm>
 #include <cstdio>
 #include <iostream>
 #include <utility>
 #include <vector>
 
 using namespace std;
 
 int solve(int*, int);
 
 typedef priority_queue<int> heap;
 
 int main()
 {
 	int T;
 	cin >> T;
 
 	int cs = 1;
 	while(T--)
 	{
 		int d;
 		cin >> d;
 
 		int *p = new int[d];
 		for(int i = 0; i < d; i++)
 			cin >> p[i];
 		int tn = solve(p,d);
 		printf("Case #%d: %d\n",cs,tn);
 		delete[] p;
 		cs++;
 	}
 	return 0;
 }
 
 int solve(int* p, int d)
 {
 	vector<int> v;
 	heap m(p,p+d);
 	int t = 0;
 
 	int w = m.top();
 	v.push_back(t+w);
 	while(w > 3)
 	{
 		m.pop();
 		m.push(w/2);
 		m.push(w - w/2);
 		t += 1;
 
 		w = m.top();
 		v.push_back(w+t);
 	}
 	t += w;
 	v.push_back(t);
 	sort(v.begin(),v.end());
 	return v[0];
 }
 
