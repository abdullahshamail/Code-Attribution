#include<cstdio>
 #include<algorithm>
 using namespace std;
 
 int a[1001];
 bool j[1001];
 void v(int i)
 {
 	if (j[i])
 		return;
 	j[i] = true;
 	v(a[i]);
 }
 int main()
 {
 	int t,n,result;
 	scanf("%d",&t);
 	for(int tt=1; tt<=t; tt++)
 	{
 		result = 0;
 		scanf("%d",&n);
 		for (int i=1; i<=n; i++)
 		{
 			scanf("%d",&a[i]);
 			if (a[i] != i)
 			{
 				result ++;
 				j[i] = false;
 			}
 			else
 				j[i] = true;
 		}
 		for (int i=1; i<=n; i++)
 			if (!j[i])
 			{
 				v(i);
 				result --;
 			}
 		printf("Case #%d: %lf\n",tt,(double)result*2.);
 	}
 }
