//Aleksander Łukasiewicz
 #include<cstdio>
 using namespace std;
 
 const int MAXN = 1000;
 
 int t;
 bool check[MAXN + 3];
 int prep[MAXN + 3];
 
 bool is_palindrom(int p)
 {
     int number[10], len = 0;
     while(p)
 	number[len++] = p%10, p/=10;
     for(int i=0, j=len-1; i<j; i++, j--)
 	if(number[i]!=number[j])
 	    return false;
     return true;
 }
 
 void preprocessing()
 {
     for(int i=1; i*i<=MAXN; i++)
 	if(is_palindrom(i) && is_palindrom(i*i))
 	    check[i*i]=true;
     for(int i=1; i<=MAXN; i++)
 	prep[i] = check[i] ? prep[i-1]+1 : prep[i-1];
 }
 
 int main()
 {
     preprocessing();
     scanf("%d", &t);
     for(int i=1; i<=t; i++)
     {
 	int A, B;
 	scanf("%d %d", &A, &B);
 	printf("Case #%d: %d\n", i, prep[B]-prep[A-1]);
     }
 
 return 0;
 }