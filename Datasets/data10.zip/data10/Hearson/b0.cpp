#include <iostream>
 #include <cstdlib>
 #include <cstdio>
 #include <cstring>
 #include <cmath>
 #include <cassert>
 #include <algorithm>
 #include <vector>
 #include <set>
 #include <utility>
 #include <string>
 #include <queue>
 
 //#define _DEBUG_MODE_
 
 #ifdef _DEBUG_MODE_
 #define db(X) cerr << "* DEBUG [L" << __LINE__ << "]: " << #X << " = " << X << endl;
 #define db_arr(X) cerr << "* DEBUG [L" << __LINE__ << "]: {" << #X << "} = "; for (int __i__=0; __i__<sizeof(X)/sizeof(X[0]); __i__++) cerr << X[__i__] << " "; cerr << endl;
 #define db_arrM(X, M) cerr << "* DEBUG [L" << __LINE__ << "]: {" << #X << "} = "; for (int __i__=0; __i__<M; __i__++) cerr << X[__i__] << " "; cerr << endl;
 #define db_arrMN(X, M, N) cerr << "* DEBUG [L" << __LINE__ << "]: {" << #X << "} = "; for (int __i__=M; __i__<N; __i__++) cerr << X[__i__] << " "; cerr << endl;
 #else
 #define db(X)
 #define db_arr(X)
 #define db_arrM(X, M)
 #define db_arrMN(X, M, N)
 #endif
 
 #define For(i, n) for(i=0;i<(n);i++)
 #define ForL(i, m, n) for(i=(m);i<(n);i++)
 
 #define Clear(X) memset( (X), 0, sizeof( (X) ) )
 #define Fill(X) memset( (X), -1, sizeof( (X) ) )
 
 using namespace std;
 typedef long long ll;
 typedef unsigned long long ull;
 typedef unsigned int uint;
 typedef unsigned long ulong;
 
 void _main();
 
 int main() {
   // COUNTER CODE STARTS HERE
 
   int cases, i;
 
   cin >> cases;
 
   For (i, cases) {
     printf("Case #%d: ", i+1);
     _main();
     cout << endl;
   }
 
   // COUNTER CODE ENDS HERE
 
   return 0;
 }
 
 // ACTUAL CODE STARTS BELOW
 int dp[200][200];
 int a[200];
 int D, I, M, N;
 
 void _main() {
   Clear(dp);
 
   int i, j, k, l, r, m, c, d;
 
   cin >> D >> I >> M >> N;
 
   For (i, N) {
     cin >> a[i];
   }
 
   For (i, N-1) {
     c = 0x7fffffff;
     d = abs(a[i+1] - a[i]);
     if (D < c) c = d; // Del
     if (M != 0  && ((d-1)/M)*I < c) c = ((d-1)/M)*I; // Ins
     //if ((d-M) > 0 && (d-M) < c) c = d-M; // Modify;
     dp[i][i+1] = c;
   }
 
   c = dp[0][1] + dp[1][2];
   db(c);
 
   if (M == 0) {
     l = r = a[0];
     for (i=1; i<N; i++) {
       l = min(l, a[i]);
       r = max(r, a[i]);
     }
 
     for (int t=l; t<=r; t++) {
       d=0;
       for (i=0; i<N; i++) d += abs(t-a[i]);
       c = min(c, d);
     }
   } else if (N == 3) {
     i = a[0];
     j = a[2];
 
     if (i > j) {
       k = i; i = j; j = k;
     }
     db(i); db(j);
     
     for (m=i+1; m<j; m++) {
       int b = abs(m-a[1]);
       b += (m-i-1)/M*I;
       b += (j-m-1)/M*I;
 
       db(m); db(b);
       if (b < c) c = b;
     }
   }
 
   cout << c;
 }
