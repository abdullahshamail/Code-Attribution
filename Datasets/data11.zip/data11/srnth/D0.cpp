#include <fstream>
 using namespace std;
 
 ofstream fout ("D.out");
 ifstream fin ("D.in");
 
 int N,T;
 int n[1000],k[1000];
 double a;
 
 int main() {
     fin >> N;
     fout.precision(6);
     fout.setf(ios::fixed,ios::floatfield);
     for(int i=0;i<N;i++){
         fin >> T;
         for(int j=0;j<T;j++){
             fin >> n[j];
             k[n[j]-1]=j+1;
         }
         for(int j=0;j<T;j++)
             a+=(k[j]!=n[j])+(n[j]!=j+1);
         fout << "Case #" << i+1 << ": " << a << endl;
         a=0;
     }
     
     return 0;
 }
 
