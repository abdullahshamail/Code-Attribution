#include <iostream>
 #include <cmath>
 
 using namespace std;
 
 int max(int n, int a[]) {
 	int m = 0;
 	for(int i = 1 ; i < n ; i++)
 		if(a[m] < a[i])
 			m = i;
 	return m;
 }
 void print(int n, int a[]) {
 	for(int i = 0 ; i < n ; i++)
 		cout << a[i] << " " ;
 	cout << endl;
 }	
 void split(int n, int a[]) {
 	int m = max(n, a);
 	int x = floor(a[m]/2.0);
 	int y = ceil(a[m]/2.0);
 	a[m] = x;
 	a[n] = y;
 }
 int main() {
     int T, n, casen = 1, output;
     cin >> T;
     while(T--) {
         cin >> n;
 		int a[200 * n];
 		for(int i = 0 ; i < n ; i++)
 			cin >> a[i];
 		
 		int max1 = a[max(n, a)];
 		int nextm = 0, current = a[max(n, a)];
 		split(n, a);
 		n++;
 		int tries = 1;
 		nextm = a[max(n, a)] + tries;
 		if(nextm < current) {
 			current = nextm;
 		}
 		for(int i = 0 ; i < max1; i++) {
 			split(n, a);
 			n++;
 			tries++;
 			nextm = a[max(n, a)] + tries;
 			if(nextm < current) {
 				current = nextm;
 			}
 		}
 		output = (current);
         cout << "Case #" << casen++ << ": " << output << endl;
     }
     return 0;   
 }
