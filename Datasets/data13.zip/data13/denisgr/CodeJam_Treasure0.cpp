// CodeJam_Treasure.cpp : Defines the entry point for the console application.
 //
 
 #include "stdafx.h"
 #include <fstream>
 #include <iostream>
 #include <string>
 #include <set>
 #include <vector>
 #include <unordered_map>
 #include <xfunctional>
 #include <bitset>
 #include <sstream>
 #include <map>
 
 using namespace std;
 static const string impossibleStr = "IMPOSSIBLE";
 typedef multiset<int> IntMultiset;
 typedef IntMultiset::const_iterator IntMultisetIter;
 typedef vector<int> IntArray;
 typedef IntArray::const_iterator IntArrayIter;
 struct Chest
 {
    int keyType;
    IntArray keys;
    int number;
 };
 struct ChestComparer
 {
    bool operator ()(const Chest* l, const Chest* r) const
    {
       return l->number < r->number;
    }
 };
 struct solution
 {
    bool impossible;
    IntArray chestNumbers;
    bool operator < (const solution& s) const
    {
       if (chestNumbers.size() < s.chestNumbers.size())
          return false;
       else if (chestNumbers.size() > s.chestNumbers.size())
          return true;
       else
       {
          for (size_t i = 0; i < chestNumbers.size(); ++i)
          {
             if (chestNumbers[i] != s.chestNumbers[i])
             {
                return chestNumbers[i] < s.chestNumbers[i];
             }
          }
       }
       return false;
    }
    string ToString() const
    {
       if (impossible)
       {
          return impossibleStr;
       }
       else
       {
          stringstream ss;
          for (size_t i = 0; i < chestNumbers.size(); ++i)
          {
             ss << chestNumbers[i] << " ";
          }
          string chainStr = ss.str();
          // remove last space
          return string(chainStr.begin(), --chainStr.end());
       }
    }
 };
 
 typedef vector<Chest*> ChestArray;
 typedef ChestArray::const_iterator ChestArrayConstIter;
 typedef map<Chest*, ChestArray, ChestComparer> ChestMap;
 typedef ChestMap::iterator ChestMapIter;
 typedef ChestMap::const_iterator ChestMapConstIter;
 
 solution solve(ChestArray& chainOfChests, const ChestMap& chests, IntMultiset& availableKeys,
              vector<bool>& openedChests)
 {
    if (!availableKeys.empty())
    {
       for (IntMultisetIter keyIter = availableKeys.begin(); keyIter != availableKeys.end(); ++keyIter)
       {
          for (ChestMapConstIter chestIter = chests.begin(); chestIter != chests.end(); ++chestIter)
          {
             Chest* chest = chestIter->first;
             if (!openedChests[chest->number] && availableKeys.find(chest->keyType) != availableKeys.end())
             {
                openedChests[chest->number] = true;
                IntMultiset availableKeysUpdated(availableKeys.begin(), availableKeys.end());
                availableKeysUpdated.erase(availableKeysUpdated.find(chest->keyType));
                for (IntArrayIter keyIter = chest->keys.begin(); keyIter != chest->keys.end(); ++keyIter)
                {
                   availableKeysUpdated.insert(*keyIter);
                }
                chainOfChests.push_back(chest);
                solve(chainOfChests, chests, availableKeysUpdated, openedChests);
             }
          }
       }
    }
    ChestMapConstIter availableChestsIter = chests.find(chainOfChests.back());
    const ChestArray& availableChests = availableChestsIter->second;
    for (ChestArrayConstIter nextChestIter = availableChests.begin(); nextChestIter != availableChests.end(); ++nextChestIter)
    {
       Chest* nextChest = *nextChestIter;
       if (!openedChests[nextChest->number] && availableKeys.find(nextChest->keyType) != availableKeys.end())
       {
          openedChests[nextChest->number] = true;
          IntMultiset availableKeysUpdated(availableKeys.begin(), availableKeys.end());
          availableKeysUpdated.erase(availableKeysUpdated.find(nextChest->keyType));
          for (IntArrayIter keyIter = nextChest->keys.begin(); keyIter != nextChest->keys.end(); ++keyIter)
          {
             availableKeysUpdated.insert(*keyIter);
          }
          chainOfChests.push_back(nextChest);
          solve(chainOfChests, chests, availableKeysUpdated, openedChests);
       }
    }
 
    if (chainOfChests.size() != chests.size())
    {
       solution s;
       s.impossible = true;
       return s;
    }
    solution s;
    s.impossible = false;
    for (ChestArrayConstIter chestFromChainIter = chainOfChests.begin(); chestFromChainIter != chainOfChests.end(); ++ chestFromChainIter)
    {
        s.chestNumbers.push_back((*chestFromChainIter)->number + 1);
    }
    // remove last space
    return s;
 }
 
 string processTestCase(const ChestMap& chests, const IntMultiset& availableKeys)
 {
    int chestsQty = chests.size();
    typedef set<solution>::const_iterator SetStringIter;
    set<solution> solutions;
    for (IntMultisetIter keyIter = availableKeys.begin(); keyIter != availableKeys.end(); ++keyIter)
    {
       for (ChestMapConstIter chestIter = chests.begin(); chestIter != chests.end(); ++chestIter)
       {
          if (*keyIter == chestIter->first->keyType)
          {
             vector<bool> openedChests(chestsQty);
             fill(openedChests.begin(), openedChests.end(), false);
             openedChests[chestIter->first->number] = true;
             IntMultiset keysAtTheBegining(availableKeys.begin(), availableKeys.end());
             keysAtTheBegining.erase(keysAtTheBegining.find(*keyIter));
             for (IntArrayIter keyIter = chestIter->first->keys.begin(); keyIter != chestIter->first->keys.end(); ++keyIter)
             {
                keysAtTheBegining.insert(*keyIter);
             }
             ChestArray chainOfChests;
             chainOfChests.push_back(chestIter->first);
             solutions.insert(solve(chainOfChests, chests, keysAtTheBegining, openedChests));
          }
       }
    }
 
    if (solutions.size() > 0)
       return solutions.begin()->ToString();
    else
       return impossibleStr;
 }
 
 int _tmain(int argc, _TCHAR* argv[])
 {
    if (argc != 3)
    {
       cerr << "Usage: CodeJam_Lawnmower inputFileName outputFileName";
       return -1;
    }
 
    string line;
    fstream inputFile(argv[1], fstream::in);
    fstream outputFile(argv[2], fstream::out);
    getline(inputFile, line);
    int testCasesQty = atoi(line.c_str());
    int testCasesProcessed = 0;
    while (testCasesProcessed != testCasesQty)
    {
       int keysAtTheBeginingQty = 0, chestQty = 0;
       inputFile >> keysAtTheBeginingQty >> chestQty;
       IntMultiset availableKeys;
       int keyType;
       for (int i = 0; i < keysAtTheBeginingQty; ++i)
       {
          inputFile >> keyType;
          availableKeys.insert(keyType);
       }
       ChestMap chests;
       // read information about all chests
       for (int i = 0; i < chestQty; ++i)
       {
          Chest* currentChest = new Chest();
          currentChest->number = i;
          inputFile >> currentChest->keyType;
          int keyInsideQty = 0;
          inputFile >> keyInsideQty;
          int currentKeyTypeInsideChest = 0;
          for (int j = 0; j < keyInsideQty; ++j)
          {
             inputFile >> currentKeyTypeInsideChest;
             currentChest->keys.push_back(currentKeyTypeInsideChest);
          }
          chests.insert(std::make_pair(currentChest, ChestArray()));
       }
       // prepare structure 'linked chests'. i.e. structure will contain numbers of those chests
       // keys from particular chest fits to.
       for (ChestMapIter iter = chests.begin(); iter != chests.end(); ++iter)
       {
          const Chest& chest = *(iter->first);
          for (IntArrayIter keyIter = chest.keys.begin(); keyIter != chest.keys.end(); ++keyIter)
          {
             for (ChestMapIter chestIter = chests.begin(); chestIter != chests.end(); ++chestIter)
             {
                if (*keyIter == chestIter->first->keyType)
                {
                   iter->second.push_back(chestIter->first);
                }
             }
          }
       }
       outputFile << "Case #" << ++testCasesProcessed << ": " << processTestCase(chests, availableKeys);
 
       if (testCasesProcessed != testCasesQty)
          outputFile << '\n';
       else
          break;
    }
 
    return 0;
 }