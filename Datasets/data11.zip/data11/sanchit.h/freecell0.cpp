#include<stdio.h>
 #include<vector>
 #include<bitset>
 #include<iostream>
 #include<conio.h>
 using namespace std;
 
 #define max(a,b) (a>=b?a:b)
 int t=1,tests,D,G,N,Pd,Pg,i,flag=0,j;
 char pos[]="Possible",br[]="Broken";
 
 int main()
 {
     freopen("A-small-attempt1.in","r",stdin);
     freopen("A-small-1.out","w",stdout);
     scanf("%d",&tests);
     while(t<=tests)
     {
          scanf("%d %d %d",&N,&Pd,&Pg);
          flag=0;
          if(Pd==0 && Pg==0)
          {
               flag=1;
          }
          else if(Pd>0 && Pg==0)
          {
               flag=0;
          }
          else if(Pd==0 && Pg>0 && Pg!=100)
          {
               flag=1;
          }
          else if(Pd==100 && Pg==100)
          {
               flag=1;
          }
          else if(Pd<100 && Pg==100)
          {
               flag=0;
          }
          else if(Pd==100 && Pg<100)
          {
               flag=1;
          }
          else
          {
          for(i=1;i<=N && flag==0;i++)
          {
              for(j=0;j<=i && flag==0;j++)
              {
                  if((float)(j*100)/i==(float)Pd)
                  {
                       flag=1;//printf("enter");
                  }
              }
          }
          }
          if(flag==1)
          {
               j--;i--;
               //printf("Case #%d: %s %d %d %d %d %d\n",t,pos,(j*100)/i,Pd,Pg,j,i);
               printf("Case #%d: %s\n",t,pos);
          }
          else
          {
               printf("Case #%d: %s\n",t,br);
          }
          t++;
     }
     getch();
 }
          
          
          
          
          
          
          
          
          
          
          
           
                      
