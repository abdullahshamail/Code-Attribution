#include <iostream>
 #include <string>
 #include <vector>
 #include <algorithm>
 using namespace std;
 
 int main()
 {
 	long long c, i, n, b, t, j, k, s, hm;
 	long long x[55], v[55], nx[55];
 
 	cin >> c;
 	for (i = 0; i < c; i++)
 	{
 		cin >> n >> k >> b >> t;
 
 		for (j = 0; j < n; j++)
 			cin >> x[j];
 		for (j = 0; j < n; j++)
 			cin >> v[j];
 
 		s = 0;
 		for (long long t1 = 0; t1 < t; t1++)
 		{
 			hm = 0;
 			for (j = 0; j < n; j++)
 				if (x[j] >= b)
 					hm++;
 			if (hm >= k)
 				break;
 
 			memcpy(nx, x, sizeof(nx));
 			for (j = 0; j < n; j++)
 				if (nx[j] < b)
 					nx[j] += v[j];
 
 			for (j = n-1; j >= 0; j--)
 			{
 				if (nx[j] >= b)
 					continue;
 
 				if (j+1 < n && nx[j] > nx[j+1] && nx[j+1] < b && nx[j] < b)
 				{
 					swap(nx[j], nx[j+1]);
 					swap(v[j], v[j+1]);
 					s++;
 					j = n;
 				}
 			}
 
 			memcpy(x, nx, sizeof(x));
 		}
 
 		hm = 0;
 		for (j = 0; j < n; j++)
 			if (x[j] >= b)
 				hm++;
 
 		if (hm >= k)
 			cout << "Case #" << i+1 << ": " << s << endl;
 		else
 			cout << "Case #" << i+1 << ": " << "IMPOSSIBLE" << endl;
 	}
 
 	return 0;
 }
