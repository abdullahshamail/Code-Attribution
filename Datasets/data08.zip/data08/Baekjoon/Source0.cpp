#include <cstdio>
 #include <memory.h>
 #include <string>
 using namespace std;
 string bird = "BIRD";
 string nbird = "NOT BIRD";
 int a[1111][3];
 int h[10];
 int w[10];
 int main(){
 	freopen("input.txt","r",stdin);
 	freopen("output.txt","w",stdout);
 	int tc;
 	scanf("%d\n",&tc);
 	for(int tt=1; tt<=tc; tt++){
 		memset(a,0,sizeof(a)); 
 		memset(h,0,sizeof(h));
 		memset(w,0,sizeof(w));
 		printf("Case #%d:\n",tt);
 		int n;
 		scanf("%d\n",&n);
 		int t1,t2;
 		char temp[111]={0,};
 		int cntbird = 0 ;
 		for(int i=1; i<=n; i++){
 			scanf("%d %d %[^\n]\n",&a[i][0],&a[i][1],temp);
 			string t3 = temp;
 			if(t3==bird)
 				a[i][2] = 1;
 			else
 				a[i][2] = 2;
 			if(a[i][2]==1)
 				cntbird++;
 		}
 		h[0] = 0;
 		h[1] = 1000001;
 		h[2] = 0;
 		h[3] = 1000001;
 		for(int i=1; i<=n; i++){
 			if(a[i][2]==1){
 				if(h[1] > a[i][0])
 					h[1] = a[i][0];
 				if(h[2] < a[i][0])
 					h[2] = a[i][0];
 			}
 		}
 		for(int i=1; i<=n; i++){
 			if(a[i][2]==2){
 				if(h[1] > a[i][0] && h[0] < a[i][0])
 					h[0] = a[i][0];
 				if(h[2] < a[i][0] && h[3] > a[i][0])
 					h[3] = a[i][0];
 			}
 		}
 
 		w[0] = 0;
 		w[1] = 1000001;
 		w[2] = 0;
 		w[3] = 1000001;
 		for(int i=1; i<=n; i++){
 			if(a[i][2]==1){
 				if(w[1] > a[i][1])
 					w[1] = a[i][1];
 				if(w[2] < a[i][1])
 					w[2] = a[i][1];
 			}
 		}
 		for(int i=1; i<=n; i++){
 			if(a[i][2]==2){
 				if(w[1] > a[i][1] && w[0] < a[i][1])
 					w[0] = a[i][1];
 				if(w[2] < a[i][1] && w[3] > a[i][1])
 					w[3] = a[i][1];
 			}
 		}
 		int m;
 		scanf("%d\n",&m);
 		if(cntbird==0){
 			while(m--){
 			int t1,t2;
 			scanf("%d %d\n",&t1,&t2);
 			if((h[3]<=t1 && t1<=h[0]) || (w[3]<=t2 && t2<=w[0]))
 				printf("NOT BIRD\n");
 			else
 				printf("UNKNOWN\n");
 			}
 		}
 		else{
 		while(m--){
 			int t1,t2;
 			scanf("%d %d\n",&t1,&t2);
 			int type1, type2;
 			
 		 if(h[1]<=t1 && t1<=h[2])
 				type1=1;
 			else if(t1<=h[0])
 				type1=2;
 			else if(t1>=h[3])
 				type1=2;
 			else
 				type1=3;
 			
 			if(w[1]<=t2 && t2<=w[2])
 				type2=1;
 			else if(t2<=w[0])
 				type2=2;
 			else if(t2>=w[3])
 				type2=2;
 			else
 				type2=3;
 			if(type1==1 && type2==1)
 				printf("BIRD\n");
 			else if(type1==1 && type2==3)
 				printf("UNKNOWN\n");
 			else if(type1==1 && type2==2)
 				printf("NOT BIRD\n");
 			else if(type1==2 && type2==1)
 				printf("NOT BIRD\n");
 			else if(type1==3 && type2==1)
 				printf("UNKNOWN\n");
 			else if(type1==3 && type2==3)
 				printf("UNKNOWN\n");
 			else if(type1==2 && type2==3)
 				printf("NOT BIRD\n");
 			else if(type1==3 && type2==2)
 				printf("NOT BIRD\n");
 			else
 				printf("NOT BIRD\n");
 		}
 		}
 	}
 	return 0;
 }