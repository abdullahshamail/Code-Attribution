#include <iostream>
 using namespace std;
 
 long mem[1002], next_a[1002];
 
 int main()
 {
 	long t, n, k, r, i, j, a, b, c, hold, euro, g[1002];
 
 	cin >> t;
 
 	for (i = 0; i < t; i++)
 	{
 		cin >> r >> k >> n;
 
 		for (j = 0; j < n; j++)
 			cin >> g[j];
 
 		euro = 0;
 		a = 0;
 		memset(mem, 0, sizeof(mem));
 		for (j = 0; j < r; j++)
 		{
 			b = hold = 0;
 
 			if (mem[a])
 			{
 				hold = mem[a];
 				a = next_a[a];
 			}
 			else
 			{
 				c = a;
 				while(true)
 				{
 					if (hold + g[a] > k)
 						break;
 
 					hold += g[a];
 					a = (a+1) % n;
 					b++;
 
 					if (b == n)
 						break;
 				}
 				mem[c] = hold;
 				next_a[c] = a;
 			}
 
 			euro += hold;
 		}
 
 		cout << "Case #" << i+1 << ": " << euro << endl;
 	}
 
 	return 0;
 }
