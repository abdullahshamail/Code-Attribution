#include <iostream>
 #include <map>
 #include <set>
 #include <vector>
 
 using namespace std;
 
 int main(int argc, char *argv[])
 {
 	int cases, n;
 	cin >> cases;
 	vector<int> fibonacci_modulo(500, 1);
 	for(int i = 2; i < 500; ++i)
 		fibonacci_modulo[i] = (fibonacci_modulo[i-1] + fibonacci_modulo[i-2]) % 100003;
 	for(int ci = 0; ci < cases; ++ci)
 	{
 		cin >> n;
 		cout << "Case #" << (ci + 1) << ": " << fibonacci_modulo[n-1] << endl;
 	}
 
 	return 0;
 }
