#include <iostream>
 #include <algorithm>
 #include <vector>
 using namespace std;
 
 struct cc{
 	int idx;
 	int spos;
 	int speed;	
 };
 
 struct cs{
 	int speed;
 	vector<cc> ccs;
 };
 
 bool posSort(const cc &c1, const cc &c2)
 {
 	return c1.spos > c2.spos;
 }
 
 int main()
 {
 	int t_case;
 	scanf("%d", &t_case);
 
 	int N,K,B,T;
 	int NS[52],VS[52];
 	for(int t=1; t<=t_case; ++t)
 	{
 		scanf("%d %d %d %d", &N, &K, &B, &T);
 		for(int i=0; i < N; ++i) scanf("%d", &NS[i]);
 		for(int i=0; i < N; ++i) scanf("%d", &VS[i]);
 
 		cc c;
 		vector<cc> chs;		
 		for(int i=0; i < N; ++i){
 			c.idx = i;
 			c.spos = NS[i];
 			c.speed = VS[i];
 			chs.push_back(c);
 		}
 
 		sort( chs.begin(), chs.end(), posSort );
 
 		/*for(int i=0; i < N; ++i)
 			printf("%d ", chs[i].spos);
 		printf("\n");
 
 		for(int i=0; i < N; ++i)
 			printf("%d ", chs[i].speed);
 		printf("\n");*/
 
 		for(int i=0; i < N; ++i)
 			chs[i].idx = i;
 
 		vector<int> bestChs;
 		int sim=0;
 		for(int i=0; i < N; ++i){
 			if( chs[i].spos+T*chs[i].speed >= B ){
 				bestChs.push_back(chs[i].idx);
 				++sim;
 			}
 		}
 
 		bool impossible=false;
 		if( sim < K )
 			impossible=true;
 
 		int sw=0;
 		vector<cc> tmp=chs;
 		if(impossible==false)
 		{
 			int goal=0;			
 			for(int i=1; i <= T; ++i)
 			{
 				vector<cc> chs2 = tmp;
 				for(int i=0; i < chs2.size(); ++i)
 					chs2[i].spos += chs2[i].speed;
 				
 				for(int i=1; i < chs2.size(); ++i)
 					if( chs2[i].spos > chs2[i-1].spos )
 						chs2[i].spos = chs2[i-1].spos;
 				
 				tmp.clear();
 				for(int i=0; i < chs2.size(); ++i){
 					if( chs2[i].spos >= B )
 						++goal;
 					else
 						tmp.push_back(chs2[i]);
 				}
 			}
 			if( goal < K )
 			{			
 
 				int remain = K-goal;
 				vector<int> tempV;
 				for(int i=0; i < bestChs.size(); ++i){
 					if( bestChs[i] <= goal ) continue;
 					tempV.push_back(bestChs[i]);
 				}
 				swap(tempV, bestChs);
 
 				for(int i=1; i < T; ++i){
 					vector<cc> chs2 = tmp;
 					for(int i=0; i < chs2.size(); ++i)
 						chs2[i].spos += chs2[i].speed;
 
 					for(int i=chs2.size()-1; i > -1; --i){
 						if( find(bestChs.begin(), bestChs.end(), chs2[i].idx) != bestChs.end() ){
 							int j=i-1;
 							bool ttt=false;
 							for(int j=i-1; j > -1; --j){
 								if( chs2[j].spos < chs2[i].spos ){
 									++sw; ttt=true; break;
 								}
 							}
 							if(ttt)
 								swap(chs2[i], chs2[j]);
 						}
 
 					}
 
 					tmp.clear();
 					for(int i=0; i < chs2.size(); ++i){
 						if( chs2[i].spos >= B )
 							++goal;
 						else
 							tmp.push_back(chs2[i]);
 					}
 					if( goal >= K )
 						break;
 				}
 			}
 
 
 		}
 
 		if( impossible==true )
 			printf("Case #%d: IMPOSSIBLE\n", t);
 		else
 			printf("Case #%d: %d\n", t, sw);
 
 
 	}
 	return 0;
 }
 
