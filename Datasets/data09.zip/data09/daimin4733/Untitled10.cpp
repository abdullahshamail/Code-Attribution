#include<iostream>
 #define MAXN 100
 using namespace std;
 int n,k;
 int p[100][25];
 int mat[100][100];int ans;
 int col[100];
 int now;
 void dummy(int n,int* a){
 	 for (int i=0;i<n;i++)
 		col[a[i]]=col[a[0]];
 	//cout<<endl;
 	//ans-=(n-1);
 	//now++;
 } 
 
 void search(int n,int mat[][MAXN],int* dfn,int* low,int now,int& cnt,int* st,int& sp){
 	int i,m,a[MAXN];
 	dfn[st[sp++]=now]=low[now]=++cnt;
 	for (i=0;i<n;i++)
 		if (mat[now][i]){
 			if (!dfn[i]){
 				search(n,mat,dfn,low,i,cnt,st,sp);
 				if (low[i]<low[now])
 					low[now]=low[i];
 				if (low[i]>=dfn[now]){
 					for (st[sp]=-1,a[0]=now,m=1;st[sp]!=i;a[m++]=st[--sp]);
 					dummy(m,a);
 				}
 			}
 			else if (dfn[i]<low[now])
 				low[now]=dfn[i];
 		}
 }
 
 void block(int n,int mat[][MAXN]){
 	int i,cnt,dfn[MAXN],low[MAXN],st[MAXN],sp=0;
 	for (i=0;i<n;dfn[i++]=0);
 	for (cnt=i=0;i<n;i++)
 		if (!dfn[i])
 			search(n,mat,dfn,low,i,cnt,st,sp);
 }
 
 int main()
 {
     freopen("C-small-attempt2.in","r",stdin);
 	freopen("1.txt","w",stdout);
 	int cas=0;
 	int t,i,j;scanf("%d",&t);while(t--){
 	     scanf("%d%d",&n,&k);
 	     memset(col,-1,sizeof(col));
 	     memset(p,0,sizeof(p));
 	     memset(mat,0,sizeof(mat));
 		 for(i=0;i<n;i++)
 		    for(j=0;j<k;j++)
 			scanf("%d",&p[i][j]);
 	     for(i=0;i<n;i++)
 	     for(j=i+1;j<n;j++)
 	     {
 		     bool a=1,b=1;
 			 for(int l=0;l<k;l++)
 			 {
 			      if(p[i][l]>=p[j][l])a=0;
 				  if(p[i][l]<=p[j][l])b=0;		 
 	         }
 			 if(a||b) 
 			 {
 			     //printf("%d %d\n",i,j);
 				 mat[i][j]=1;
 				 mat[j][i]=1; 		  
 			 }				   
 		 }
 	     ans=0;now=0;
 	     //for(i=0;i<n;i++)
 	     //for(j=i+1;j<n;j++)
 	     //if(mat[i][j])printf("%d-%d\n",i,j);
 	     //for(i=0;i<n;i++)if(col[i]==-1)dfs(i);
 	     //for(i=0;i<n;i++)printf("%d ",col[i]);printf("\n");
 	     for(i=0;i<n;i++)col[i]=i;
 	     block(n,mat);bool ff[100];memset(ff,0,sizeof(ff));
 	     for(i=0;i<n;i++)ff[col[i]]=1;for(i=0;i<n;i++)ans+=ff[i];
 	     printf("Case #%d: %d\n",++cas,ans);
 	}
 }
