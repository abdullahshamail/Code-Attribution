#include<iostream>
 #include<cstring>
 #include<vector>
 #include<map>
 #include<algorithm>
 #include<cmath>
 #include<cctype>
 #include<bitset>
 #include<queue>
 #include<ctime>
 using namespace std;
 
 typedef long long int64;
 const int maxn=50;
 int f[2][maxn];
 int tot,a1,a2,b1,b2,a,b,k,ans;
 
 void gcd(int a,int b)
   {
    k++;
    if (a%b==0) return;
    gcd(b,a%b);
   }
   
 int dp(int o,int l,int a,int b)
   {
    if (l==k) return 1;
    if (f[o][l]>=0) return f[o][l];
    if (a/b==1) 
      {
       f[o][l]=-1;
       f[o][l]=dp(o^1,l+1,b,a-b)^1;
      }
    else 
      {
       f[o][l]=-1;
       f[o][l]=min(dp(o^1,l+1,b,a%b),dp(o^1,l,a-((a/b)-1)*b,b))^1;
      }
    return f[o][l];
   }
   
 void solve(int aa,int bb)
   {
    int a=aa,b=bb;
    if (a<b) swap(a,b);
    if (a==b) return;
    memset(f,255,sizeof(f));
    k=0;
    gcd(a,b);
    f[0][1]=dp(0,1,a,b);
    ans+=f[0][1];
   }
   
 int main()
   { 
    //freopen("game.in","r",stdin);
    //freopen("game.out","w",stdout);
    scanf("%d",&tot);
    for (int tt=1;tt<=tot;tt++)
      {
       scanf("%d%d%d%d",&a1,&a2,&b1,&b2);
       ans=0;
       for (a=a1;a<=a2;a++)
         for (b=b1;b<=b2;b++)
           solve(a,b);
       printf("Case #%d: %d\n",tt,ans);
      }
    return 0;
   }
