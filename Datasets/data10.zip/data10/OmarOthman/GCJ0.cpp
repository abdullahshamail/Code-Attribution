#include <fstream>
 using namespace std;
 
 int main()
 {
 	bool off;
 	int nCases, n, k, index;
 
 	ifstream fin("A-small.in");
 	ofstream fout("A-small.out");
 
 	fin >> nCases;
 
 	for (int currentCase = 1; currentCase <= nCases; currentCase++)
 	{
 		fin >> n >> k;
 
 		off = true;
 
 		for (index = 0; index < n; index++)
 		{
 			if ((k & 1) == false)
 			{
 				off = false;
 				break;
 			}
 
 			k >>= 1;
 		}
 
 		if (off)
 			fout << "Case #" << currentCase << ": ON" << endl;
 		else
 			fout << "Case #" << currentCase << ": OFF" << endl;
 	}
 
 	return 0;
 }