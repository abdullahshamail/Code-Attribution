#include <cstdio>
 #include <cmath>
 #include <cstring>
 #include <iostream>
 #include <map>
 #include <limits>
 #include <queue>
 #include <stack>
 #include <algorithm>
 #include <string>
 #include <ctime>
 #include <set>
 #include <vector>
 
 #define pb push_back
 #define mp make_pair
 #define mod 1000000007
 #define N 100001
 
 using namespace std;
 
 int main()
 {
 	freopen("B-small-attempt6.in","r",stdin);
     freopen("B-small-attempt6.out","w",stdout);
 	int n,t;
 	cin>>t;
 	for(int asd = 1; asd <= t; asd++){
 		int count = 0;
 		cin>>n;
 		int list[1001];
 		for(int i = 1; i <= 1000; i++) list[i] = 0;
 		int max = 0;
 		for(int i = 1; i <= n ;i++){
 			int sda;
 			cin>>sda;
 			list[sda]++;
 		}
 		for(int i = 1000; i > 0; i--){
 			if(list[i] == 0) continue;
 			if(i / 2 < list[i]) {
 				int k = count + i;
 				cout<<"Case #"<<asd<<": "<<k<<endl;
 				break;
 			}else {
 				for(int j = 1; j <= list[i]; j++){
 					if(i%2 == 0){
 						list[i/2] += 2;
 					}else {
 						int k = i / 2;
 						list[k] += 1;
 						list[k+1] += 1;
 					}
 					count++;
 				}
 			}
 		}
 	}
     return 0;
 }
