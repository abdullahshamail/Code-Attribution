#include<iostream>
 #include<vector>
 #include<iomanip>
 #include<cstdio>
 #include <algorithm>
 #include <cmath>
 #include <string>
 
 using namespace std;
 #define f(i,a,b) for (int i = a; i < b; i++ )
 #define rf(i,a,b) for (int i = a; i > =b; i-- )
 
 
 int main()
 {
 	long long int a[26] ={1, 4, 9, 121, 484, 10201, 12321, 14641, 40804, 44944, 1002001, 1234321, 4008004, 100020001, 102030201, 104060401, 121242121, 123454321, 125686521, 400080004, 404090404, 10000200001, 10221412201, 12102420121, 12345654321, 40000800004};
 	int t;
 	cin>>t;
 	for(int q=1;q<=t; q++)
     	{
 		long long int l,h;
 		int count=0;
 		cin>>l>>h;
 		for(int i=0;i<26;i++)
 		{
 			if(a[i]>=l&&a[i]<=h)
 			{
 				count++;
 			}
 		}
 		printf("Case #%d: %d\n",q,count);
 		
 	}
 	return 0;
 }
