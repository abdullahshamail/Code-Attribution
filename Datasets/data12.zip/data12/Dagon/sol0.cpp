#include <cstdio>
 #include <iostream>
 #include <cstring>
 #include <string>
 #include <algorithm>
 #include <cstdlib>
 #include <vector>
 #include <cmath>
 #include <set>
 #include <map>
 #include <deque>
 #include <bitset>
 
 #define sqr(x) ((x) * (x))
 #define fi first
 #define se second
 #define mp make_pair
 #define pb push_back
 #define y0 ywuerosdfhgjkls
 #define y1 hdsfjkhgjlsdfhgsdf
 #define j1 j924
 #define j0 j2834
 #define sqrt(x) (sqrt(abs(x)))
 #define re return
 #define sz(x) ((int)(x).size())
 #define all(x) (x).begin(), (x).end()
 #define rep(i, n) for (int i = 0; i < (n); i++)
 #define rrep(i, n) for (int i = ((n) - 1); i >= 0; i--)
 #define fill(a, x) memset(a, x, sizeof(a))
 
 using namespace std;
 
 typedef long long ll;
 typedef long double ld;
 typedef pair <int, int> ii;
 typedef vector <int> vi;
 typedef vector <ii> vii;
 typedef vector <vi> vvi;
 typedef double D;
 typedef vector <string> vs;
 
 template <class T> inline T abs(T a) {
 	return a > 0 ? a : -a;
 }
 
 int n;
 int m;
 
 int a[2000];
 
 ll h[2000];
 
 bool check() {
 	rep(i, n) {
 		int k = a[i];
 		for (int j = i + 1; j < n; j++) {
 			if (j != k) {
 				if ((h[j] - h[i]) * (k - i) > (h[k] - h[i]) * (j - i))
 					re false;
 			}
 		}
 	}
 	re true;
 }
 
 int main() {
 	int T;
 	cin >> T;
 	rep(I, T) {
 		cerr << I << endl;
 		cin >> n;
 		rep(i, n - 1) {
 			cin >> a[i];
 			a[i]--;
 		}
 		bool kpyto = false;
 		rep(J, 10000000) {
 			h[n - 1] = 500000000;
 			kpyto = true;
 			rrep(i, n - 1) {
 				ll L = 0, R = 1000000000;
 				int k = a[i];
 				for (int j = i + 1; j < n; j++) {
 					if (j != a[i]) {
 						ll A = j - k;
 						ll B = h[k] * (j - i) - h[j] * (k - i);
 						if (A > 0) {
 							R = min(R, (ll)(B / A));
 						} else {
 							L = max(L, (ll)(B / A) + 1);
 						}
 					}
 				}
 				if (L >= R) {
 					kpyto = false;
 					break;
 				}
 				h[i] = L + rand() % (R - L + 1);
 			}
 			if (kpyto)
 				break;
 		}
 		cout << "Case #" << I + 1 << ":";
 		if (kpyto) {
 			if (!check())
 				cerr << "ALARM" << endl;
 			rep(i, n)
 				cout << " " << h[i];
 			cout << endl;
 		} else
 			cout << " Impossible" << endl;
 	}
 	return 0;
 }
