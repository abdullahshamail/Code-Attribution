#include <iostream>
 #include <string>
 #include <vector>
 #include <fstream>
 
 
 using namespace std;
 
 
 int best(vector<int> vec)
 {
 	int maxone = vec[0];
 	int maxindex = 0;
 	for (size_t i = 0; i < vec.size(); i++){
 		if (vec[i] > maxone){
 			maxone = vec[i];
 			maxindex = i;
 		}
 	}
 	if (maxone > 1){
 		vec[maxindex] = maxone / 2;
 		vec.push_back(maxone- maxone/2);
 		int time = 1 + best(vec);
 		if (time < maxone){
 			return time;
 		}
 		else {
 			return maxone;
 		}
 	}
 	return maxone;
 }
 int main(int argc, char **argv)
 {
 	ifstream in(argv[1]);
 	int nCase;
 	in >> nCase;
 	for (int i = 1; i <= nCase; i++){
 		int nNum ;
 		in >> nNum;
 		vector<int> vecNum;
 		for (int j = 0; j < nNum; j++){
 			int tmp;
 			in >> tmp;
 			vecNum.push_back(tmp);
 		}
 		int minute = best(vecNum);
 		cout<<"Case #"<<i<<": "<<minute<<endl;
 	}
 	return 0;
 }
