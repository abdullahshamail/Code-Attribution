﻿#include<iostream>
 #include<string>
 #include<math.h>
 #include<vector>
 #include<queue>
 #include<algorithm>
 #include<cstdio>
 #include<cstdlib>
 #include<string.h>
 #include<map>
 
 using namespace std;
 
 int p[1005];
 int sol[1005];
 int main()
 {
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
 
 	int t;
 	cin >> t;
 	for (int ii = 1; ii <= t; ii++)
 	{
 		memset(p, 0, sizeof(p));
 		memset(sol, 0, sizeof(sol));
 		int result = 0;
 		int d, temp;
 		cin >> d;
 		for (int i = 0; i < d; i++)
 		{
 			cin >> temp;
 			p[temp]++;
 		}
 		for (int i = 1000; i >= 0; i--)
 		{
 			
 			if (p[i] == 0)
 				continue;
 			sol[i] = i + result;
 			if (i % 2 == 0)
 			{
 				int div = i / 2;
 				result+=p[i];
 				p[div] +=  p[i];
 				p[div]+= p[i];
 			}
 			else
 			{
 				int div = i / 2;
 				result+=p[i];
 				p[div]+= p[i];
 				p[div+1]+=p[i];
 			}
 		}
 
 		int answer = 10000000;
 		for (int i = 1000; i >= 0; i--)
 		{
 			if (sol[i] == 0)
 				continue;
 			if (answer > sol[i])
 				answer = sol[i];
 		}
 		cout << "Case #" << ii << ": " << answer << endl;
 	}
 	return 0;
 }
 
