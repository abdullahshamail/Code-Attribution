#include<iostream>
 #include <cstring>
 #include <stdio.h>
 #include <cmath>
 #include <iomanip>
 using namespace std;
 
 const int maxn = 2020;
 int T,n,d;
 int a[maxn];
 int h[maxn];
 int ans;
 bool flag;
 
 
 int main() {
     freopen("C-large.in", "r", stdin);
     freopen("C-large.out", "w", stdout);
     cin >> T;
     for (int test = 1; test <= T; test++) {
         cout << "Case #" << test << ": ";
         
          cin >> n;
         ans = 0;
         int tmp = 0;
         flag = true;
         for (int i = 0; i < n-1; i++)
         {
             cin >> a[i];
             a[i]--;
             for (int j = 0; j < i; j++)
                 if (a[j] > i && a[j] < a[i]) {
                     flag = false;
                     break;
                 }
         }
         
      if (!flag) {
         cout << "Impossible" << endl;
         continue;
     }
     
     bool check;
     int k;
     h[n-1] = 95000;
     h[n-2] = 65000;
     double tmp1;
     for (int i = n-3; i >= 0; i--)
     {
         if (a[i] == i+1)
         {
             tmp1 = double(h[a[i+1]]-h[i+1])/(a[i+1]-(i+1)) * (a[i+1]-i);
             h[i] = h[a[i+1]]-(tmp1+10);
         }
         else
         {
             for (int j = i+1; j < n-1; j++)
                 if (a[i] == a[j]) {
                     k = j;
                     break;
                 }
             tmp1 = double(h[a[i]]-h[k])/(a[i]-k) * (a[i]-i);
             h[i] = h[a[i]]-(tmp1-10);
         }
     }
     tmp1 = 0;
     for (int i = 0; i < n; i++)
         if(h[i] < 0 && tmp1 > h[i]) tmp1 = h[i];
     for (int i = 0; i < n; i++) h[i]+= -tmp1+10;
     for (int i = 0; i < n; i++)
         cout << h[i] << ' ';       
         
         
         cout << endl;
     }
     return 0;
 }
