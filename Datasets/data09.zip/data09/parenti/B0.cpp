#include <cstdio>
 #include <cstdlib>
 #include <cmath>
 
 using namespace std;
 
 struct Point{
     double x;
     double y;
     double z;
     Point(double x = 0, double y = 0, double z = 0):x(x),y(y),z(z){}
     Point operator % (const Point &p) const{
         return Point(y*p.z - z*p.y, z*p.x-x*p.z, x*p.y-y*p.x);
     }
     
 };
 int fireflies;
 Point ini;
 Point centerOfMass;
 
 void process(){
     scanf("%d", &fireflies);
     ini = Point(0,0,0);
     centerOfMass = Point(0,0,0);
     double sumX = 0,sumY = 0,sumZ = 0;
     for(int i = 0; i < fireflies; i++){
         double x,y,z,vx,vy,vz;
         scanf("%lf%lf%lf%lf%lf%lf", &x,&y,&z,&vx,&vy,&vz);
         centerOfMass.x += x;
         centerOfMass.y += y;
         centerOfMass.z += z;
         sumX += vx;
         sumY += vy;
         sumZ += vz;
     }
     centerOfMass.x /= fireflies;
     centerOfMass.y /= fireflies;
     centerOfMass.z /= fireflies;
     Point dir(sumX,sumY,sumZ);
     double sX = sumX;
     double sY = sumY;
     double sZ = sumZ;
     double root = sqrt(sumX*sumX+sumY*sumY+sumZ*sumZ);
     dir.x /= root;
     dir.y /= root;
     dir.z /= root;
     Point rev = centerOfMass;
     rev.x = -rev.x;
     rev.y = -rev.y;
     rev.z = -rev.z;
     Point smallest = rev % dir;
     printf(" %lf", sqrt(smallest.x*smallest.x + smallest.y*smallest.y + smallest.z*smallest.z));
     double time;
     if(sX == 0){
         if(sY == 0)
             if(sZ == 0)time = 0;
             else time = (smallest.z - centerOfMass.z)/(sZ/fireflies);
         else time = (smallest.y - centerOfMass.y)/(sY/fireflies);
     }else time = (smallest.x - centerOfMass.x)/(sX/fireflies);
     
     printf(" %lf\n", time);
 }
 int main(){
     freopen("B-small-attempt0.in", "r", stdin);
     freopen("small.out", "w", stdout);
     int casos;
     scanf("%d", &casos);
     for(int i = 1; i <= casos; i++){
         printf("Case #%d:", i);
         process();
     }
     return 0;
 }
