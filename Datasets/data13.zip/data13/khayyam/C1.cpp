#include <sstream>
 #include <string>
 #include <math.h>
 using namespace std;
 #define LL long long
 
 bool isPalindrome(LL x){
 	ostringstream os;
 	os<<x;
 	string s=os.str();
 	int i=0;
 	int j=s.size()-1;
 	while(i<j){
 		if(s[i]!=s[j]){
 			return false;
 		}
 		++i;
 		--j;
 	}
 	return true;
 }
 
 
 LL pals[11000];
 int numPals;
 
 LL palSq[11000];
 int numPalSq;
 
 void initPals(void){
 	numPals=0;
 	for(int x=1;x<10000001;++x){
 		if(isPalindrome(x)){
 			pals[numPals]=x;
 			++numPals;
 		}
 	}
 	numPalSq=0;
 	for(int i=0;i<numPals;++i){
 		if(isPalindrome(pals[i]*pals[i])){
 			palSq[numPalSq]=pals[i]*pals[i];
 			numPalSq++;
 		}
 	}
 }
 
 int solve(int A, int B){
 	int sol=0;
 	for(int i=0;i<numPalSq;++i){
 		if((A<=palSq[i]) && (palSq[i]<=B)){
 			++sol;
 		}
 	}
 	return sol;
 }
 
 int main(int argc, char *argv[]){
 	initPals();
 	int T;
 	scanf("%d", &T);
 	for(int c=1;c<=T;++c){
 		int A, B;
 		scanf("%d%d", &A, &B);
 		int sol=solve(A, B);
 		printf("Case #%d: %d\n", c, sol);
 	}
 	return 0;
 }
