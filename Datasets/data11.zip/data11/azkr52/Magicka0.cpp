#include<stdio.h>
 #include<vector>
 
 using namespace std;
 int main()
 {
 	int n,n1,n2,n3,i,j,k,b,b2,l;
 	
 	scanf("%d",&n);
 	for(i=1;i<=n;i++)		
 	{
 		char v1[4],v2[4],v[12];
 		scanf("%d ",&n1);
 		if(n1) scanf("%s ",v1);
 		
 		scanf("%d ",&n2);
 		if(n2) scanf("%s ",v2);
 		
 		scanf("%d ",&n3);
 		scanf("%s\n",v);		
 		vector <char> vr;
 		vr.push_back(v[0]);
 		b2=j=k=1;
 
 		if(!n1 && !n2)
 		b2=0;
 		else
 		{			
 			while(j<n3)
 			{
 				b=1;
 				if(!n1 && n2)
 				{
 					if(b && k>0 && ((v[j]+vr[k-1]== v2[0]+v2[1])&& (v[j]==v2[1] || v[j]==v2[0]))){
 						vr.pop_back();
 						k--;
 						j++;
 						b=0;
 					}
 					if(b && k>1 && ((v[j]+vr[k-2]== v2[0]+v2[1])&& (v[j]==v2[1] || v[j]==v2[0]))){
 						k-=2;
 						vr.pop_back();
 						vr.pop_back();
 						j++;
 						b=0;
 					}
 			
 					if(b)
 					{
 						vr.push_back(v[j]);
 						j++;
 						k++;
 					}
 				}
 				
 				if(n1 && !n2)
 				{
 					if(k>0 && ((v[j]+vr[k-1] == v1[0]+v1[1])&& (v[j]==v1[1] || v[j]==v1[0]))){
 						vr.pop_back();					
 						vr.push_back(v1[2]);
 						
 						j++;	
 					}
 			
 					else
 					{
 						vr.push_back(v[j]);
 						j++;
 						k++;
 					}
 				}
 
 				if(n1 && n2)
 				{
 					if(b==1 && ((v[j]+vr[k-1] == v1[0]+v1[1])&& (v[j]==v1[1] || v[j]==v1[0]))){
 						vr.pop_back();			
 						vr.push_back(v1[2]);
 						j++;
 						b=0;	
 					}
 
 					if(b==1 && k>0 && ((v[j]+vr[k-1]== v2[0]+v2[1])&& (v[j]==v2[1] || v[j]==v2[0]))){
 						vr.pop_back();
 						k--;
 						j++;
 						b=0;
 					}
 					if(b==1 && k>0 && ((v[j]+vr[k-2]== v2[0]+v2[1])&& (v[j]==v2[1] || v[j]==v2[0]))){
 						//printf("	problema aqui\n");
 						k -=2;
 						vr.pop_back();
 						vr.pop_back();
 						b=0;
 						j++;
 					}
 						
 					if(b==1)
 					{
 						vr.push_back(v[j]);
 						j++;
 						k++;
 					}
 				}
 			}		
 		}
 		printf("Case #%d: [",i);
 		if(b2)
 			for(j=0;j<k;j++){
 				if(j==k-1)				
 					printf("%c",vr[j]);
 				else
 					printf("%c, ",vr[j]);
 			}
 		else
 			for(j=0;j<n3;j++){
 					if(j==n3-1)				
 						printf("%c",v[j]);
 					else
 						printf("%c, ",v[j]);
 			}
 		printf("]\n");
 	}
 	return 0;
 }
