/* 2011
  * Maciej Szeptuch
  * XIV LO Wrocław
  */
 #include<cstdio>
 #include<algorithm>
 //#define DEBUG(args...) fprintf(stderr, args)
 #define DEBUG(args...)
 
 int tests,
 	size,
 	tab[1024],
 	result;
 bool did;
 
 int main(void)
 {
 	scanf("%d", &tests);
 	for(int t = 0; t < tests; ++ t)
 	{
 		scanf("%d", &size);
 		result = 0;
 		for(int s = 0; s < size; ++ s)
 		{
 			scanf("%d", &tab[s]);
 			-- tab[s];
 		}
 
 		do
 		{
 			did = false;
 			for(int s = 0; s < size; ++ s)
 			{
 				if(tab[s] != s)
 				{
 					result += 2;
 					std::swap(tab[s], tab[tab[s]]);
 					did = true;
 				}
 			}
 		}
 		while(did);
 
 		printf("Case #%d: %d\n", t + 1, result);
 	}
 	return 0;
 }
 
