#include <iostream>
 #include <vector>
 #include <map>
 #include <algorithm>
 #include <cassert>
 using namespace std;
 
 string s;
 int n;
 
 int solve() {
     vector< int > e;
     for (int i = 0, k = n; i < s.length(); i++)
         if (s[i] != 'a'
                 && s[i] != 'e'
                 && s[i] != 'i'
                 && s[i] != 'o'
                 && s[i] != 'u') {
             if (k != 0)
                 k--;
             if (k == 0) {
                 e.push_back(i);
                 //cerr << i << endl;
             }
         }
         else
             k = n;
     long long res = 0;
     for (int i = 0; i < s.length(); i++) {
         auto it = upper_bound(e.begin(), e.end(), i);
         if (it == e.begin())
             continue;
         it--;
         //cerr << i << " " << *it << endl;
         if (*it > i)
             continue;
         res += *it - n + 2;
     }
     return res;
 }
 
 int main() {
     int T;
     cin >> T;
     for (int i = 1; i <= T; i++) {
         cout << "Case #" << i << ": ";
         cin >> s >> n;
         cout << solve();
         cout << "\n";
     }
     return 0;
 }
