#include<stdio.h>
 using namespace std;
 int max;
 int ar[1001],n,t;
 void brute (int i, int s, int p, int o, bool a, bool b){
 	//printf(" %d %d %d %d\n", i,s,p,o);
 	if(i == n){
 		if(s == p && a && b)
 			max = (max>o)? max : o;
 	}
 	else{
 		brute(i+1, s ^ ar[i], p, o + ar[i], a+1, b);
 		brute(i+1, s, p ^ ar[i], o, a, b+1);
 	}
 }
 
 int main(){
 	scanf("%d",&t);
 	for(int I=1;I<=t;++I){
 		scanf("%d",&n);
 		for(int i=0;i<n;++i)
 			scanf("%d",&ar[i]);
 		max = -1;
 		brute(0,0,0,0,0,0);
 		
 		if(max == -1) printf("Case #%d: NO\n",I);
 		else printf("Case #%d: %d\n",I,max);
 	}
 	return 0;
 }
