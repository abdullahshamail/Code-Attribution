#include <iostream>
 #include <stdio.h>
 #include <vector>
 #include <set>
 #include <map>
 #include <queue>
 #include <algorithm>
 #include <string.h>
 #include <string>
 using namespace std;
 
 int i, j, k, n, m;
 long long r, res;
 int t, T;
 char a[15][15];
 int b[15], c[15];
 
 int main() {
 	freopen("C-small-attempt0.in", "r", stdin);
 	freopen("C-small-attempt0.out", "w", stdout);
 
 	cin >> T;
 	for (t = 1; t <= T; t ++) {
 		cin >> m >> n;
 		memset(a, 0, sizeof(a));
 		for (i = 0; i < m; i ++) {
 			cin >> a[i];
 		}
 
 		res = 0;
 		for (i = 0; i < (1 << n); i ++) {
 			r = 0;
 			memset(b, 0, sizeof(b));
 			for (j = 0; j < n; j ++) {
 				if (i & (1 << j)) {
 					if (a[0][j] == 'x') {
 						break;
 					}
 					if (j > 0) {
 						if (i & (1 << (j - 1))) {
 							break;
 						}
 					}
 					if (i & (1 << (j + 1))) {
 						break;
 					}
 					b[j] = 1;
 					r ++;
 				}
 			}
 			if (j < n) {
 				continue;
 			}
 			for (j = 1; j < m; j ++) {
 				for (k = 0; k < n; k ++) {
 					if (a[j][k] == 'x') {
 						continue;
 					}
 					if (k > 0) {
 						if (b[k-1] == 0 && c[k-1] == 0 && b[k+1] == 0) {
 							c[k] = 1;
 							r ++;
 						}
 					} else {
 						if (b[k+1] == 0) {
 							c[k] = 1;
 							r ++;
 						}
 					}
 				}
 				for (k = 0; k < n; k ++) {
 					b[k] = c[k];
 					c[k] = 0;
 				}
 			}
 			if (r > res) {
 				res = r;
 			}
 		}
 		cout << "Case #" << t << ": " << res << endl;
 	}
 	return 0;
 }
 
 
 
 
