#include <cstdio>
 #include <iostream>
 #include <algorithm>
 #include <vector>
 #include <map>
 #include <numeric>
 using namespace std;
 
 FILE * in=fopen("in1.txt","r");
 FILE * out=fopen("out1.txt","w");
 
 int T;
 int grid[550][550];
 int dx[4]={-1,0,1,0}, dy[4]={0,-1,0,1}; //W,N,W,S
 void ff(int x, int y) {
     if( grid[y][x]!=0 ) return;
     grid[y][x]=2;
 
     for( int i=0; i<4; i++ ) {
         if(y+dy[i]>=99 && y+dy[i]<=301 && x+dx[i]>=99 && x+dx[i]<=301 && grid[y+dy[i]][x+dx[i]]==0) {
             ff(x+dx[i],y+dy[i]);
         }
     }
 }
 
 
 int main() {
     fscanf(in,"%d",&T);
     for( int test=1; test<=T; test++ ) {
         int L;
         string moves;
         cout << test << endl;
 
         for( int i=0; i<350; i++ ) for( int j=0; j<350; j++ ) grid[i][j]=0;
         fscanf(in,"%d",&L);
         grid[200][200] = true;
         for( int i=0; i<L; i++ ) {
             char buf[100];
             int m;
             fscanf(in,"%s %d",buf,&m);
             string t=buf;
             for( int k=0; k<m; k++ ) moves+=t;
         }
 
 
         int curX=200, curY=200, curD=1;
         for( int i=0; i<moves.size(); i++ ) {
             if( moves[i]=='F' ) {
                 curX+=dx[curD]; curY+=dy[curD];
                 grid[curY][curX] = 1;
                 //cout << curX << " " << curY << endl;
             }
             else if( moves[i]=='L' ) {
                 curX+=dx[curD]; curY+=dy[curD];
                 grid[curY][curX] = 1;
                 curD=(curD+3)%4;
                 //curY+=dy[curD]*-1, curX+=dx[curD]*-1;
 
             }
             else {
                 curD=(curD+1)%4;
                 curY+=dy[curD]*-1, curX+=dx[curD]*-1;
             }
         }
 
         ff(99,99);
         for( int i=100; i<301; i++ ) {
             for( int j=100; j<301; j++ ) {
                 if( grid[i][j]==0 ) grid[i][j]=1;
             }
         }
 
 
 
         int ans=0;
         for( int i=100; i<301; i++ ) {
             for( int j=100; j<301; j++ ) {
                 if( grid[i][j]!=2 ) continue;
                 bool xOk=false, xOk2=false, yOk=false, yOk2=false;
                 for( int k=j-1; k>=100; k-- ) {
                     if( grid[i][k]==1 ) {
                         xOk=true; break;
                     }
                 }
                 for( int k=j+1; k<301; k++ ) {
                     if( grid[i][k]==1 ) {
                         xOk2=true; break;
                     }
                 }
                 for( int k=i+1; k<301; k++ ) {
                     if( grid[k][j]==1 ) {
                         yOk=true; break;
                     }
                 }
                 for( int k=i-1; k>=100; k-- ) {
                     if( grid[k][j]==1 ) {
                         yOk2=true; break;
                     }
                 }
                 if(yOk&&yOk2||xOk&&xOk2) {
                     ans++;
                 }
 
             }
         }
 
 
         fprintf(out,"Case #%d: %d\n",test,ans);
 
     }
 
     return 0;
 }
