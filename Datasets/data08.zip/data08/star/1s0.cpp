#include<iostream>
 #include<algorithm>
 
 
 int main()
 {
 	freopen("A-small-attempt0.in" , "r" , stdin);
 	freopen("A-small-attempt0.out" , "w" , stdout);
 	int x[8] , y[8] , t , n , i , ca = 1 , ans;
 	scanf("%d" , &t);
 	while(t--)
 	{
 		scanf("%d" , &n);
 		for( i = 0 ; i < n ; i++ )
 			scanf("%d" , &x[i]);
 		for( i = 0 ; i < n ; i++ )
 			scanf("%d" , &y[i]);
 		std::sort( x , x + n );
 		std::sort( y , y + n );
 		ans = 0;
 		for( i = 0 ; i < n ; i++)
 			ans += x[i] * y[n-i-1];
 		printf("Case #%d: %d\n",ca,ans);
 		ca++;
 	}
 
 }