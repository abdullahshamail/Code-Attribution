/*
  * Qualify-B
  * CodeJam
  *
  *  Created on: 11th Apr '15
  *      Author: sparks
  */
 #include <bits/stdc++.h>
 #define make_it_fast ios_base::sync_with_stdio(0);cin.tie(0);
 
 using namespace std;
 
 typedef long long int ll;
 typedef unsigned long long ull;
 
 class TimeTracker {
   clock_t start, end;
 public:
   TimeTracker() { start = clock(); }
   ~TimeTracker() { end = clock(); fprintf(stderr, "RunTime : %.3lf s\n", (double)(end - start) / CLOCKS_PER_SEC); }
 };
 
 #define ff first
 #define ss second
 #define pb push_back
 #define mkp make_pair
 #define mt make_tuple
 #define pll pair<ll, ll>
 #define loop(i, begin, end) for(__typeof(end) i=(begin)-((begin)>(end)); i!=(end)-((begin)>(end)); i+=1-2*((begin)>(end)))
 #define rep(i,n) for(i=0;i<n;i++)
 #define all(v) v.begin(), v.end()
 #define db(args...) { vector<string> _v = split(#args, ','); debug_fn(_v.begin(), args); }
 #define dbp(p) cerr << #p << " = " << '(' << p.ff << ',' << p.ss << ") " << endl;
 #define dbn(A,N) for(int __I=0; __I<N; __I++) cerr << A[__I] << " \n"[__I==(N-1)];
 #define dbnm(A,N,M) for(int __I=0; __I<N; __I++) { for(int __J=0; __J<M; __J++) cerr << A[__I][__J] << " \n"[__J==(M-1)]; }
 #define dbv(v) for(auto __Velem : v) cerr << __Velem << ' '; cerr << endl;
 #define dbvp(v) for(auto __Velem : v) cerr << '(' << __Velem.ff << ',' << __Velem.ss << ") " ; cerr << endl;
 
 vector<string> split(const string& s, char c) 
 {
   vector<string> v; stringstream ss(s); string x;
   while (getline(ss, x, c)) v.push_back(x);
   return v;
 }
 
 void debug_fn(vector<string>::iterator it) {}
 template<typename T, typename... Args>
 void debug_fn(vector<string>::iterator it, T a, Args... args) 
 {
   cerr << it -> substr((*it)[0] == ' ', it -> length()) << " = " << a << '\n';
   debug_fn(++it, args...);
 }
 
 # define getcx getchar_unlocked
 
 void inp() {}
 template <typename T, typename... Args>
 void inp(T& n, Args&... args)//fast input function
 {
   int ch=getcx(), sign=1; n=0;
   while( ch < '0' || ch > '9' ) { if(ch=='-')sign=-1; ch=getcx(); }
   while( ch >= '0' && ch <= '9' ) n = (n<<3)+(n<<1) + ch-'0', ch=getcx();
   n=n*sign; inp(args...);
 }
 
 void oup() {}
 template <typename T, typename... Args>
 void oup(T x, Args... args)
 { 
   if(x<0){ putchar('-'); x=-x; } int len=0,data[25];
   while(x) { data[len++]=x%10; x/=10; } if(!len) data[len++]=0;
   while(len--) putchar(data[len]+48); putchar('\n'); oup(args...);
 }
 
 #define N 1010
 
 map<string, ll> solMap;
 ll solve(string s)
 {
   sort(s.begin(), s.end());
   while(*(s.begin()) == '0')
     s.erase(s.begin());
 
   if(s.length() == 0)
     return 0;
 
   if ( solMap[s] )
     return solMap[s];
 
   // cout << "solve ( " << s << " ) " << endl;
 
   ll sol = 100;
   ll i, mx = -1, mxi = -1;
 
   mx = s[s.length() - 1] - '0';
   mxi = s.length() - 1;
 
   if( (s[mxi] - '0') % 2 == 0 )
   {
     s[mxi] = '0' + (s[mxi] - '0')/2 ;
     sol = min( sol, 1 + solve(string(s).append(1, s[mxi])) );
     s[mxi] = '0' + 2 * (s[mxi] - '0') ;
 
     if ( mxi > 0 and (s[mxi] - '0') > 1 + (s[0] - '0') + (s[mxi] - '0')/2 )
     {
       s[mxi] = '0' + (s[mxi] - '0')/2 ;
       s[0] = '0' + (s[0] - '0') + (s[mxi] - '0');
       sol = min( sol, 1 + solve(s) );
       s[0] = '0' + (s[0] - '0') - (s[mxi] - '0');
       s[mxi] = '0' + 2 * (s[mxi] - '0') ;    
     }
   }
 
   rep(i, s.length())
   {
     s[i] = '0' + (s[i] - '0' - 1);
   }
 
   sol = min(sol, 1 + solve(s));
 
   return solMap[s] = min(mx, sol);
 }
 
 int main()
 {
   // make_it_fast
   #ifdef LOCAL
     freopen("in", "r", stdin);
     freopen("out", "w", stdout);
     TimeTracker trk;
   #endif
 
   ll t, tp;
   ll n, i, j;
   string s;
 
   inp(t);
 
   for(tp = 1; tp <= t; tp++)
   { 
     s.clear();
 
     inp(n);
     rep(i, n) 
     {
       inp(j);
       s.pb(j + '0');
     }
 
     cout << "Case #" << tp << ": " << solve(s) << endl;
   }
   return 0;
 }