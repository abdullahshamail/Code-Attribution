#include<iostream>
 #include <iomanip>
 #include<vector>
 #include<set>
 #include<map>
 
 using namespace std;
 typedef map<long long, long long> PVMap;
 typedef vector<long long> LongVec;;
 
 #define NP '.'
 #define WON '1'
 #define LOST '0'
 
 int main()
 {
     int T;
     cin >> T;
    
     for(int n =0; n<T; ++n)
     {
        long long C,D;
        PVMap init;
        cin >> C >> D;
        
        long long minp, maxp;
        long long totalvendors = 0;
        for(int i =0; i< C; ++i)
        {
            long long p,v;
            cin >> p >> v;
            if(i==0)
              minp = maxp = p;
            else
            {
                if(minp>p) minp = p;
                if(maxp<p) maxp = p;
            }
            init[p] = v; 
            totalvendors += v;   
        }
        
        long double rangebefore = maxp - minp;
        long double rangeafter = (totalvendors) * D;
        long double t = (rangebefore -  rangeafter)/2.0 ;
        if(rangebefore < rangeafter)
        {
            t = -1* t;
        }
        cout << "Case #" <<n+1<<": "<< t <<"\n";
     
     }
     
 }
