#include <stdio.h>
 #include <iostream.h>
   int main()
 	{
 	long T,I,i,x,n,a[10],b[10],j,p;
 	scanf("%ld",&T);
 	for(I=1;I<=T;I++)
 	  {
 	  printf("Case #%ld: ",I);
 	  scanf("%ld",&n);
 	  x=n;
 	  memset(a,0,sizeof(a));
 	  while(x)
 		{
 		a[x%10]++;
 		x/=10;
 		}
 	  p=1;
 	  for(i=n+1;p;i++)
 		{
 		x=i;
 		p=0;
 		memset(b,0,sizeof(b));
 		while(x)
 		  {
 		  b[x%10]++;
 		  x/=10;
 		  }
 		for(j=1;j<10;j++)
 		  if(a[j]!=b[j]) {
 						 p=1;
 						 break;
 						 }
 		}
 	  printf("%ld\n",i-1);
 	  }
 	}
