#include <iostream>
 #include <stdio.h>
 #include <string.h>
 
 using namespace std;
 
 int n, m;
 int le[128], ri[128];
 int sum;
 
 int getSum(int k) {
     return (k * (k + 1)) / 2;
 }
 
 void read() {
     int a, b, c;
     memset(le, 0, sizeof(le));
     memset(ri, 0, sizeof(ri));
 
     scanf("%d %d", &n, &m);
     sum = 0;
     for(int i = 0; i < m; i ++) {
         scanf("%d %d %d", &a, &b, &c);
         le[a] += c;
         ri[b] += c;
         sum += c * getSum(b - a - 1);
     }
 }
 
 void solve() {
     int ans = 0;
     while(1) {
         int pos = -1;
         for(int i = 1; i <= n; i ++)
             if(ri[i]) {
                 pos = i;
                 break;
             }
         if(pos == -1) break;
         for(int i = pos; i >= 1; i --)
             if(le[i]) {
                 le[i] --;
                 ri[pos] --;
                 ans += getSum(pos - i - 1);
                 break;
             }
     }
     cout << ans - sum << endl;
 }
 
 int main()
 {
     int t;
     scanf("%d", &t);
     for(int i = 1; i <= t; i ++) {
         printf("Case #%d: ", i);
         read();
         solve();
     }
 
     return 0;
 }
