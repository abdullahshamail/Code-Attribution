#include<iostream>
 #include<cstring>
 #include<vector>
 #include<map>
 #include<algorithm>
 #include<cmath>
 #include<cctype>
 #include<bitset>
 #include<queue>
 #include<ctime>
 using namespace std;
 
 typedef long long int64;
 
 const int maxn=111;
 const int maxm=257;
 int a[maxn],f[maxn][maxm];
 int tot,n,m,d,l,ans;
 
 void init()
   {
    scanf("%d%d%d%d",&d,&l,&m,&n);     
    for (int i=0;i<n;i++) scanf("%d",&a[i]);   
   }
   
 void solve()
   {
    memset(f,127,sizeof(f));
    f[0][256]=d;f[0][a[0]]=0;
    for (int i=0;i<maxm-1;i++) f[0][i]=min(f[0][i],abs(a[0]-i));
    for (int i=1;i<n;i++)
      {
       for (int j=0;j<maxm;j++)
         {
          f[i][j]=min(f[i][j],f[i-1][j]+d);
          if (j==256 || abs(a[i]-j)<=m) f[i][a[i]]=min(f[i][a[i]],f[i-1][j]);
          if (j!=256 && m!=0) f[i][a[i]]=min(f[i][a[i]],f[i-1][j]+l*(max(0,abs(a[i]-j)-1)/m));
          for (int k=max(j-m,0);k<=min(j+m,255);k++)
            f[i][k]=min(f[i][k],f[i-1][j]+abs(k-a[i]));
         }
       //for (int j=0;j<maxm;j++) printf("%d %d %d\n",i,j,f[i][j]);
      } 
    ans=1<<30;
    for (int j=0;j<maxm;j++)
      ans=min(ans,f[n-1][j]);
   }
   
 int main()
   { 
    //freopen("smooth.in","r",stdin);
    //freopen("smooth.out","w",stdout);
    scanf("%d",&tot);
    for (int tt=1;tt<=tot;tt++)
      {
       init();
       solve();
       printf("Case #%d: %d\n",tt,ans);
      }
    return 0;
   }
