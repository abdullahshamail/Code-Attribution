#include <iostream>
 using namespace std;
 
 /* Driver program to test above functions */
 int main()
 {
     int t,k =0;
 freopen("in.txt", "r", stdin);
  
 freopen("out.txt", "w", stdout);
     scanf("%d",&t);
     // while loop starts here
     while(t--)
     {
         k++;
         int p[1001];
         for(int i=0;i<=1000;i++)
             p[i]=0;
         int d,a;
         scanf("%d",&d);
         int max=0;
         for(int i=0;i<d;i++)
         {
             scanf("%d",&a);
             p[a]++;
             if(max<a)
                 max=a;
         }
         int min=0;
         int i,j,added=0;
         int time=1001;
         bool f=false;
         for(i=max;i>2;i--)
         {
           
             if(time>i+min)
                 time=i+min;
             f=false;
             if(p[i]>0)
             {
                 for(j=i-1;j>2;j--)
                 {
                     if(p[j]>0)
                     {
                         f=true;
                         break;
                     }
                 }
                
                if(f==true)
                {
                   
                    int z=1,bs,left;
                    while(1)
                    {
                        z++;
                        left=i%z;
                        if(left==0)
                            bs=i/z;
                        else
                            bs=(i/z)+1;
                        
                        left=i%bs;
                        
                        int z1=z+1;
                        int left1,bs1;
                        left1=i%z1;
                        if(left1==0)
                            bs1=i/z1;
                        else
                            bs1=i/z1;
                        left1=i%bs;
                        
                        if(bs1+((z1-1)*p[i])<bs+(p[i]*(z-1))&&(j>=bs1)&&(bs>j))
                        {
                            bs=bs1;
                            left=left1;
                            z=z1;
                        }
                        if(j>=bs||j>=bs-2)
                        {
                            min+=(z-1)*p[i];
                            if(bs>=j)
                            added=min+bs;
                            else
                                added=min+j;
                            if(left==0)
                            {
                                p[bs]+=z*p[i];
                                break;
                            } // if left=0 ends here
                            else
                            {
                                p[bs]+=(z-1)*p[i];
                                p[left]+=p[i];
                            }
                            break;
                        }// if for ending while ends here
                        
                    }// while(1) ends here
                } /// if f== true ends here
                 
                 // else for no j found
                 else
                 {
                     int minimum=i;
                     int z=2,left,bs;
                     left=i%z;
                     if(left==0)
                         bs=i/z;
                     else
                         bs=(i/z)+1;
                     
                     left=i%bs;
                     
                     int z1=z+1;
                     int left1,bs1;
                     left1=i%z1;
                     if(left1==0)
                         bs1=i/z1;
                     else
                         bs1=i/z1+1;
                     left1=i%bs;
                     
                     if(bs1+((z1-1)*p[i])<bs+(p[i]*(z-1)))
                     {
                         bs=bs1;
                         left=left1;
                         z=z1;
                     }
 
                     
                     
                     if(bs+((z-1)*(p[i]))<=minimum)
                     {
                         min+=(z-1)*p[i];
                         added=bs+min;
                         if(left==0)
                         {
                             p[bs]+=z*p[i];
                         } // if left=0 ends here
                         else
                         {
                             p[bs]+=(z-1)*p[i];
                             p[left]+=p[i];
                         }
 
                     }
                     else
                     {
                     while(1)
                     {
                         z++;
                         left=i%z;
                         if(left==0)
                             bs=i/z;
                         else
                             bs=(i/z)+1;
                         left = i%bs;
                         if(bs+(z-1)>=minimum)
                         {
                             
                             
                             {
                                 z--;
                                 if(left==0)
                                     bs=i/z;
                                 else
                                     bs=(i/z)+1;
                                 
                                 min+=(z-1)*p[i];
                                 added=min+bs;
                                 if(left==0)
                                 {
                                     p[bs]+=z*p[i];
                                 } // if left=0 ends here
                                 else
                                 {
                                     p[bs]+=(z-1)*p[i];
                                     p[left]+=p[i];
                                 }
                             
                                 break;
                             }
                             break;
                         } // if bs>=minimum ends here
                          //elsefirst=false;
                         minimum=bs+(z-1);
                     }
                     }
                 }
                 if(time>added)
                     time=added;
             }// if p[i]>0 ends  here
         }// for loop ends here
         
         if(max<3)
         {
         if(time>2+min)
         {
             time=2+min;
             min+=p[2];
         }
         if(time>1+min)
             {
                 time=1+min;
             }
         }
         
             
         printf("Case #%d: %d\n",k,time);
     }// while ends
     return 0;
 }