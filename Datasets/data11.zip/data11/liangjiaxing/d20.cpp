#include<stdio.h>
 #include<string.h>
 #include<algorithm>
 #include<vector>
 using namespace std;
 double dp[1001];
 
 int main(){
 	int i, j, k, m, n, cas;
 	freopen("D-small-attempt1.in", "r", stdin);
 	freopen("w.txt", "w", stdout);
 /*
 	memset(dp, 0, sizeof(dp));
 	dp[1] = 0;
 	double fact = 1;
 	for(i = 2; i <= 10; i++){
 		vector<int> a;
 		double tmp = 0;
 		
 		fact *= i;
 		for(j = 0; j < i; j++)
 			a.push_back(j);
 		do{
 			vector<int> ans;
 			int v[20] = {0};
 			//for(j = 0; j < a.size(); j++) printf("(%d)", a[j]); puts("");	
 			for(j = 0; j < i; j++){
 				int u = 0;
 				int next = j;
 				while(!v[next]){
 					u++;
 					v[next] = 1;
 					next = a[next];
 				}
 				ans.push_back(u);
 				if(u < i) tmp += dp[u];
 			}
 			//for(j = 0; j < ans.size(); j++)printf("%d ", ans[j]); puts("");
 		}while(next_permutation(a.begin(), a.end()));
 		//printf("%.15lf\n", tmp);
 		dp[i] = fact / (fact + 1 - i) * (tmp / fact + 1);
 		printf("%.15lf,\n", dp[i]);
 	}
 */
 	for(i = 2; i <= 10; i++)
 		dp[i] = i;
 	scanf("%d", &cas);
 	for(int ri = 1; ri <= cas; ri++){
 		printf("Case #%d: ", ri);
 		scanf("%d", &n);
 		vector<int> a, b;
 		for(i = 0; i < n; i++){
 			scanf("%d", &k);
 			a.push_back(k);
 		}
 		b = a;
 		sort(b.begin(), b.end());
 		for(i = 0; i < n; i++){
 			for(j = 0; j < n; j++)
 				if(a[i] == b[j])
 					a[i] = j;
 		}
 		double tmp = 0;
 		int v[20] = {0};
 		for(j = 0; j < n; j++){
 			int u = 0;
 			int next = j;
 			while(!v[next]){
 				u++;
 				v[next] = 1;
 				next = a[next];
 			}
 			tmp += dp[u];
 		}
 		printf("%.15lf\n", tmp);
 	}
 	scanf("%*d");
 }
