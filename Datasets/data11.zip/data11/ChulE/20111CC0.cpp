//////////////////
 // chul-e		//
 // CoconutLabs.	//
 //////////////////
 
 
 #include "stdafx.h"
 #include <string>
 #include <vector> 
 #include <map>
 #include <algorithm>
 
 using namespace std;
 
 /// 
 FILE*	fIN;
 FILE*   fOUT;
 
 ///Է 
 int TEST; //׽Ʈ 
  
 int N;
 long L;
 long H;
 
 ///Է  
 #define N_MAX 1000
 #define N_MIN 0
 #define M_MAX 1000
 #define M_MIN 0
 
 
 long long Others[100];
 long long OthersBuf[100];
 
 //ִ ϴ Ŭ 
 long get_gcd_modulus(long u, long v)
 {
 	long temp;
 	while(v != 0)
 	{
 		u = u%v;
 		temp = v;
 		v = u;
 		u = temp;
 		 
 	}
 
 	return u;
 }
 
 int _tmain(int argc, _TCHAR* argv[])
 {
 	fIN = fopen("in.txt","rb");
 	fOUT = fopen("out.txt","w");
 	
  
 	 
 	fscanf(fIN, "%d", &TEST);
 
 
 	for(int t = 1; t <= TEST; t++)
 	{
 
 		fscanf(fIN, "%d", &N); 
 		fscanf(fIN, "%d", &L);
 		fscanf(fIN, "%d", &H);
 
 		bool bbb = false;
 		for(int i = 0; i < N; i++)
 		{
 			int other;
 		 	fscanf(fIN, "%d", &other);
 			Others[i] = other;
 			OthersBuf[i] = other;
 
 			if(i > 0)
 			{
 			if(count(Others, Others + i - 1, other) != 0)
 			{
 							fprintf(fOUT,"Case #%d: NO\r\n",t);
 							bbb = true;
 							break;
 			}
 			}
 
 		} 
 
 		if(bbb)
 			continue;
 
 		sort(Others, Others + N);
 		sort(OthersBuf, OthersBuf + N);
 
 		long lcm = 0;
 
 		for(int i = 0; i < N - 1; i++)
 		{
 			int gcd = get_gcd_modulus(OthersBuf[i], OthersBuf[i+1]);
 
 			lcm = (OthersBuf[i] * OthersBuf[i+1])/gcd;
 
 			OthersBuf[i+1] = lcm;
 
 		}
 
 		bool bFound = false;
 		for(int i = L; i <= H ;i++)
 		{
 			if(i > lcm)
 			{
 				if(count(Others, Others + N, i) == 0)
 				{
 					if(lcm != 0)
 					{
 						
 					if((i%lcm) == 0)
 					{
 					lcm = i;
 					bFound = true;
 					break;
 
 					}
 					}
 				}
 
 			}
 		  
 		}
 
 		if(bFound)
 		{
 			fprintf(fOUT,"Case #%d: %d\r\n",t, lcm);
 		}
 		else
 		{
 
 			OthersBuf[N -2]; // ū  ּ 
 
 			bool bTrue = false;
 			long sol = -1;
 
 			for(int i = L; i <= H ;i++)
 			{
      			long gcd = get_gcd_modulus(i, OthersBuf[N -2]);
 				lcm = (i * OthersBuf[N -2])/gcd;
 
 				if(lcm != 0)
 				{
 				if((Others[N -1] % lcm) == 0)
 				{
 					if(count(Others, Others + N, i) == 0)
 					{
 						sol = i;
 						break;
 					}
 				} 
 				}
 			}
 
 			if(sol != -1)
 			{
 				fprintf(fOUT,"Case #%d: %d\r\n",t, sol);
 			}
 			else
 				fprintf(fOUT,"Case #%d: NO\r\n",t);
 		}
 	 
 
 		 
 
 
 	}
 
 
 	fclose(fIN);
 	fclose(fOUT);
 
 	return 0;
 }
 
