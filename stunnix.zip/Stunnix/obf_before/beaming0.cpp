#include <cstdio>
 #include <algorithm>
 #include <queue>
 #include <vector>
 using namespace std;
 
 char grid[55][55];
 char ans[55][55];
 bool ud[55][55];
 bool lr[55][55];
 
 vector<pair<pair<int,int>,int> > imp[55][55][2];
 bool v[55][55][2];
 
 void dfs(int x, int y, int n){
     v[x][y][n] = true;
     for (vector<pair<pair<int,int>,int> >::iterator i = imp[x][y][n].begin(); i != imp[x][y][n].end(); i++){
         if (!v[i->first.first][i->first.second][i->second]){
             dfs(i->first.first,i->first.second,i->second);
         }
     }
 }
 
 int main(){
     freopen("C-small-attempt1 (1).in", "r", stdin);
     freopen("Csmallout2.out","w",stdout);
     int T;
     scanf("%d", &T);
     for (int t = 1; t <= T; t++){
         int R, C;
         scanf("%d %d", &R, &C);
         for (int i = 1; i <= R; i++){
             scanf(" %s", grid[i]+1);
             for (int j = 1; j <= C; j++){
                 ud[i][j] = lr[i][j] = true;
             }
         }
         bool poss = true;
         for (int i = 1; i <= R; i++){
             for (int j = 1; j <= C; j++){
                 if (grid[i][j]=='-'||grid[i][j]=='|'){
                     bool good = true;
                     int x = i, y = j;
                     int dx = -1, dy = 0;
                     while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                         x += dx;
                         y += dy;
                         if (grid[x][y]=='/'){
                             int t = dx;
                             dx = dy;
                             dy = dx;
                             dx = -dx;
                             dy = -dy;
                         }
                         else if (grid[x][y]=='\\'){
                             int t = dx;
                             dx = dy;
                             dy = dx;
                         }
                         else if (grid[x][y]=='|'||grid[x][y]=='-'){
                             good = false;
                             break;
                         }
                     }
                     if (good){
                         x = i;
                         y = j;
                         dx = 1;
                         dy = 0;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 good = false;
                                 break;
                             }
                         }
                     }
                     if (!good) ud[i][j] = false;
                     good = true;
                     x = i, y = j;
                     dx = 0, dy = 1;
                     while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                         x += dx;
                         y += dy;
                         if (grid[x][y]=='/'){
                             int t = dx;
                             dx = dy;
                             dy = dx;
                             dx = -dx;
                             dy = -dy;
                         }
                         else if (grid[x][y]=='\\'){
                             int t = dx;
                             dx = dy;
                             dy = dx;
                         }
                         else if (grid[x][y]=='|'||grid[x][y]=='-'){
                             good = false;
                             break;
                         }
                     }
                     if (good){
                         x = i;
                         y = j;
                         dx = 0;
                         dy = -1;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 good = false;
                                 break;
                             }
                         }
                     }
                     if (!good){
                         lr[i][j] = false;
                     }
                     if (!lr[i][j]&&!ud[i][j]){
                         poss = false;
                         break;
                     }
                 }
                 if (!poss) break;
             }
             if (!poss) break;
         }
         for (int i = 1; i <= R; i++){
             for (int j = 1; j <= C; j++){
                 if (grid[i][j]!='-'&&grid[i][j]!='|') {
                     ans[i][j] = grid[i][j];
                     if (grid[i][j]=='.'){
                         bool du = false, rl = false;
                         int dux = 0, duy = 0, rlx = 0, rly = 0;
                         char dup = '\0', rlp = '\0';
                         int x = i, y = j;
                         int dx = -1, dy = 0;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (dux == 0 && duy == 0){
                                     dup = dx==0?'-':'|';
                                     du = true;
                                     dux = x;
                                     duy = y;
                                 }
                                 else {
                                     du = false;
                                     break;
                                 }
                             }
                         }
                         x = i;
                         y = j;
                         dx = 1;
                         dy = 0;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (dux == 0 && duy == 0){
                                     dup = dx==0?'-':'|';
                                     du = true;
                                     dux = x;
                                     duy = y;
                                 }
                                 else {
                                     du = false;
                                     break;
                                 }
                             }
                         }
                         x = i, y = j;
                         dx = 0, dy = 1;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (rlx == 0 && rly == 0){
                                     rlp = dx==0?'-':'|';
                                     rl = true;
                                     rlx = x;
                                     rly = y;
                                 }
                                 else {
                                     rl = false;
                                     break;
                                 }
                             }
                         }
                         x = i;
                         y = j;
                         dx = 0;
                         dy = -1;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (rlx == 0 && rly == 0){
                                     rlp = dx==0?'-':'|';
                                     rl = true;
                                     rlx = x;
                                     rly = y;
                                 }
                                 else {
                                     rl = false;
                                     break;
                                 }
                             }
                         }
                         if (du&&!rl){
                             if (dup=='-') ud[dux][duy] = false;
                             else lr[dux][duy] = false;
                         }
                         else if (rl&&!du){
                             if (rlp=='-') ud[rlx][rly] = false;
                             else lr[rlx][rly] = false;
                         }
                         else if (!du&&!rl){
                             poss = false;
                             break;
                         }
                         /*else {
                             int dun = dup=='-'?0:1;
                             int rln = rlp=='-'?0:1;
                             imp[dux][duy][1-dun].push_back(make_pair(make_pair(rlx,rly),rln));
                             imp[rlx][rly][1-rln].push_back(make_pair(make_pair(dux,duy),dun));
                         }*/
                     }
                 }
             }
         }
         for (int i = 1; i <= R; i++){
             for (int j = 1; j <= C; j++){
                 if (grid[i][j]!='-'&&grid[i][j]!='|') {
                     ans[i][j] = grid[i][j];
                     if (grid[i][j]=='.'){
                         bool du = false, rl = false;
                         int dux = 0, duy = 0, rlx = 0, rly = 0;
                         char dup = '\0', rlp = '\0';
                         int x = i, y = j;
                         int dx = -1, dy = 0;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (dux == 0 && duy == 0){
                                     dup = dx==0?'-':'|';
                                     du = true;
                                     dux = x;
                                     duy = y;
                                 }
                                 else {
                                     du = false;
                                     break;
                                 }
                             }
                         }
                         x = i;
                         y = j;
                         dx = 1;
                         dy = 0;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (dux == 0 && duy == 0){
                                     dup = dx==0?'-':'|';
                                     du = true;
                                     dux = x;
                                     duy = y;
                                 }
                                 else {
                                     du = false;
                                     break;
                                 }
                             }
                         }
                         x = i, y = j;
                         dx = 0, dy = 1;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (rlx == 0 && rly == 0){
                                     rlp = dx==0?'-':'|';
                                     rl = true;
                                     rlx = x;
                                     rly = y;
                                 }
                                 else {
                                     rl = false;
                                     break;
                                 }
                             }
                         }
                         x = i;
                         y = j;
                         dx = 0;
                         dy = -1;
                         while (x>=1&&x<=R&&y>=1&&y<=C&&grid[x][y]!='#'){
                             x += dx;
                             y += dy;
                             if (grid[x][y]=='/'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                                 dx = -dx;
                                 dy = -dy;
                             }
                             else if (grid[x][y]=='\\'){
                                 int t = dx;
                                 dx = dy;
                                 dy = dx;
                             }
                             else if (grid[x][y]=='|'||grid[x][y]=='-'){
                                 if (rlx == 0 && rly == 0){
                                     rlp = dx==0?'-':'|';
                                     rl = true;
                                     rlx = x;
                                     rly = y;
                                 }
                                 else {
                                     rl = false;
                                     break;
                                 }
                             }
                         }
                         if (du&&!rl){
                             if (dup=='-') ud[dux][duy] = false;
                             else lr[dux][duy] = false;
                         }
                         else if (rl&&!du){
                             if (rlp=='-') ud[rlx][rly] = false;
                             else lr[rlx][rly] = false;
                         }
                         else if (!du&&!rl){
                             poss = false;
                             break;
                         }
                         else if (ud[dux][duy]&&lr[dux][duy]&&ud[rlx][rly]&&lr[rlx][rly]) {
                             int dun = dup=='-'?0:1;
                             int rln = rlp=='-'?0:1;
                             imp[dux][duy][1-dun].push_back(make_pair(make_pair(rlx,rly),rln));
                             imp[rlx][rly][1-rln].push_back(make_pair(make_pair(dux,duy),dun));
                         }
                     }
                 }
             }
         }
         for (int i = 1; i <= R; i++){
             for (int j = 1; j <= C; j++){
                 if (grid[i][j]=='-'||grid[i][j]=='|'){
                     if (ud[i][j]&&!lr[i][j]) ans[i][j] = '-';
                     else if (lr[i][j]&&!ud[i][j]) ans[i][j] = '|';
                     else {
                         if (v[i][j][0]&&!v[i][j][1]) ans[i][j] = '|';
                         else if (v[i][j][1]&&!v[i][j][0]) ans[i][j] = '-';
                         else if (v[i][j][0]&&v[i][j][1]) poss = false;
                         else {
                             dfs(i,j,0);
                             if (v[i][j][1]) poss = false;
                             else ans[i][j] = '-';
                         }
                     }
                 }
                 else ans[i][j] = grid[i][j];
             }
         }
         if (poss){
             printf("Case #%d: POSSIBLE\n", t);
             for (int i = 1; i <= R; i++){
                 printf("%s\n",ans[i]+1);
             }
         }
         else printf("Case #%d: IMPOSSIBLE\n", t);
         for (int i = 1; i <= R; i++){
             for (int j = 1; j <= C; j++){
                 grid[i][j] = '\0';
                 ans[i][j] = '\0';
                 ud[i][j] = true;
                 lr[i][j] = true;
                 imp[i][j][0].clear();
                 imp[i][j][1].clear();
                 v[i][j][0] = false;
                 v[i][j][1] = false;
             }
         }
     }
 }
