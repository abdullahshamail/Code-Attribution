#include<stdio.h>
 #include<memory.h>
 #include<string.h>
 
 using namespace std;
 
 int n,m;
 
 int match(int tem)
 {
     int num(0);
     if(tem <= 10)
     return 0;
     if(tem > 10 && tem <= 100)
     {
         if(tem == 100)
         return 0;
         if(tem % 10 > tem / 10)
         {
             if((tem % 10)*10+(tem/10) <= m)
             return 1;
             else
             return 0;
         }
         else
         return 0;
         
     }
     if(tem > 100 && tem <= 1000)
     {
         if(tem == 1000)
         return 0;
         int tem1 = (tem % 10)*100 + (tem / 10);
         int tem2 = (tem % 100)*10 + (tem / 100);
         if(tem1 > tem && tem1 <= m)
         num++;
         if(tem2 > tem && tem2 <= m)
         num++;
         return num;
     }
     if(tem > 1001 && tem <= 10000)
     {
         if(tem == 10000)
         return 0;
         int tem1 = (tem%10)*1000 + (tem/10);
         int tem2 = (tem%100)*100 + (tem/100);
         int tem3 = (tem%1000)*10 + (tem/1000);
         if(tem1 > tem && tem1 < m)
         num++;
         if(tem2 > tem && tem2 < m)
         num++;
         if(tem3 > tem && tem3 < m)
         num++;
         return num;
     }
     if(tem > 10001 && tem <= 100000)
     {
         if(tem == 100000)
         return 0;
         int tem1 = (tem%10)*10000 + (tem/10);
         int tem2 = (tem%100)*1000 + (tem/100);
         int tem3 = (tem%1000)*100 + (tem/1000);
         int tem4 = (tem%10000)*10 + (tem/10000);
         if(tem1 > tem && tem1 < m)
         num++;
         if(tem2 > tem && tem2 < m)
         num++;
         if(tem3 > tem && tem3 < m)
         num++;
         if(tem4 > tem && tem4 < m)
         num++;
         return num;
     }
     if(tem > 100001 && tem <= 1000000)
     {
         if(tem == 1000000)
         return 0;
         int tem1 = (tem%10)*100000 + (tem/10);
         int tem2 = (tem%100)*10000 + (tem/100);
         int tem3 = (tem%1000)*1000 + (tem/1000);
         int tem4 = (tem%10000)*100 + (tem/10000);
         int tem5 = (tem%100000)*10 + (tem/100000);
         if(tem1 > tem && tem1 < m)
         num++;
         if(tem2 > tem && tem2 < m)
         num++;
         if(tem3 > tem && tem3 < m)
         num++;
         if(tem4 > tem && tem4 < m)
         num++;
         if(tem5 > tem && tem5 < m)
         num++;
         return num;
     }
     if(tem > 1000001 && tem <= 2000000)
     {
         if(tem == 1000000)
         return 0;
         int tem1 = (tem%10)*1000000 + (tem/10);
         int tem2 = (tem%100)*100000 + (tem/100);
         int tem3 = (tem%1000)*10000 + (tem/1000);
         int tem4 = (tem%10000)*1000 + (tem/10000);
         int tem5 = (tem%100000)*100 + (tem/100000);
         int tem6 = (tem%1000000)*10 + (tem/1000000);
         if(tem1 > tem && tem1 < m)
         num++;
         if(tem2 > tem && tem2 < m)
         num++;
         if(tem3 > tem && tem3 < m)
         num++;
         if(tem4 > tem && tem4 < m)
         num++;
         if(tem5 > tem && tem5 < m)
         num++;
         if(tem6 > tem && tem6 < m)
         num++;
         return num;
     }
 }
 int main()
 {
     
     char filename[32];
 	char infile[32], outfile[32];
 	scanf("%s", filename);
 	strcpy(infile, filename); strcpy(outfile, filename);
 	strcat(infile, ".in"); strcat(outfile, ".out");
 	FILE *fp=fopen(infile, "r"), *ofp=fopen(outfile, "w");
 	
 	int t;
 	//printf("OK\n");
 	fscanf(fp,"%d",&t);
 	//printf("OK\n");
 	for(int i=1;i <= t;i++)
 	{
         int ans = 0;
         fscanf(fp,"%d%d",&n,&m);
         for(int j = n;j <= m;j++)
         {
             ans += match(j);
         }
         fprintf(ofp, "Case #%d: %d\n", i, ans);
     }
     
     return 0;
 }
