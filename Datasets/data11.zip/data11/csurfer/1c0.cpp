#include<iostream>
 using namespace std;
 int primes[10001];
 unsigned long long hcf(unsigned long long a,unsigned long long b)
 {
 	if(a==0 || b==0)return 0;
 	if(a==1 || b==1)return 1;
 	unsigned long long nm,dm,rm;
 	
 	nm=0;
 	dm=(a>b)?a:b;
 	rm=(a+b)-dm;
 	while(rm!=0)
 	{
 		nm=dm;
 		dm=rm;
 		rm=nm%dm;
 	}
 	return dm;
 }
 
 int main()
 {
 	int tc,tbc;
 	cin>>tc;
 	tbc=tc;
 	
 	//init
 	for(int i=0;i<10001;i++)primes[i]=1;
 	primes[0] = primes[1] = 0;
 
 	for(int i=2;i<10001;i++)
 	{
 		if(primes[i]==1)
 		{
 			unsigned long j = i*i;
 			while(j<10001)
 			{
 				primes[j] = 0;
 				j += i;
 			}
 		}
 	}
 	
 	while(tc--)
 	{
 		unsigned long long n,l,h;
 		cin>>n>>l>>h;
 		unsigned long long har = 1;
 		for(int i=0;i<n;i++)
 		{
 			unsigned long long val;
 			cin>>val;
 			if(primes[val]==1)
 			{
 				unsigned long long hcomfac = hcf(val,har);
 				har = (val*har)/hcomfac;
 			}
 		}
 		
 		cout<<"Case #"<<tbc-tc<<": ";
 		if(har>=l && har<=h)
 			cout<<har<<endl;
 		else
 			cout<<"NO"<<endl;
 	}
 	return 0;
 }
