#include <cstdio>
 #include <cstdlib>
 #include <cstring>
 #include <cmath>
 #include <iostream>
 #include <algorithm>
 #include <ctime>
 
 using namespace std;
 
 
 int N, maxh[2005], a[2005];
 
 inline int	read()
 {
 	char ch = getchar(); int x = 0; bool flag = 0;
 	for (; ch != '-' && (ch < '0' || ch > '9'); ch = getchar());
 	if (ch == '-') 	{	flag = 1;	ch = getchar();	}
 	for (; ch >= '0' && ch <= '9'; ch = getchar()) x = x * 10 + ch - '0';
 	if (flag) return - x; return x;
 }
 
 inline bool	check(int x)
 {
 	long double max = (a[maxh[x]] - a[x]) * 1.0 / (maxh[x] - x);
 	for (int i = x + 1; i <= N; ++ i)
 		if ((a[i] - a[x]) * 1.0 / (i - x) > max)
 			return 0;
 	return 1;
 }
 
 bool	DFS(int x)
 {
 	if (!x)
 	{
 		for (int i = 1; i <= N; ++ i)	printf(" %d", a[i]);
 		printf("\n");
 		return 1;
 	}
 	for (int t = 1; t <= 7; ++ t)
 	{
 		a[x] = rand() % 100;
 		if (check(x))
 			if (DFS(x - 1))	return 1;
 	}
 	return 0;
 }
 
 inline void	Main()
 {
 	N = read();
 	for (int i = 1; i < N; ++ i)	maxh[i] = read();
 	if (!DFS(N))	printf(" Impossible\n");
 }
 
 int main()
 {
 	srand(time(0));
 	freopen("c.in", "r", stdin);
 	freopen("c.out", "w", stdout);
 	int T = read();
 	for (int t = 1; t <= T; ++ t)
 	{
 		printf("Case #%d:", t);
 		Main();
 	}
 	return 0;
 }
