#include <vector>
 #include <vector>
 #include <list>
 #include <map>
 #include <set>
 #include <deque>
 #include <queue>
 #include <stack>
 #include <bitset>
 #include <algorithm>
 #include <functional>
 #include <numeric>
 #include <utility>
 #include <string.h>
 #include <sstream>
 #include <iostream>
 #include <iomanip>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <ctime>
 using namespace std;
 
 #define MOD (1000000000+7) 
 #define INF 1000000000
 typedef long long  ll;
 typedef unsigned long long  ull;
 typedef pair<ll,ll> pii;
 
 ll t, n, m;
 ll dp[128][128];
 ll a[128], acnt[128], b[128], bcnt[128];
 
 ll mem(ll i, ll j)
 {
 	if(i < 1 || j < 1)
 		return 0;
 		
 	if(dp[i][j] != -1)
 		return dp[i][j];
 		
 	ll &ref = dp[i][j];
 	ref = 0;
 	
 	if(a[i] == b[j])
 	{
 		ll mehdi = min(acnt[i], bcnt[j]);
 		acnt[i] -= mehdi;
 		bcnt[j] -= mehdi;
 		
 		ll mx = 0;
 		mx = max( mx, mem(i-1, j) );
 		mx = max( mx, mem(i, j-1) );
 		mx = max( mx, mem(i-1, j-1) );
 		
 		ref = mehdi + mx;
 		
 		acnt[i] += mehdi;
 		bcnt[j] += mehdi;
 		
 		// for(int k = i-1; k >= 0; k --)
 			// ref = max(ref, mem(k, j));
 		// for(int k = j-1; k >= 0; k --)
 			// ref = max(ref, mem(i, k));
 			
 		
 	}
 	else
 	{
 		ref = max( mem(i-1, j), mem(i, j-1) );
 		
 		// for(int k = i-1; k >= 0; k --)
 			// ref = max(ref, mem(k, j));
 		// for(int k = j-1; k >= 0; k --)
 			// ref = max(ref, mem(i, k));
 	}
 	return ref;
 }
 
 int main()
 {
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
 
 	cin >> t;
 	for(int cas = 1; cas <= t; cas ++)
 	{
 		cin >> n >> m;
 		for(int i = 1; i <= n; i ++)
 			cin >> acnt[i] >> a[i];
 		for(int i = 1; i <= m; i ++)
 			cin >> bcnt[i] >> b[i];
 		
 		// for(int i = 0; i < a.size(); i ++)
 			// cout << a[i] << " ";
 		// cout << endl;
 		// for(int i = 0; i < b.size(); i ++)
 			// cout << b[i] << " ";
 		// cout << endl;
 		
 		memset(dp, -1, sizeof dp);
 		cout << "Case #" << cas << ": " << mem(n, m) << endl;
 		
 		// for(int i = 1; i <= n; i ++)
 		// {
 			// for(int j = 1; j <= m; j ++)
 			// {
 				// cout << setw(5) << dp[i][j];
 			// }
 			// cout << endl;
 		// }
 		
 	}
 	
 	return 0;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
