#include <iostream>
 #include <sstream>
 #include <cstdio>
 #include <cstdlib>
 #include <string>
 #include <queue>
 
 int main() {
 	std::freopen( "B-small-attempt0.in", "r", stdin );
 	std::freopen( "B-small-attempt0.out", "w", stdout );
 	int numCases;
 	std::cin >> numCases;
   for( int curCase = 1; curCase <= numCases; curCase++ ) {
 		std::priority_queue<int> plates;
 		int diners;
 		int time = 0;
 		std::cout << "Case #" << curCase << ": ";
 		std::cin >> diners;
 		for( int i = 0; i < diners; ++i ) {
 			int pancakes;
 			std::cin >> pancakes;
 			plates.push( pancakes );
 		}
 		while( plates.top() >= 4 + 2 * ( ((int) plates.size()) - 1 )) {
 			time += 1;
 			if( plates.top() % 2 != 0 ){
 				plates.push( ( plates.top() / 2 ) + 1);
 			}
 			else {
 				plates.push( plates.top() / 2 );
 			}
 			plates.push( plates.top() / 2 );
 			plates.pop();
 		}
 		time += plates.top();
 		if( curCase != numCases ){
 			std::cout << time << std::endl;
 		}
 		else {
 			std::cout << time;
 		}
 	}
 	return 0;
 }