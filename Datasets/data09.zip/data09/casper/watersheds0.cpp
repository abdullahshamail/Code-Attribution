#include<iostream>
 #include<algorithm>
 #include<sstream>
 #include<string>
 #include<vector>
 #include<cmath>
 #include<cstdio>
 #include<cstdlib>
 #include<fstream>
 #include<cassert>
 #include<numeric>
 #include<stack>
 #include<set>
 #include<map>
 #include<queue>
 #include<list>
 #include<deque>
 #include <algorithm>
 #include <string>
 #include <vector>
 #include <ctype.h>
 #include <math.h>
 
 
 using namespace std;
 
 
 typedef long long ll;
 
 typedef long long int64;
 typedef long double double64;
 typedef unsigned long long uint64;
 
 typedef vector<int> vi;
 typedef vector<string> vs;
 typedef pair<int, int> pii;
 typedef pair<ll, ll> pll;
 typedef pair<double, double> pdd;
 
 #define ALL(t) t.begin(),t.end()
 #define FOR(i,n) for (int i=0;i<(int)(n);i++)
 #define maxB 1000
 
 using namespace std;
 
 int main(){
 	freopen("B-small-attempt11.in","r",stdin);
 	//freopen("test.in","r",stdin);
 	
 	freopen("B-small-attempt11.out","w",stdout);
 	int N;
 	cin >> N;
 
 	FOR(testCase, N){
 		
 
 		int H, W;
 		int inp[100][100];
 		int solve[100][100];
 		int num[maxB];
 		FOR(i, maxB){
 			num[i] = i;
 		}
 
 		int count = 0;
 		memset(solve, 20000, sizeof(solve));
 		memset(solve, -1, sizeof(solve));
 		cin >> H >> W;
 		FOR(i, H){
 			FOR(j, W){
 				 cin >> inp[i][j];
 			}
 		}
 		FOR(i, H){
 			FOR(j, W){
 				int min = inp[i][j];
 				int minI, minJ;
 				if(i>0){
 					if(inp[i-1][j] < min){
 						min = inp[i-1][j];
 						minI = i-1;
 						minJ = j;
 					}
 				}
 				if(j>0){
 					if(inp[i][j-1] < min){
 						min = inp[i][j-1];
 						minI = i;
 						minJ = j-1;
 					}
 				}
 				if(j<W-1){
 					if(inp[i][j+1] < min){
 						min = inp[i][j+1];
 						minI = i;
 						minJ = j+1;
 					}
 				}
 				if(i<H-1){
 					if(inp[i+1][j] < min){
 						min = inp[i+1][j];
 						minI = i+1;
 						minJ = j;
 					}
 				}
 				if(solve[i][j] == -1){
 					if(min == inp[i][j]){
 						solve[i][j] = count++;
 					}
 					else{
 						if(solve[minI][minJ] == -1){
 							solve[minI][minJ] = count;
 							solve[i][j] = count++;
 						}
 						else{
 							solve[i][j] = solve[minI][minJ];
 						}
 					}
 				}
 				else{
 					if(min != inp[i][j]){
 						if(solve[minI][minJ] == -1){
 							solve[minI][minJ] = solve[i][j];
 						}
 						else{
 							if(num[solve[minI][minJ]] > num[solve[i][j]]){
 								num[solve[minI][minJ]] =solve[i][j];
 								for(int q= solve[minI][minJ]+1; q<maxB; q++){
 									num[q]--;
 								}
 								count--;
 								//cout << "error" << i << " " << j << " " << solve[i][j] << " " << minI << " " << minJ << " " << solve[minI][minJ] << endl;
 
 							}
 							else if(num[solve[minI][minJ]] < num[solve[i][j]]){
 								num[solve[i][j]] = solve[minI][minJ];
 								for(int q= solve[i][j]+1; q<maxB; q++){
 									num[q]--;
 								}
 								count--;
 								//cout << "error" << i << " " << j << " " << solve[i][j] << " " << minI << " " << minJ << " " << solve[minI][minJ] << endl;
 
 							}
 						}
 					}
 
 				}
 
 
 
 			}
 		}
 		cout << "Case #" << testCase+1 << ":" << endl;
 		FOR(i, H){
 			FOR(j, W){
 				if(j!=0) cout << " ";
 				cout << char( num[solve[i][j]] + 'a');
 			}
 			cout << endl;
 		}
 	}
 	
 	return 0;
 
 }
