#include <iostream>
 #include <vector>
 #include <queue>
 using namespace std;
 
 bool allZeros(const vector<int>&a) {
 	for(auto &x:a) if (x!=0) return false;
 	return true;
 }
 
 int main() {
 	int nCases; cin >> nCases;
 	for(int caseNum=1;caseNum<=nCases;caseNum++) {
 		int n; cin >> n;
 		vector<int>cakes;
 		int myMap[1010] = {0};
 		for(int i=0;i<n;i++) {
 			int num; cin >> num;
 			myMap[num]++;
 			cakes.push_back(num);
 		}
 		queue<pair<int,vector<int>> > que;
 		que.push(make_pair(0,cakes));
 
 		int ans = 2000000000;
 
 		while (!que.empty()) {
 			vector<int> temp = que.front().second; 
 			int depth = que.front().first; que.pop();
 
 			//for(int i=0;i<temp.size(); i++) cout << temp[i] << " ";
 			//cout<<endl;
 
 			if (allZeros(temp)) {ans = depth; break;}
 
 			int mx= 0;
 			int mxplace=-1;
 			for(int i=0;i<temp.size();i++) {
 				if(mx<temp[i]) {
 					mx=temp[i];
 					mxplace=i;
 				}
 			}
 			//cout << "mx " << mx << endl;
 			vector<int> newTemp=temp;
 			for(int i=0;i<newTemp.size();i++) {
 				if (newTemp[i]) newTemp[i]--;
 			}
 			que.push(make_pair(depth+1,newTemp));
 
 			temp.push_back(mx/2);
 			if (mx%2==0)
 				temp.push_back(mx/2);
 			else temp.push_back(mx/2+1);
 			temp.erase(temp.begin()+mxplace);
 
 			que.push(make_pair(depth+1,temp));
 
 		}
 		cout << "Case #"<<caseNum<<": "<<ans << endl;
 	}
 	return 0;
 }