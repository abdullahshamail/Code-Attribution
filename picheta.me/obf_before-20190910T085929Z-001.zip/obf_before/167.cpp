#include <bits/stdc++.h>
 using namespace std;
 int hd, ad, hk, ak, b, d;
 
 int main() {
 	int tc; scanf("%d", &tc);
 	for (int i=1; i<=tc; i++) {
 		scanf("%d%d%d%d%d%d", &hd, &ad, &hk, &ak, &b, &d);
 		int ans=-1;
 		int hdn=hd, adn=ad, hkn=hk, akn=ak;
 		int he,x;
 		for (int j=0; j<=200; j++) {
 			for (int k=0; k<=200; k++) {
 				if (k==0) he=hdn;
 				for (int v=0; v<=200; v++) {
 					if (v==0) {x=he; hkn=hk;}
 					if (hkn<=0) {
 						if (ans==-1) ans=j+k+v;
 						else ans=min(ans,j+k+v);
 						break;
 					}
 					if (x>akn || hkn<=adn) {
 						x-=akn;
 						hkn-=adn;
 					}
 					else x=hd-akn;
 				}
 				if (he>akn) {
 					adn+=b;
 					he-=akn;
 				}
 				else he=hd-akn;
 			}
 			if (hdn>akn-d) {
 				akn-=d;
 				akn=max(0,akn);
 				hdn-=akn;
 			}
 			else hdn=hd-akn;
 		}
 		printf("Case #%d: ", i);
 		if (ans==-1) printf("IMPOSSIBLE\n");
 		else printf("%d\n", ans);
 	}
 }
#include <bits/stdc++.h>
 using namespace std;
 int hd, ad, hk, ak, b, d;
 
 int main() {
 	int tc; scanf("%d", &tc);
 	for (int i=1; i<=tc; i++) {
 		scanf("%d%d%d%d%d%d", &hd, &ad, &hk, &ak, &b, &d);
 		int ans=-1;
 		int hdn=hd, adn=ad, hkn=hk, akn=ak;
 		int he,x;
 		for (int j=0; j<=200; j++) {
 			for (int k=0; k<=200; k++) {
 				if (k==0) he=hdn;
 				for (int v=0; v<=200; v++) {
 					if (v==0) {x=he; hkn=hk;}
 					if (hkn<=0) {
 						if (ans==-1) ans=j+k+v;
 						else ans=min(ans,j+k+v);
 						break;
 					}
 					if (x>akn || hkn<=adn) {
 						x-=akn;
 						hkn-=adn;
 					}
 					else x=hd-akn;
 				}
 				if (he>akn) {
 					adn+=b;
 					he-=akn;
 				}
 				else he=hd-akn;
 			}
 			if (hdn>akn-d) {
 				akn-=d;
 				akn=max(0,akn);
 				hdn-=akn;
 			}
 			else hdn=hd-akn;
 		}
 		printf("Case #%d: ", i);
 		if (ans==-1) printf("IMPOSSIBLE\n");
 		else printf("%d\n", ans);
 	}
 }
#include <bits/stdc++.h>
 using namespace std;
 int hd, ad, hk, ak, b, d;
 
 int main() {
 	int tc; scanf("%d", &tc);
 	for (int i=1; i<=tc; i++) {
 		scanf("%d%d%d%d%d%d", &hd, &ad, &hk, &ak, &b, &d);
 		int ans=-1;
 		int hdn=hd, adn=ad, hkn=hk, akn=ak;
 		int he,x;
 		for (int j=0; j<=200; j++) {
 			for (int k=0; k<=200; k++) {
 				if (k==0) he=hdn;
 				for (int v=0; v<=200; v++) {
 					if (v==0) {x=he; hkn=hk;}
 					if (hkn<=0) {
 						if (ans==-1) ans=j+k+v;
 						else ans=min(ans,j+k+v);
 						break;
 					}
 					if (x>akn || hkn<=adn) {
 						x-=akn;
 						hkn-=adn;
 					}
 					else x=hd-akn;
 				}
 				if (he>akn) {
 					adn+=b;
 					he-=akn;
 				}
 				else he=hd-akn;
 			}
 			if (hdn>akn-d) {
 				akn-=d;
 				akn=max(0,akn);
 				hdn-=akn;
 			}
 			else hdn=hd-akn;
 		}
 		printf("Case #%d: ", i);
 		if (ans==-1) printf("IMPOSSIBLE\n");
 		else printf("%d\n", ans);
 	}
 }
