#include <cstdio>
 #include <vector>
 #include <queue>
 using namespace std;
 
 int main() {
 	int t, r, k, n, tmp;
 	scanf("%d", &t);
 	for (int kase = 0; kase < t; ++kase) {
 		scanf("%d%d%d", &r, &k, &n);
 		vector<int> group;
 		queue<int> ready, running;
 		for (int i = 0; i < n; ++i) {
 			scanf("%d", &tmp);
 			group.push_back(tmp);
 		}
 		for (int i = 0; i < group.size(); ++i) {
 			running.push(group[i]);
 		}
 		int ret = 0;
 		for (int i = 0; i < r; ++i) {
 			int cur = 0;
 			while (!running.empty()) {
 				ready.push(running.front());
 				running.pop();
 			}
 			while (cur < k && !ready.empty()) {
 				int first = ready.front();
 				if (cur + first <= k) {
 					cur += first;
 					ret += first;
 					ready.pop();
 					running.push(first);
 				} else {
 					break;
 				}
 			}
 		}
 		printf("Case #%d: %d\n", kase + 1, ret);
 	}
 	return 0;
 }
 
