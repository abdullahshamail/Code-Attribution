//============================================================================
 // Name        : A.cpp
 // Author      : 
 // Version     :
 // Copyright   : Your copyright notice
 // Description : Hello World in C++, Ansi-style
 //============================================================================
 #include <cstring>
 #include <cstdio>
 #include <algorithm>
 #include <cmath>
 #include <queue>
 #include <map>
 #include <set>
 #include <iostream>
 #define max(x,y) ((x)>(y)?(x):(y))
 #define min(x,y) ((x)<(y)?(x):(y))
 #define MAXN 100050
 #define LL long long
 using namespace std;
 int N,P;
 int a[1111];
 int cal2(){
 	int res=0;
 	int cnt=0;
 	for(int i=0;i<N;++i)
 		if(a[i]&1)
 			cnt++;
 		else
 			res++;
 	res+=(cnt+1)/2;
 	return res;
 }
 int cal3(){
 	int res=0;
 	int cnt1=0;
 	int cnt2=0;
 	for(int i=0;i<N;++i){
 		if(a[i]%3==0)
 			res++;
 		else if(a[i]%3==1)
 			cnt1++;
 		else
 			cnt2++;
 	}
 	if(cnt1>cnt2)
 		swap(cnt1,cnt2);
 	res+=cnt1;
 	cnt2-=cnt1;
 	res+=(cnt2+2)/3;
 	return res;
 }
 int cal4(){
 	return 0;
 }
 int main() {
 	freopen("A-small-attempt0 (1).in","r",stdin);
 	freopen("A-small-attempt0 (1).out","w",stdout);
 	int tt,ri=0;
 	scanf("%d",&tt);
 	while(tt--){
 		scanf("%d%d",&N,&P);
 		for(int i=0;i<N;++i)
 			scanf("%d",&a[i]);
 		int ans;
 		if(P==2)
 			ans=cal2();
 		else if(P==3)
 			ans=cal3();
 		else
 			ans=cal4();
 		printf("Case #%d: %d\n",++ri,ans);
 	}
 	return 0;
 }
//============================================================================
 // Name        : A.cpp
 // Author      : 
 // Version     :
 // Copyright   : Your copyright notice
 // Description : Hello World in C++, Ansi-style
 //============================================================================
 #include <cstring>
 #include <cstdio>
 #include <algorithm>
 #include <cmath>
 #include <queue>
 #include <map>
 #include <set>
 #include <iostream>
 #define max(x,y) ((x)>(y)?(x):(y))
 #define min(x,y) ((x)<(y)?(x):(y))
 #define MAXN 100050
 #define LL long long
 using namespace std;
 int N,P;
 int a[1111];
 int cal2(){
 	int res=0;
 	int cnt=0;
 	for(int i=0;i<N;++i)
 		if(a[i]&1)
 			cnt++;
 		else
 			res++;
 	res+=(cnt+1)/2;
 	return res;
 }
 int cal3(){
 	int res=0;
 	int cnt1=0;
 	int cnt2=0;
 	for(int i=0;i<N;++i){
 		if(a[i]%3==0)
 			res++;
 		else if(a[i]%3==1)
 			cnt1++;
 		else
 			cnt2++;
 	}
 	if(cnt1>cnt2)
 		swap(cnt1,cnt2);
 	res+=cnt1;
 	cnt2-=cnt1;
 	res+=(cnt2+2)/3;
 	return res;
 }
 int cal4(){
 	return 0;
 }
 int main() {
 	freopen("A-small-attempt0 (1).in","r",stdin);
 	freopen("A-small-attempt0 (1).out","w",stdout);
 	int tt,ri=0;
 	scanf("%d",&tt);
 	while(tt--){
 		scanf("%d%d",&N,&P);
 		for(int i=0;i<N;++i)
 			scanf("%d",&a[i]);
 		int ans;
 		if(P==2)
 			ans=cal2();
 		else if(P==3)
 			ans=cal3();
 		else
 			ans=cal4();
 		printf("Case #%d: %d\n",++ri,ans);
 	}
 	return 0;
 }
