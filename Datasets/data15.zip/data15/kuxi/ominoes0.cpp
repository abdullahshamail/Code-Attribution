#include <iostream>
 #include <stdlib.h>
 #include <string>
 
 using namespace std;
 
 int solve(int n, int r, int c) {
     // can create line of length N
     if(n > r && n > c) {
         return 0;
     }
     // board is too small
     if(r * c < 2 * n) {
         if(n < 3 && r * c == n) {
             return 1;
         }
         return 0;
     }
     int forceLength = n/2 + 1;
     if(n > 2 && (forceLength > r || forceLength > c)) {
         return 0;
     }
     // can create circle
     if(n > 6) {
         return 0;
     }
     
     return (n % (n * c)) ? 1 : 0;
 }
 
 int main()
 {
     int t;
     cin >> t;
 
     for ( int tcase = 0; tcase < t; tcase += 1 ) {
         int n, r, c;
         cin >> n >> r >> c;
         int sol = solve(n, r, c);
         string str = sol == 1 ? "GABRIEL" : "RICHARD";
         cout << "Case #" << (tcase + 1) << ": " << str << endl;
     }
     return 0;
 }
