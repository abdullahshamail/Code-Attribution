#include <iostream>
 
 #include "fileInput.h"
 #include "fileOutput.h"
 #include <algorithm>
 #include <string>
 #include <vector>
 #include <fstream>
 #include <sstream>
 #include <sstream>
 #include <string>
 
 using namespace std;
 
 
 typedef std::pair<int, int> mypair;
 bool mySecondfunction(mypair i, mypair j) { return (i.first<j.first); }
 bool myfunction(int i, int j) { return (i>j); }
 
 
 
 bool comparator(const mypair& l, const mypair& r)
 {
 	return l.first < r.first;
 }
 
 struct myclass {
 	bool operator() (int i, int j) { return (i<j); }
 } myobject;
 
 
 int main()
 {
 	//cout << "Hello world";
 	// Է, Է : ϸ,  : matrix   
 	fileInputInterface *inputProcessing;
 	fileInput testInput("input.txt");
 
 	std::ifstream infile("input.txt");
 	std::string line;
 
 	std::getline(infile, line);
 
 	std::istringstream iss(line);
 	int caseNumber = stoi(line);
 
 	vector<vector<int> > tempVector;
 	tempVector.resize(caseNumber);
 
 	std::ofstream fmatch("output.txt", std::ios::out);
 
 	for (int i = 0; i < caseNumber; i++)
 	{
 		int caseMaxNumber = 0;
 
 		int tempInt;
 		int maxNumber;
 
 		std::getline(infile, line);
 		
 		maxNumber=stoi(line);
 
 		int n = 0;
 		int vectorIndex = 1;
 		tempVector[i].resize(maxNumber);
 		std::getline(infile, line);
 	
 		stringstream ssin(line);
 		for (int j = 0; j < maxNumber; j++)
 		{
 			ssin >> tempInt;
 			tempVector[i][j] = tempInt;
 			if (caseMaxNumber < tempInt)
 				caseMaxNumber = tempInt;
 
 		}
 		sort(tempVector[i].begin(), tempVector[i].end(), myfunction);
 		int iter = 0;
 		int sortMaxNumber = tempVector[i][0];
 		int halfCount = 0;
 
 		int minusall = 0;
 
 		bool isSame = true;
 		int checkNumber = tempVector[i][0];
 		for (int j = 1; j < tempVector[i].size(); j++)
 		{
 			if (checkNumber != tempVector[i][j])
 			{
 				isSame = false;
 				break;
 			}
 		}
 
 
 		while (tempVector[i][0]>4)
 		{
 			int sameNumber = 0;
 			checkNumber = tempVector[i][0];
 			for (int j = 1; j < tempVector[i].size(); j++)
 			{
 				if ( tempVector[i][j] == checkNumber || checkNumber - 1 == tempVector[i][j])
 				{
 					sameNumber++;
 				}
 			}
 			int halfCount = tempVector[i][0];
 
 			if (tempVector[i][0] % 2 == 1)
 			{
 				halfCount = halfCount + 1;
 			}
 			halfCount = halfCount / 2;
 			cout << " ?? " << sameNumber + halfCount <<" "<< tempVector[i][0] << endl;
 			if (sameNumber + halfCount < tempVector[i][0])
 			{
 				tempVector[i][0] = tempVector[i][0] / 2;
 				tempVector[i].push_back(halfCount);
 				sort(tempVector[i].begin(), tempVector[i].end(), myfunction);
 			}
 			else
 			{
 				for (int j = 0; j < tempVector[i].size(); j++)
 				{
 					tempVector[i][j] = tempVector[i][j] - 1;
 				}
 			}
 
 
 			/*
 			// ¥ 
 			int tempMax = tempVector[i][0];
 			minusall = tempMax;
 
 			if (tempVector[i][0] % 2 == 1)
 			{
 				tempMax = tempMax + 1;
 			}
 
 			int nextMax = 0;
 			if (tempVector[i].size()!=1)
 				nextMax=tempVector[i][1];
 			
 			tempVector[i][0] = tempVector[i][0]/2;
 			tempVector[i].push_back(tempMax / 2);	//̰  ū
 
 			sort(tempVector[i].begin(), tempVector[i].end(), myfunction);
 
 			int halfMax = tempMax + nextMax;
 			
 			if (minusall > halfMax)
 			{
 				break;
 			}
 			iter++;;
 
 			cout << (i + 1) << " ";
 			for (int j = 0; j < tempVector[i].size(); j++)
 			{
 				cout << tempVector[i][j] << " ";
 			}
 			cout << endl;
 			cout << " !!! " << sortMaxNumber << " " << halfCount << " " << iter << " " << minusall << " " << halfMax<< endl;
 			
 			
 			int halfCount = tempVector[i][0];
 			
 			if (tempVector[i][0] % 2 == 1)
 			{
 				halfCount = halfCount + 1;
 			}
 			halfCount = halfCount / 2;
 
 			
 			int countBetween = 0;
 			for (int j = 1; j < tempVector[i].size(); j++)
 			{
 				if (tempVector[i][j] <= sortMaxNumber && tempVector[i][j] >= halfCount)
 				{
 					countBetween++;
 				}
 			}
 
 			if (tempVector[i].size()!=1 && tempVector[i][0] - tempVector[i][1] == 1 && sortMaxNumber - halfCount <= countBetween)
 			{
 				for (int j = 0; j < tempVector[i].size(); j++)
 				{
 					tempVector[i][j] = tempVector[i][j] - 1;
 				}
 			}
 			else
 			{
 			//	int tempMax = tempVector[i][0];
 			//	if (tempVector[i][0] % 2 == 1)
 			//	{
 					
 			//		tempMax = tempMax + 1;
 			//	}
 
 				tempVector[i].push_back(tempVector[i][0] / 2);
 				tempVector[i][0] = halfCount ;
 				sort(tempVector[i].begin(), tempVector[i].end(), myfunction);
 			}
 
 			sortMaxNumber = tempVector[i][0];
 			
 			halfCount = tempVector[i][0] / 2;
 			*/ 
 			iter++;
 			cout << (i+1) << " ma ";
 			for (int j = 0; j < tempVector[i].size(); j++)
 			{
 				cout << tempVector[i][j] << " ";
 			}
 			cout << endl;
 			cout << " !!! " << sortMaxNumber << " " << halfCount << " " << iter << " " << endl;
 			
 		}
 		int tuningNumber = tempVector[i][0];;
 		if (tempVector[i][0] == 4 && tempVector[i].size() != 1 && tempVector[i][1] >=3 )
 		{
 			tuningNumber = 4;
 		}
 		else if (tempVector[i][0] <= 2)
 		{
 			tuningNumber = tempVector[i][0];
 		}
 		else
 		{
 			tuningNumber = 3;
 		}
 		/*
 		if (isSame)
 		{
 			iter = checkNumber;
 			tuningNumber = 0;
 		}
 		*/
 		
 		cout << (i + 1) << " " << sortMaxNumber << " " << halfCount << " " << iter << " " << (iter + tuningNumber) << endl;
 		string output = "Case #" + to_string(i + 1) + ": " + to_string((iter + tuningNumber)) + "\n";
 		cout << "** " << output << endl;
 		fmatch << output;
 	//	if (i + 1 == 6)
 	//		system("pause");
 		
 		/*
 		while (sortMaxNumber>halfCount)
 		{
 			
 			if (tempVector[i][0] % 2 == 1)
 			{
 				for (int j = 0; j < tempVector[i].size(); j++)
 				{
 					tempVector[i][j] = tempVector[i][j] - 1;
 				}
 			}
 			else
 			{
 				tempVector[i][0] = tempVector[i][0] / 2;
 				sort(tempVector[i].begin(), tempVector[i].end(), myfunction);
 			}
 			sortMaxNumber = tempVector[i][0];
 			if (tempVector[i][0] % 2 == 0)
 				halfCount = tempVector[i][0] / 2;
 			else
 				halfCount = tempVector[i][0] / 2 + 1;
 			if (sortMaxNumber <= 3)
 				break;
 			iter++;
 		}
 		if (caseMaxNumber <= 3)
 		{
 			iter = 3;
 		}
 		else if (sortMaxNumber<=3)
 		{
 			iter = iter + sortMaxNumber;
 		}
 		//if (sortMaxNumber)
 		cout << sortMaxNumber << " " << halfCount <<" " <<iter<< endl;
 		*/
 		/*
 		if (caseMaxNumber < 3)
 		{
 			iter = caseMaxNumber;
 		}
 		else
 		{
 			while (tempVector[i][0] != 0)
 			{
 				if (tempVector[i][0] % 2 == 1)
 				{
 					for (int j = 0; j < tempVector[i].size(); j++)
 					{
 						tempVector[i][j] = tempVector[i][j] - 1;
 					}
 				}
 				else
 				{
 					tempVector[i][0] = tempVector[i][0] / 2;
 					sort(tempVector[i].begin(), tempVector[i].end(), myfunction);
 				}
 				iter++;
 			}
 
 		}
 		*/
 	//	cout << iter << " ";
 	//	cout << endl;
 		//if (caseMaxNumber > 3)
 		//	caseMaxNumber = 3;
 
 		
 	}
 	fmatch.close();
 	cout << endl << endl;
 	vector<int> needNumberVector;
 	needNumberVector.resize(tempVector.size());
 	system("pause");
 	/*
 	for (int i = 0; i < tempVector.size(); i++)
 	{
 		int maxNumber = stoi(tempVector[i][0]);
 		vector<int> numberInt;
 		numberInt.resize(maxNumber+1);
 		int wholeSum = 0;
 		for (int j = 0; j <= maxNumber; j++)
 		{
 			numberInt[j]=(int)(tempVector[i][1][j])-'0';
 			wholeSum = wholeSum + (int)(tempVector[i][1][j]) - '0';
 			//cout << numberInt[j] << " ";
 		}
 		//cout << endl;
 
 		int needNumber = 0;
 		int sumBefore = 0;
 		if (numberInt[0] == 0)
 		{
 			needNumber++;
 			sumBefore = sumBefore + 1;
 		}
 		else
 		{
 			
 			sumBefore = sumBefore + numberInt[0];
 		}
 		
 		
 		for (int j = 1; j <= maxNumber; j++)
 		{
 			if (j > sumBefore)
 			{
 				needNumber = needNumber+ j - sumBefore;
 				sumBefore = j;
 			}
 
 			sumBefore = sumBefore + numberInt[j];
 		
 		}
 		needNumberVector[i] = needNumber;
 	}
 	std::ofstream fmatch("output.txt", std::ios::out);
 
 	for (int i = 0; i < needNumberVector.size(); i++)
 	{
 		string output = "Case #" + to_string(i + 1) + ": " + to_string(needNumberVector[i])+"\n";
 		fmatch << output;
 	}
 	fmatch.close();
 	*/
 
 //	std::system("pause");
 //	inputProcessing = &testInput;
 
 //	inputProcessing->getFileLinebyLine();
 	
 	/*
 	vector<pair<int, int > > answerVector;
 	vector<vector<pair<int, int> > > indexVector;
 
 	indexVector.resize(tempVector.size());
 	for (int i = 0; i < tempVector.size(); i++)
 	{
 		indexVector[i].resize(tempVector[i].size()-2);
 		for (int j = 2; j < tempVector[i].size(); j++)
 		{
 			indexVector[i][j-2] = (mypair (tempVector[i][j], j - 2));
 		}
 	}
 
 	for (int i = 0; i < indexVector.size(); i++)
 	{
 		int cNumber = tempVector[i][0];
 		int lNumber = tempVector[i][1];
 
 		sort(indexVector[i].begin(), indexVector[i].end(), myfunction);
 		for (int j = 0; j < indexVector[i].size(); j++)
 		{
 			cout << indexVector[i][j].first << " " << indexVector[i][j].second << "  :  ";
 		}
 		cout << endl;
 		for (int j = 0; j < indexVector[i].size()-1;j++)
 		{
 			cout << i << " : "<<j <<" : " << j+1 << " is ";
 			if (std::binary_search(indexVector[i].begin() + j+1 , indexVector[i].end(), pair<int, int>(cNumber - indexVector[i][j].first, 0), mySecondfunction))
 				std::cout << "found!\n"; 
 			else std::cout << "not found.\n";
 
 		}
 		
 
 	}
 
 	*/
 	/*
 	for (int i = 0; i < tempVector.size(); i++)
 	{
 		// sorting
 		int cNumber = tempVector[i][0];
 		int lNumber = tempVector[i][1];
 
 		std::vector<int> myvector(tempVector[i].begin + 2, tempVector[i].begin + tempVector[i].size());
 
 	}
 	*/
 	/*
 	for (int i = 0; i<tempVector.size(); i++)
 	{
 		int cNumber = tempVector[i][0];
 		int lNumber = tempVector[i][1];
 		pair<int, int> answerPair;
 
 		bool isFind = false;
 
 		for (int j = 2; j < tempVector[i].size()-1; j++)
 		{
 			for (int q = j + 1; q < tempVector[i].size(); q++)
 			{
 				if (tempVector[i][j] + tempVector[i][q] == cNumber)
 				{
 					answerPair.first = j-1;
 					answerPair.second = q-1;
 					isFind = true;
 					break;
 				}
 			}
 			if (isFind == true)
 				break;
 		}
 		answerVector.push_back(answerPair);
 	}
 	for (int i = 0; i < answerVector.size(); i++)
 	{
 		cout << answerVector[i].first << " " << answerVector[i].second << endl;
 
 	}
 	*/
 
 
 	/*
 	fileOutputInterface *outputProcessing;
 	
 	fileOutput testOutput("outputTest.txt");
 
 	vector<string> testTable;
 	testTable.resize(3);
 	testTable[0] = "Case #1: 2 3";
 	testTable[1] = "Case #2: 1 4";
 	testTable[2] = "Case #3: 4 5";
 
 	outputProcessing = &testOutput;
 
 	outputProcessing->setFileLinebyLine(testTable);
 
 	cout<<" compare "<<testOutput.compareOutput("output.txt", testTable);
 	*/
 
 	
 }