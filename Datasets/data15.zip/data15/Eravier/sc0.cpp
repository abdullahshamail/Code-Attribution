#include <iostream>
 
 using namespace std;
 
 char mnoz(char a,char b)
 {
   if(a=='1')
     return b;
   if(b=='1')
     return a;
   if(a<='n'&&a>='l'&&b<='n'&&b>='l')
     {
       a-=3;
       b-=3;
     }
   if(a<='k'&&a>='i'&&b<='n'&&b>='l')
     {
       a+=3;
       b-=3;
     }
   if(a<='k'&&a>='i'&&b<='k'&&b>='i')
   {
     if(a==b)
       return '4';
     else if(a=='i')
       {
         if(b=='j')
           return 'k';
         else
           return 'm';
       }
     else if(a=='j')
       {
         if(b=='i')
           return 'n';
         else
           return 'i';
       }
     else if(a=='k')
       {
         if(b=='i')
           return 'j';
         else
           return 'l';
       }
   }
   if(a<='n'&&a>='l'&&b<='k'&&b>='i')
   {
     if((a-3)==b)
       return '1';
     else if(a=='l')
       {
         if(b=='j')
           return 'n';
         else
           return 'j';
       }
     else if(a=='m')
       {
         if(b=='i')
           return 'k';
         else
           return 'l';
       }
     else if(a=='n')
       {
         if(b=='i')
           return 'm';
         else
           return 'i';
       }
   }
   else if(a=='4'&&b<='k'&&b>='i')
     return b+3;
   else if(a=='4')
     return b-3;
   else if(b=='4'&&a<='k'&&a>='i')
     return a+3;
   else if(b=='4')
     return a-3;
     
 }
 
 int main()
 {
   int n,l,x,licznik1,licznik2;
   char tab[10000];
   char srodek;
   char poczatek;
   char koniec;
   bool flag;
   cin>>n;
   for(int i=0;i<n;i++)
   {
     cin>>l>>x;
     for(int j=0;j<l;j++)
       {
         cin>>tab[j];
         for(int k=l+j;k<x*l;k+=l)
         {
           tab[k]=tab[j];
         }
       }
     licznik1=0;
     licznik2=x*l-1;
     flag=0;
     poczatek='1';
     koniec='1';
     srodek='1';
         while(flag==0&&licznik1<licznik2)
         {
           while(koniec!='k'&&licznik1<licznik2)
           {
             koniec=mnoz(tab[licznik2],koniec);
             licznik2--;
             
           }
           while(flag==0&&licznik1<licznik2)
           {
             while(poczatek!='i'&&licznik1<licznik2)
             {
               poczatek=mnoz(poczatek,tab[licznik1]);
               licznik1++;
             }
             if(poczatek=='i'&&koniec=='k')
             {
               for(int j=licznik1;j<=licznik2;j++)
                 srodek=mnoz(srodek,tab[j]);
               if(srodek=='j')
               {
                 flag=1;
               }
               else
               {
                 poczatek=mnoz(poczatek,tab[licznik1]);
                 licznik1++;
               }
             }
           }
           if(flag==0)
           {
             koniec=mnoz(tab[licznik2],koniec);
             licznik2--;
             poczatek=1;
             licznik1=0;
           }
         }
           
     
     
     
    if(flag==0)
     cout<<"Case #"<<i+1<<": NO\n";
    else
     cout<<"Case #"<<i+1<<": YES\n";
   }
   
 
   return 0;
 }