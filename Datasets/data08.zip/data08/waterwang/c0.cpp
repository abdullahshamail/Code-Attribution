#include <iostream>
 using namespace std;
 int C,M,N;
 bool map[100][100];
 int res[100][100];
 void print()
 {
     int i,j;
     for (i=0;i<M;i++)
     {
         for (j=0;j<N;j++)
             cout<<res[i][j]<<' ';
         cout<<endl;
     }       
 }
 bool find()
 {
     int i,j,tmp,ans,x,y;
     bool flag;
     flag=false;
     ans=10;
     for (i=0;i<M;i++)
         for (j=0;j<N;j++)
             if (res[i][j]==0 && map[i][j])
             {
                 tmp=0;
                 if (i-1>=0)
                 {
                     if (j-1>=0 && map[i-1][j-1] && res[i][j]==0)
                         tmp++;
                     if (j+1<N && map[i-1][j+1] && res[i][j]==0)
                         tmp++;
                 }
                 if (j-1>=0 && map[i][j-1] && res[i][j]==0)
                     tmp++;
                 if (j+1<N && map[i][j+1] && res[i][j]==0)
                     tmp++;
                 if (tmp<ans)
                 {
                     x=i;
                     y=j;
                     ans=tmp;
                     flag=true;
                 }
             }
     if (flag)
     {
     res[x][y]=1;
     if (x+1<M)
     {
         if (y-1>=0)
             map[x+1][y-1]=false;
         if (y+1<N)
             map[x+1][y+1]=false;
     }   
     if (y-1>=0)
         map[x][y-1]=false;
     if (y+1<N)
         map[x][y+1]=false;
     //print();
     } 
     return flag;
 }
 int main()
 {
     char c;
     int Ci,total,i,j;
     freopen("C-small-attempt2.in","r",stdin);
     freopen("C-small-attempt2.out","w",stdout);
     cin>>C;
     for (Ci=1;Ci<=C;Ci++)
     {
         total=0;
         memset(map,true,sizeof(map));
         memset(res,0,sizeof(res));
         cin>>M>>N;
         for (i=0;i<M;i++)
             for (j=0;j<N;j++)
             {
                 cin>>c;
                 while (!(c=='.' || c=='x'))
                     cin>>c;
                 if (c=='x')
                     map[i][j]=false;
             }
         while (find())
             total++;
         //print();
         cout<<"Case #"<<Ci<<": "<<total<<endl;
     }
     return 0;
 }
