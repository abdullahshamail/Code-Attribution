#include <iostream>
 #include <map>
 #include <string>
 #include <algorithm>
 using namespace std;
 
 
 int M, N;
 char grid[100][100];
 int record[11][1200];
 int cc[1200];
 int dd[1200][1200];
 int VV[100][1200];
 
 int valid(int x, int y)
 {
     if (VV[x][y] >= 0) return VV[x][y];   
     
     int tt = N - 1;
     int pre = -1;
     while (y > 0)
     {
         int t = y % 2;
         
         
         if (t != pre) t = pre;
         else if (t == pre && t == 1) return VV[x][y] = 0;
         
         if (grid[x][tt--] == 'x' && t) return VV[x][y] = 0;
         
         y /= 2;
     }   
     return VV[x][y] = 1; 
 }      
 
 int count(int x)
 {
     if (cc[x] >= 0) return cc[x];
     int ans = 0;
     while (x > 0)
     {
         if (x % 2 == 1) ans++;
         x /= 2;
     }    
     return cc[x] = ans;
 }    
 
 int count(int x, int *y)
 {
     int t = N - 1;
     while (x > 0)
     {
         y[t--] = x % 2;
         x /= 2;
     }  
 }    
 
 int valid2(int x, int y)
 {
     if (dd[x][y] >= 0) return dd[x][y];
     
     int a[20] = {0}, b[20] = {0};
     count(x, a); count(y, b);
     for (int i = 0; i < N; i++)
     {
         if (i == 0)
         {
             if (b[i] == 1 && a[i + 1] == 1) return dd[x][y] = 0;
         } else    
         if (b[i] == 1 && (a[i - 1] == 1 || a[i + 1] == 1)) return dd[x][y] = 0;
     }    
     
     return dd[x][y] = 1;
 }    
 
 void solve()
 {
     memset(record, -1, sizeof(record));
     memset(cc, -1, sizeof(cc));
     memset(dd, -1, sizeof(dd));
     memset(VV, -1, sizeof(VV));
     for (int j = 0; j < (1 << N); j++)
     {
         if (valid(0, j)) {
             record[0][j] = count(j);
         }    
     } 
        
    for (int i = 0; i < M - 1; i++)
    {
        for (int j = 0; j < (1 << N); j++)
        {
            if (record[i][j] >= 0)
            {
                for (int k = 0; k < (1 << N); k++)
                {
                    if (!valid(i + 1, k)) continue;
                    if (!valid(i, j)) continue;
                    if (valid2(k, j))
                    {
                        int tt = record[i][j] + count(k);
                        if (tt > record[i + 1][k]) record[i + 1][k] = tt;
                    }    
                }   
            }     
        }    
    } 
    int ans = -1;
    for (int j = 0; j < (1 << N); j++)   
    {
        if (record[M - 1][j] > ans) ans = record[M - 1][j];
    }  
    printf("%d\n", ans);   
 }  
 
    
 
 int main()
 {
     freopen("C-small-attempt1.in", "r", stdin);
     //freopen("A-large.in", "r", stdin);
     freopen("out.txt", "w", stdout);
     int t; scanf("%d", &t);
     for (int i = 1; i <= t; i++)
     {
         printf("Case #%d: ", i);
         scanf("%d %d", &M, &N);
         for (int j = 0; j < M; j++)
         {
             scanf("%s", grid[j]);   
         } 
         solve();   
     }      
 }    
