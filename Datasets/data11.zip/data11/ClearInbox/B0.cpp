// Template for CodeJam by _ClearInbox_
 #include <iostream>
 #include <fstream>
 #include <sstream>
 #include <vector>
 #include <string>
 #include <map>
 #include <algorithm>
 
 using namespace std;
 void HandleCases(ifstream &fin, ofstream &fout, int caseNum);
 
 int main(int argc, char *argv[]) {
 	ifstream fin(argv[1]);
 	string out(argv[1]);
 	out.replace(out.find(".in"), 3, ".out");
 	ofstream fout(out.c_str()); // output
 	string line;
 	getline(fin, line);
 	int cases = atoi(line.c_str());
 	for (int i = 0; i < cases; i++) {
 		HandleCases(fin, fout, i + 1);
 	}
 	fin.close();
 	fout.close();
 	return 0;
 }
 
 void Solve(string &item, string comb[], int c_num, string oppo[], int o_num) {
 	for (int i = 0; i < c_num; i++) {
 		if ((item[0] == comb[i][0] && item[1] == comb[i][1]) ||
 				(item[0] == comb[i][1] && item[1] == comb[i][0])) {
 			item.replace(0, 2, string(&comb[i][2]));
 			Solve(item, comb, c_num, oppo, o_num);
 		}
 		if ((item[item.size() - 1] == comb[i][0] &&
 					item[item.size() - 2] == comb[i][1]) ||
 				(item[item.size() - 1] == comb[i][1] &&
 				 item[item.size() - 2] == comb[i][0])) {
 			item.replace(item.size() - 2, 2, string(&comb[i][2]));
 			Solve(item, comb, c_num, oppo, o_num);
 		}
 	}
 	for (int i = 0; i < item.size(); i++) {
 		for (int k = 0; k < o_num; k++) {
 			if (item[i] == oppo[k][0]) {
 				for (int j = i+1; j < item.size(); j++) {
 					if (item[j] == oppo[k][1]) {
 						item.replace(min(i, j), abs(i-j) + 1, "");
 						Solve(item, comb, c_num, oppo, o_num);
 					}
 				}
 			}
 			if (item[i] == oppo[k][1]) {
 				for (int j = i+1; j < item.size(); j++) {
 					if (item[j] == oppo[k][0]) {
 						item.replace(min(i, j), abs(i-j) + 1, "");
 						Solve(item, comb, c_num, oppo, o_num);
 					}
 				}
 			}
 		}
 		for (int k = 0; k < c_num; k++) {
 			if (i != item.size() - 1 && item[i] == comb[k][0]) {
 				if (item[i-1] == comb[k][1]) { 
 					item.replace(i - 1, 2, string(&comb[k][2]));
 					Solve(item, comb, c_num, oppo, o_num);
 				}
 				if (item[i+1] == comb[k][1]) {
 					item.replace(i, 2, string(&comb[k][2]));
 					Solve(item, comb, c_num, oppo, o_num);
 				}
 			}
 		}
 	}
 }
 
 void HandleCases(ifstream &fin, ofstream &fout, int caseNum) {
 	fout << "Case #" << caseNum << ": ";
 	cout << "Case #" << caseNum << ": ";	// testing
 	int c_num;
 	int o_num;
 	int len;
 	string item;
 	string line;
 	getline(fin, line);
 	stringstream ss;
 	ss << line;
 	ss >> c_num;
 	string comb[c_num];
 	for (int i = 0; i < c_num; i++) {
 		ss >> comb[i];
 	}
 	ss >> o_num;
 	string oppo[o_num];
 	for (int i = 0; i < o_num; i++) {
 		ss >> oppo[i];
 	}
 	ss >> len >> item;
 	Solve(item, comb, c_num, oppo, o_num);
 	fout << "[";
 	if (item.size() != 0) {
 		for (int i = 0; i < item.size() - 1; i++) {
 			fout << item[i] << ", ";
 		}
 		fout << item[item.size() - 1];
 	}
 	fout << "]";
 	fout << endl;
 	cout << endl;	// testing
 }
