#include<iostream>
 using namespace std;
 
 unsigned long long fact(unsigned long long n)
 {
 	unsigned long long result = 1;
 	while(n>1)
 	{
 		result *= n;
 		n--;
 	}
 	return result;
 }
 
 int main()
 {
 	int t,tbc;
 	cin>>t;
 	tbc = t;
 	while(t--)
 	{
 		int n;
 		cin>>n;
 		int arrd[n],arro[n];
 		for(int i=0;i<n;i++)
 		{
 			cin>>arrd[i];
 			arro[i] = arrd[i];
 		}
 
 		for(int i=0;i<n;i++)
 		for(int j=i;j<n-1;j++)
 		{
 			if(arro[j]>arro[j+1])
 			{
 				int temp = arro[j];
 				arro[j] = arro[j+1];
 				arro[j+1] = temp;
 			}
 		}		
 
 		int cnt = n;
 		for(int i=0;i<n;i++)
 		{
 			if(arro[i]==arrd[i]) cnt--;
 		}
 		
 		unsigned long long mn = cnt;
 		if(cnt>1)
 		{
 			mn = 99999999999;
 			for(int i=2;i<=cnt;i++)
 			{
 				if(cnt%i==0)
 				{
 					unsigned long long val = (cnt/i)*fact(i);
 					if(val<mn)
 						mn = val;
 				}
 			}
 		}			
 
 		cout<<"Case #"<<tbc-t<<": "<<mn<<".000000"<<endl;
 	}
 	return 0;
 }
