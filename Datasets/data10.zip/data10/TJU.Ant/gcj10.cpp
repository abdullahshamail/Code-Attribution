#include <iostream>
 #include <cstring>
 using namespace std;
 int n,k,t;
 int cnt[35];
 int main()
 {
 	int i;
 	int case_t;
 	freopen("A-small-attempt1.in","r",stdin);
 	freopen("A-small.out","w",stdout);
 	while(scanf("%d",&t)!=EOF)
 	{
 		case_t = 1;
 		while(t--)
 		{
 			memset(cnt,0,sizeof(cnt));
 			cnt[0] = 1;
 			scanf("%d%d",&n,&k);
 			while(k--)
 			{
 			for(i=0;i<n;i++)
 			{
 				if(i==0)
 				{
 					if(cnt[i] == 1)
 						cnt[i] = 3;
 					else
 						cnt[i] = 1;
 				}
 				else
 				{
 					if(cnt[i]==0)
 					{
 						if(cnt[i-1]==3)
 							cnt[i] = 1;
 						else
 							cnt[i] = 0;
 					}
 					else if(cnt[i]==1)
 					{
 						if(cnt[i-1]==3)
 							cnt[i] = 3;
 						else
 							cnt[i] = 2;
 					}
 					else if(cnt[i]==2)
 					{
 						if(cnt[i-1]==3)
 							cnt[i] = 3;
 						else
 							cnt[i] = 2;
 					}
 					else if(cnt[i]==3)
 					{
 						if(cnt[i-1]==3)
 							cnt[i] = 1;
 						else
 							cnt[i] = 0;
 					}
 				}
 			}
 
 			}
 			//for(i=0;i<n;i++)
 				//cout<<cnt[i];
 			//cout<<endl;
 			printf("Case #%d: ",case_t++);
 			if(cnt[n-1]==3)
 				printf("ON\n");
 			else
 				printf("OFF\n");
 		}
 	}
 	return 0;
 }
