#include <cstdlib>
 #include <cstdio>
 #include <iostream>
 #include <algorithm>
 #include <vector>
 
 using namespace std;
 
 const int MAXN = 500;
 
 int keys[MAXN];
 int needed[MAXN];
 int chest_needed[MAXN];
 vector<int> contents[MAXN];
 bool visited[MAXN];
 
 void change_contents(int x, int plus){
 	for(int i = 0; i < contents[x].size(); i++)
 		keys[ contents[x][i] ] += plus;
 	}
 bool check(int x){
 	for(int i = 0; i < contents[x].size(); i++){
 		//~ printf("Comp: %d < %d | %d\n", needed[ contents[x][i] ], keys[ contents[x][i] ], contents[x][i]);
 		if(needed[ contents[x][i] ] > keys[ contents[x][i] ] )
 			return false;
 			}
 	return true;
 	}
 
 int pick(int n){
 	for(int j = n-1; j >= 0; j--)
 		if(!visited[j]){
 			change_contents(j, -1);
 			if(check(j) && needed[chest_needed[j]] <= keys[chest_needed[j]]){
 				needed[chest_needed[j]]--;
 				return j;
 				}
 			else
 				change_contents(j, +1);
 			}
 	return -1;
 	}
 
 void solve(int n){
 	//~ cout << "We are in" << endl;
 	for(int i = 0; i < n; i++)
 		for(int j = 0; j < contents[i].size(); j++)
 			keys[contents[i][j]]++;
 	/// we have all the keys in the end
 	
 	//~ cout << "We are in" << endl;
 	vector<int> answ;
 	int res;
 	for(int i = 0; i < n; i++){
 		res = pick(n);
 		if(res != -1){
 			answ.push_back(res);
 			visited[res] = true;
 			}
 		else{
 			printf(" IMPOSSIBLE\n");
 			return;
 			}
 		}
 	
 	for(int i = answ.size() -1; i >= 0; i--)
 		printf(" %d", answ[i]+1);
 	printf("\n");
 	}
 
 int main(){
 	int testcases;
 	scanf("%d", &testcases);
 	
 	int q, chests, m, tmp;
 	for(int testcase = 0; testcase < testcases; testcase++){
 		fill(keys, keys + MAXN, 0);
 		fill(needed, needed + MAXN, 0);
 		fill(visited, visited + MAXN, 0);
 		fill(chest_needed, chest_needed + MAXN, 0);
 		
 		scanf("%d%d", &q, &chests);
 		
 		for(int i = 0; i < q; i++)
 			scanf("%d", &m),
 			keys[m]++;
 			
 		//~ cout << "We are in" << endl;
 		for(int i = 0; i < chests; i++){
 			scanf("%d%d", &chest_needed[i], &m);
 			needed[chest_needed[i]]++;
 			contents[i].clear();
 			for(int j = 0; j < m; j++)
 				scanf("%d", &tmp),
 				contents[i].push_back(tmp);
 			}
 		
 		printf("Case #%d:", testcase+1);
 		solve(chests);
 		}
 	
 	
 	return 0;
 }
