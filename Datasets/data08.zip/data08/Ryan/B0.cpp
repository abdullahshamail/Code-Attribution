#include <iostream>
 #include <string>
 #include <vector>
 #include <deque>
 
 using namespace std;
 
 int solve();
 
 int main(){
   int t;
   cin>>t;
   for(int i=0;i<t;i++){
     int time=solve();
     if(time>=0)
       cout<<"Case #"<<i+1<<": "<<time<<'\n';
     else
       cout<<"Case #"<<i+1<<": THE CAKE IS A LIE\n";
     //break;
   }
 }
 
 const int dirs=4;
 const int dx[dirs]={-1,1,0,0};
 const int dy[dirs]={0,0,-1,1};
 const int N=16,infinity=999999999;
 int dist[N][N][N][N];
 int portalx[N][N][dirs];
 int portaly[N][N][dirs];
 
 bool wall(const vector<string>& v,int x,int y);
 
 int bfs(const vector<string>& v,pair<int,int> start,pair<int,int> end){
   int X=v.size(),Y=v.back().size();
   for(int x=0;x<X;x++) for(int y=0;y<Y;y++) for(int xx=0;xx<=X;xx++) for(int yy=0;yy<=Y;yy++)
     dist[x][y][xx][yy]=infinity;
   deque<vector<int> > q;
   vector<int> starting(4);
   starting[0]=start.first; starting[1]=start.second;
   starting[2]=X; starting[3]=Y;
   dist[start.first][start.second][X][Y]=0;
   q.push_back(starting);
   while(q.size()){
     int x=q.front()[0],y=q.front()[1];
     int px=q.front()[2],py=q.front()[3];
     int d=dist[x][y][px][py];
     //cout<<"state: "<<x<<','<<y<<" portal:"<<px<<','<<py<<" dist: "<<d<<'\n';
     q.pop_front();
     if(make_pair(x,y)==end)
       return d;
 
     //take a step
     for(int i=0;i<dirs;i++){
       int nd=d+1;
       int nx=x+dx[i],ny=y+dy[i];
       if(!wall(v,nx,ny)){
         if(dist[nx][ny][px][py]==infinity){
           dist[nx][ny][px][py]=nd;
           //cout<<"  stepping to: "<<nx<<','<<ny<<" portal:"<<px<<','<<py<<'\n';
           vector<int> nv(4);
           nv[0]=nx; nv[1]=ny;
           nv[2]=px; nv[3]=py;
           q.push_back(nv);
         }
       }else if(px!=X && py!=Y){
         int nx=px,ny=py;
         if(dist[nx][ny][X][Y]==infinity){
           dist[nx][ny][X][Y]=nd;
           //cout<<"  portaling to: "<<nx<<','<<ny<<" portal:"<<X<<','<<Y<<'\n';
           vector<int> nv(4);
           nv[0]=nx; nv[1]=ny;
           nv[2]=X; nv[3]=Y;
           q.push_back(nv);
         }
       }
     }
 
     //shoot the gun
     if(px==X && py==Y){
       for(int i=0;i<dirs;i++){
         int nx=portalx[x][y][i];
         int ny=portaly[x][y][i];
         if(dist[x][y][nx][ny]==infinity){
             dist[x][y][nx][ny]=d;
             vector<int> nv(4);
             //cout<<"  shooting portal at: "<<x<<','<<y<<" portal:"<<nx<<','<<ny<<'\n';
             nv[0]=x; nv[1]=y;
             nv[2]=nx; nv[3]=ny;
             q.push_front(nv);
         }
       }
     }
   }
   return -1;
 }
 
 int solve(){
   int x,y;
   string blank;
   cin>>x>>y; getline(cin,blank);
   vector<string> v(x);
   for(int i=0;i<x;i++)
     getline(cin,v[i]);
   pair<int,int> start,end;
   for(int i=0;i<v.size();i++)
     for(int j=0;j<v[i].size();j++)
       if(v[i][j]=='O')
         start=make_pair(i,j);
       else if(v[i][j]=='X')
         end=make_pair(i,j);
   //cout<<"start: "<<start.first<<','<<start.second<<'\n';
   //cout<<"end: "<<end.first<<','<<end.second<<'\n';
 
   for(int x=0;x<v.size();x++)
     for(int y=0;y<v[x].size();y++)
       for(int d=0;d<dirs;d++){
         int lx=x,ly=y;
         int cx=x,cy=y;
         while(!wall(v,cx,cy)){
           lx=cx; ly=cy;
           cx+=dx[d];
           cy+=dy[d];
         }
         portalx[x][y][d]=lx;
         portaly[x][y][d]=ly;
       }
   return bfs(v,start,end);
 }
 
 bool wall(const vector<string>& v,int x,int y){
   return x<0 || x>=v.size() || y<0 || y>=v[x].size() || v[x][y]=='#';
 }
