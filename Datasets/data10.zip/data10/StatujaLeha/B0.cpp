// B.cpp : Defines the entry polong long for the console application.
 //
 
 #include <fstream>
 
 #include <algorithm>
 #include <string>
 
 typedef struct { long long first, second, third; } Chick;
 std::ifstream in("B-small-attempt2.in");
 std::ofstream out("B.out");
 
 Chick chickens[50];
 long long N, K, B, T;
 
 # define INFINITE 2000000000
 
 long long timeToEncounter()
 {
 	long long time = INFINITE;
 
 	for (long long i = 0; i < N - 1; ++i)
 	{
 		if (chickens[i].second > chickens[i + 1].second)
 		{
 			long long t = (chickens[i + 1].first - chickens[i].first)/(chickens[i].second - chickens[i + 1].second);
 			if (0 != (chickens[i + 1].first - chickens[i].first) % (chickens[i].second - chickens[i + 1].second))
 				++t;
 
 			if (time > t)
 				time = t;
 		}
 	}
 
 	return time;
 }
 
 void updatePositions(long long time)
 {
 	if (INFINITE == time)
 		return;
 
 	chickens[N - 1].first += time*chickens[N - 1].second;
 	for (long long i = N - 2; i >= 0; --i)
 	{
 		long long x = chickens[i].first + time*chickens[i].second;
 		if (x > chickens[i + 1].first)
 			x = chickens[i + 1].first;
 		
 		chickens[i].first = x;
 	}
 }
 
 void reorderChickens(long long remainingTime)
 {
 	for (long long i = N - 1; i > 0; --i)
 	{
 		if (chickens[i].first == chickens[i - 1].first)
 		{
 			for (int j = i; j < N; ++j)
 			{
 				if (chickens[j].first == chickens[j - 1].first)
 				{
 					long long X1 = remainingTime*chickens[j].second + chickens[j].first;
 					long long X2 = remainingTime*chickens[j - 1].second + chickens[j - 1].first;
 
 					if (X1 < B && X2 >= B)
 					{
 						chickens[j - 1].third++;
 						std::swap(chickens[j - 1], chickens[j]);
 					}
 					else
 						if (X1 < B && X2 < B && chickens[j - 1].second > chickens[j].second)
 							std::swap(chickens[j - 1], chickens[j]);
 				}
 			}
 		}
 	}
 }
 
 int countChickens(long long remainingTime)
 {
 	int r = 0;
 	long long v = chickens[N - 1].second;
 
 	for (long long i = N - 1; i >= 0; --i)
 	{
 		v = std::min(v, chickens[i].second);
 		long long X1 = remainingTime*v + chickens[i].first;
 
 		if (X1 >= B)
 			++r;
 	}
 
 	return r;
 }
 
 int countResult()
 {
 	int r = 0;
 	for (long long i = 0; i < K; ++i)
 		r += chickens[N - i - 1].third;
 
 	return r;
 }
 
 long long solve()
 {
 	in >> N >> K >> B >> T;
 
 	for (long long i = 0; i < N; ++i)
 		in >> chickens[i].first;
 
 	for (long long i = 0; i < N; ++i)
 		in >> chickens[i].second;
 
 	if (countChickens(T) < K)
 		reorderChickens(T);
 
 	while (T > 0 && countChickens(T) < K)
 	{
 		long long t = timeToEncounter();
 		updatePositions(t);
 
 		if (t == INFINITE)
 		{
 			reorderChickens(T);
 			break;
 		}
 		else
 			T -= t;
 
 		reorderChickens(T);
 
 		if (countChickens(T) >= K)
 			break;
 		else
 			if (0 == t)
 				break;
 	}
 
 	if (countChickens(T) >= K)
 		return countResult();
 	else
 		return -1;
 }
 
 int main()
 {
 	long long T;
 	in >> T;
 
 	for (long long i = 0; i < T; ++i)
 	{
 		long long r = solve();
 		if (-1 != r)
 			out << "Case #" << (i + 1) << ": " << r << "\n";
 		else
 			out << "Case #" << (i + 1) << ": " << "IMPOSSIBLE" << "\n";
 	}
 
 	return 0;
 }
 
