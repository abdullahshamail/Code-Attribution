#include<stdio.h>
 #include<string.h>
 #include<map>
 #include<vector>
 #include<algorithm>
 using namespace std;
 struct P{
     int i,v;
 }in;
 typedef vector<P> T;
 int o[2005];
 int s[5][2005];
 map<int,T> ma;
 map<int,T>::iterator p;
 int cmp(P a,P b){
     return a.v<b.v;
 }
 int main(){
     freopen("C-small-attempt0.in","r",stdin);
     freopen("C-small-attempt0.out","w",stdout);
     int t,n,i,j,k,e,to;
     scanf("%d",&t);
     for(k=1;k<=t;k++){
         ma.clear();
         memset(o,0,sizeof(o));
         to=0;
         scanf("%d",&n);
         for(i=0;i<n;i++){
             scanf("%d",&s[0][i]);
         }
         for(i=0;i<n;i++){
             scanf("%d",&s[1][i]);
         }
         for(i=0;i<n;i++){
             in.i=i; in.v=s[1][i];
             ma[s[0][i]].push_back(in);
         }
         for(p=ma.begin();p!=ma.end();p++){
             sort((p->second).begin(),(p->second).end(),cmp);
             e=(p->second).size();
             for(i=0;i<e;i++){
                 o[(p->second)[i].i]=++to;
             }
         }
         printf("Case #%d:",k);
         for(i=0;i<n;i++){
             printf(" %d",o[i]);
         }
         puts("");
     }
 }
