#include<iostream>
 #include<string>
 #include<string.h>
 using namespace std;
 char ma[100][100];
 int a[100],b[100],c[100],c1[100];
 int n,m;
 int main()
 {
 	freopen("C-small-attempt3.in","r",stdin);
 	freopen("C-small-attempt3.out","w",stdout);
 	int cas,cao=1;
 	scanf("%d",&cas);
 	while(cas--)
 	{
 		scanf("%d%d",&n,&m);
 		int i,j,k,za,zb,t;
 		memset(a,0,sizeof(a));
 		memset(b,0,sizeof(b));
 		memset(c,0,sizeof(c));
 
 		for(i=0;i<n;i++)
 			for(j=0;j<m;j++)
 			{
 				cin >> ma[i][j];
 			}
 	    for(i=0;i<n;i++)
 			if(ma[i][0]=='.')
 			{
 				a[0]+=1;
 				b[0]+=1;
 				c[i]=1;
 			}
 		for(j=1;j<m;j++)
 		{
 			za=zb=0;
 			memset(c1,0,sizeof(c1));
 			for(i=0;i<n;i++)
 			if(ma[i][j]=='.')
 			{
 				za++;
 				c1[i]=1;
 			}
 			else
 			if(ma[i][j-1]=='.'&&(j-2<0||ma[i][j-2]=='x')&&((i-1)<0||(ma[i-1][j]=='x'&&(j-2<0|ma[i-1][j-2]=='x'))))
 			{
 				za++;
 			}
 			a[j]=a[j-2]+za;
 			for(i=0;i<n;i++)
 				if(c[i]==0&&ma[i][j]=='.')
 			{
 				zb++;
 			}
 			t=b[j-1]+zb;
 			if(t>a[j])
 			{
 				b[j]=t;
                 for(i=0;i<n;i++)
 				if(c[i]==0&&ma[i][j]=='.')
 			{
 				c1[i]=1;
 			}
 			}
 			else b[j]=a[j];
 			zb=0;
 			for(i=0;i<n;i++)
 		    if(ma[i][j-1]=='x'&&ma[i][j]=='.')
 			{
 				zb++;
 			}
 			t=a[j-1]+zb;
 			if(t>b[j])
 			{
 			b[j]=t;
 			memset(c1,0,sizeof(c1));
 			for(i=0;i<n;i++)
 		    if(ma[i][j-1]=='x'&&ma[i][j]=='.')
 			{
 				c1[i]=1;
 			}
 			}
 			memcpy(c,c1,sizeof(c1));
 		}
 		printf("Case #%d: %d\n",cao++,b[m-1]);
 	}
 }