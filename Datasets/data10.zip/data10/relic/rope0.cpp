#include <cstdio>
 #include <cmath>
 #include <cstring>
 #include <vector>
 using namespace std;
 
 const double infinity   = 1e10;	 // 无穷大
 const double PI = 3.1415926535;
 const double EPS = 1e-7;	// 计算精度
 const int LEFT   = 0;		// 点在直线左边
 const int RIGHT  = 1;		// 点在直线右边
 const int ONLINE = 2;		// 点在直线上
 const int CROSS  = 0;		// 两直线相交
 const int COLINE = 1;		// 两直线共线
 const int PARALLEL = 2;		// 两直线平行
 const int NOTCOPLANAR = 3;	// 两直线不共面
 const int INSIDE = 1;		// 点在图形内部
 const int OUTSIDE = 2;		// 点在图形外部
 const int BORDER = 3;		// 点在图形边界
 
 struct Point {			  // 二维点或矢量
 	double x, y;
 	double angle, dis;
 	Point() {}
 	Point(double x0, double y0): x(x0), y(y0) {}
 };
 
 struct Line {			   // 二维的直线或线段
 	Point p1, p2;
 	Line() {}
 	Line(Point p10, Point p20): p1(p10), p2(p20) {}
 };
 
 
 inline double max(double x,double y) {
 	return x > y ? x : y;
 }
 inline double min(double x, double y) {
 	return x > y ? y : x;
 }
 inline bool ZERO(double x) {		// x == 0
 	return (fabs(x) < EPS);
 }
 inline bool ZERO(Point p) {			//p == 0
 	return (ZERO(p.x) && ZERO(p.y));
 }
 inline bool EQ(double x, double y) {	// eqaul, x == y
 	return (fabs(x - y) < EPS);
 }
 inline bool NEQ(double x, double y)	{	// not equal, x != y
 	return (fabs(x - y) >= EPS);
 }
 inline bool LT(double x, double y) {	// less than, x < y
 	return ( NEQ(x, y) && (x < y) );
 }
 inline bool GT(double x, double y) {	// greater than, x > y
 	return ( NEQ(x, y) && (x > y) );
 }
 inline bool LEQ(double x, double y) {	// less equal, x <= y
 	return ( EQ(x, y) || (x < y) );
 }
 inline bool GEQ(double x, double y) {	// greater equal, x >= y
 	return ( EQ(x, y) || (x > y) );
 }
 
 Point operator-(Point p1, Point p2) {
 	return Point(p1.x - p2.x, p1.y - p2.y);
 }
 double operator*(Point p1, Point p2) {
 	return (p1.x * p2.y - p2.x * p1.y);
 }
 
 bool LineSegIntersect(Line L1, Line L2)
 {
 	return ( GEQ( max(L1.p1.x, L1.p2.x), min(L2.p1.x, L2.p2.x) ) &&
 		GEQ( max(L2.p1.x, L2.p2.x), min(L1.p1.x, L1.p2.x) ) &&
 		GEQ( max(L1.p1.y, L1.p2.y), min(L2.p1.y, L2.p2.y) ) &&
 		GEQ( max(L2.p1.y, L2.p2.y), min(L1.p1.y, L1.p2.y) ) &&
 		LEQ( ((L2.p1 - L1.p1) * (L1.p2 - L1.p1)) * ((L2.p2 -  L1.p1) * (L1.p2 - L1.p1)), 0 ) &&
 		LEQ( ((L1.p1 - L2.p1) * (L2.p2 - L2.p1)) * ((L1.p2 -  L2.p1) * (L2.p2 - L2.p1)), 0 ) );
 }
 
 int main() {
 	int T, n, a, b;
 	scanf("%d", &T);
 	for (int kase = 0; kase < T; ++kase) {
 		int ret = 0;
 		scanf("%d", &n);
 		vector<int> vl, vr;
 		for (int i = 0; i < n; ++i) {
 			scanf("%d%d", &a, &b);
 			vl.push_back(a);
 			vr.push_back(b);
 		}
 		for (int i = 0; i < n; ++i) {
 			for (int j = i + 1; j < n; ++j) {
 				Line l1(Point(0, vl[i]), Point(10, vr[i]));
 				Line l2(Point(0, vl[j]), Point(10, vr[j]));
 				if (LineSegIntersect(l1,l2))
 					ret ++;
 			}
 		}
 		printf("Case #%d: %d\n", kase + 1, ret);
 	}
 	return 0;
 }
 
 
