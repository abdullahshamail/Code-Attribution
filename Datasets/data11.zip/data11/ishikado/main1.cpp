#include "Qualification.h"
 #include <iostream>
 #include <vector>
 #include <fstream>
 #include <algorithm>
 
 using namespace std;
 
 int main(){
 
 	ProblemA pa;
 	pa.solve();
 
 	cout << "end" << endl;
 	int x;
 	cin >> x;
 
 	return 0;
 }