#include <iostream>
 #include <string>
 #include <sstream>
 #include <algorithm>
 using namespace std;
 
 #define debug(x) cerr<<#x<<"="<<(x)<<endl;
 
 int iswinning(int A, int B){
 	if(A<B)
 		swap(A, B);
 	if(A>=2*B)
 		return 1;
 	return !iswinning(B, A-B);
 }
 
 long long eval(){
 	int A1, A2, B1, B2;
 	cin>>A1>>A2>>B1>>B2;
 	long long res=0;
 	for(int A=A1; A<=A2; A++)
 	for(int B=B1; B<=B2; B++)
 		if(iswinning(A, B))
 			res++;
 	return res;
 }
 
 int main(){
 	int cases;
 	string line;
 	getline(cin, line);
 	istringstream(line)>>cases;
 	for(int i=1; i<=cases; i++){
 		cout<<"Case #"<<i<<": ";
 		cout<<eval()<<endl;
 	}
 	return 0;
 }
