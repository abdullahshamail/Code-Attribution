#include <iostream>
 
 using namespace std;
 
 int main()
 {
   int n,max,time,a,k,maxx,c;
   cin>>n;
   for(int i=0;i<n;i++)
   {
     max=1;
     maxx=0;
     time=0;
     c=0;
     cin>>k;
     for(int j=0;j<k;j++)
     {
       cin>>a;
       if(a==2)
         max=2;
       else if(a==3)
         max=3;
       else if(a!=1)
         time+=a/2-1;
       if(a>maxx)
         maxx=a;
       if(a!=1&&a%2==1)
         c=1;
     }
     time+=2+c;
     if(time<max)
       time=max;
     else if(time>maxx)
       time=maxx;
     cout<<"Case #"<<i+1<<": "<<time<<'\n';
   }
 
   return 0;
 }