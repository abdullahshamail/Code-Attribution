#include <algorithm>
 #include <iostream>
 #include <cmath>
 #include <cstdlib>
 #include <cctype>
 #include <string>
 #include <cstring>
 using namespace std;
 
 #define PI 3.14159265358979323846264338327950288
 #define MOD 1000
 
 
 int main()
 {
 	//freopen("C-small-attempt0.in","r",stdin);
 	//freopen("C-small-attempt0.out","w",stdout);
 	//freopen("C-large.in","r",stdin);
 	//freopen("C-large.out","w",stdout);
 	int cas,ca;
 	for(scanf("%d",&cas),ca=1;ca<=cas;ca++)
 	{
 		printf("Case #%d: ",ca);
 	}
 }
 
 
