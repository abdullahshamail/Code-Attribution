#include<bits/stdc++.h>
 using namespace std;
 
 int T,n,a;
 
 int main(){
     scanf("%d", &T);
     for(int qwe=1; qwe<=T;qwe++){
 	scanf("%d", &n);
 	int cnt[1005]={0}, ans = 1<<28, cur = 0;
 	for(int i=0; i<n;i++) { scanf("%d", &a); cnt[a]++;}
 	
 	for(int i=1004; i>=0; i--){
 	    ans = min(ans, i+cur);
 	    cur += cnt[i];
 	    if(i%2){ cnt[i/2] += cnt[i]; cnt[i/2 + 1] += cnt[i];}
 	    else cnt[i/2] += 2*cnt[i];
 	}
 	printf("Case #%d: %d\n", qwe, ans);
     }
     return 0;
 }
