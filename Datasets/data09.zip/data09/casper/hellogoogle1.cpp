#include<iostream>
 #include<algorithm>
 #include<sstream>
 #include<string>
 #include<vector>
 #include<cmath>
 #include<cstdio>
 #include<cstdlib>
 #include<fstream>
 #include<cassert>
 #include<numeric>
 #include<stack>
 #include<set>
 #include<map>
 #include<queue>
 #include<list>
 #include<deque>
 #include <algorithm>
 #include <string>
 #include <vector>
 #include <ctype.h>
 #include <math.h>
 
 
 using namespace std;
 
 
 typedef long long ll;
 
 typedef long long int64;
 typedef long double double64;
 typedef unsigned long long uint64;
 
 typedef vector<int> vi;
 typedef vector<string> vs;
 typedef pair<int, int> pii;
 typedef pair<ll, ll> pll;
 typedef pair<double, double> pdd;
 
 #define ALL(t) t.begin(),t.end()
 #define FOR(i,n) for (int i=0;i<(int)(n);i++)
 
 
 using namespace std;
 
 int main(){
 	freopen("C-large.in","r",stdin);
 	freopen("C-large.out","w",stdout);
 	int N;
 	cin >> N;
 
 	char flush[500];
 
 	string sub = " welcome to code jam";
 	cin.getline(flush, 100, '\n');
 	FOR(i, N){
 		char str[500];
 		int solve[20][501]={0};
 		FOR(j, 501){ solve[0][j] = 1; }
 
 		cin.getline(str, 500, '\n');
 		string input = str;
 		input = " " + input;
 		for(int j=1; j<=sub.size()-1; j++){
 			for(int k=1; k<=input.size()-1; k++){
 				if(input[k] == sub[j]){
 					solve[j][k] = solve[j-1][k-1] + solve[j][k-1];
 				}
 				else{
 					solve[j][k] = solve[j][k-1];
 				}
 			}
 		}
 		int result = solve[sub.size()-1][ input.size()-1];
 		char result1[5] = "0000";
 		result = result % 10000;
 		result1[0] = (result / 1000) + '0';
 		result = result % 1000;
 		result1[1] = (result / 100) + '0';
 		result = result % 100;
 		result1[2] = (result / 10) + '0';
 		result = result % 10;
 		result1[3] = result + '0';
 		cout << "Case #" << i+1 << ": " << result1 << endl;
 	}
 	
 	return 0;
 
 }
