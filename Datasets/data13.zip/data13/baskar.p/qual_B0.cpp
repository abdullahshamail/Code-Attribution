#include <vector>
 #include <list>
 #include <map>
 #include <set>
 #include <deque>
 #include <stack>
 #include <bitset>
 #include <algorithm>
 #include <functional>
 #include <numeric>
 #include <utility>
 #include <sstream>
 #include <iostream>
 #include <iomanip>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <ctime>
 
 using namespace std;
 
 #define REPEAT(i,a,b) for(int i=a;i<b;++i)
 #define REP(i,n) REPEAT(i,0,n)
 #define RREP(i,n) for(int i=n-1;i>=0;--i)
 #define EACH(it,v) for(typeof(v.begin()) it=v.begin();it!=v.end();++it)
 #define pb push_back
 #define all(x) (x).begin(),(x).end()
 #define CLEAR(x,with) memset(x,with,sizeof(x))
 #define sz size()
 #define mkp make_pair
 typedef long long ll;
 
 int main(){
 	int T;
 	cin>>T;
 	REP(x,T){
 			int E,R,N;
 			cin>>E>>R>>N;
 			int a[N];
 			REP(i,N)	cin>>a[i];
 			int used[E][N],dp[E][N];
 			int ans = -1;
 			REP(i,E)REP(j,N) used[i][j]=dp[i][j]=0;
 			int count[E];
 			REP(i,E)count[i]=0;
 			
 			REP(i,E) {
 				used[i][0] = i+1;
 				count[i] += ((i+1)*a[0]);
 				//cout<<i<<": used "<<used[i][0]<<": count"<<count[i]<<endl;
 				}
 			
 			REPEAT(i,1,N){
 				REP(j,E){
 					int lost = used[j][i-1];
 					int regained = min((E-lost+R),E);
 					//cout<<lost<<" "<<regained<<" ";
 					used[j][i] = regained;
 					count[j]+= regained*a[i];
 					//cout<<count[j]<<endl;
 					}
 				}
 			REP(i,E) ans = max(ans,count[i]);
 			cout<<"Case #"<<x+1<<": "<<ans<<endl;
 		}
 	return 0;
 	}
