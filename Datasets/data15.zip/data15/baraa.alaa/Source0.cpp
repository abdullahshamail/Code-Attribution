#define _CRT_SECURE_NO_DEPRECATE
 #include<iostream>
 #include<string>
 #include <stdio.h>
 #include<cstdlib>
 #include<queue>
 
 using namespace std;
 
 priority_queue < unsigned int > prqq;
 
 unsigned int arrr[1001] , ttt , nn1 , nn2 , nossaya , x;
 
 void inti_func()
 {
 	for (int itr = 0; itr < 1001; ++itr)
 		arrr[itr] = 0;
 }
 
 void fun()
 {
 	if (prqq.empty())
 		return;
 
 	nn2 = prqq.top();
 
 	prqq.pop();
 
 	nossaya = nn2 / 2;
 
 	x = arrr[nn2];
 
 	arrr[nn2] = 0;
 
 	if (nossaya <= x)
 	{
 		nn1 += nn2;
 		return;
 	}
 
 	if (nn2 % 2 != 0)
 	{
 		if (arrr[nossaya] == 0)
 			prqq.push(nossaya);
 
 		arrr[nossaya] += x;
 
 		if (arrr[nossaya+1] == 0)
 			prqq.push(nossaya+1);
 
 		arrr[nossaya+1] += x;
 	}
 
 	else
 	{
 		if (arrr[nossaya] == 0)
 			prqq.push(nossaya);
 
 		arrr[nossaya] += ( x * 2);
 	}
 
 	nn1 += x;
 
 	fun();
 }
 
 void clearr()
 {
 	while (!prqq.empty())
 		prqq.pop();
 }
 
 int main()
 {
 	//3
 	//	1
 	//	3
 	//	4
 	//	1 2 1 2
 	//	1
 	//	4
 
 	freopen("B-small-attempt1.in", "r" , stdin );
 
 	freopen("ttt.txt", "w", stdout);
 
 		cin >> ttt;
 
 	++ttt;
 
 	for (int itr = 1; itr < ttt; ++itr)
 	{
 		inti_func();
 
 		clearr();
 
 		cin >> nn1;
 
 
 		for (int itr2 = 0; itr2 < nn1; ++itr2)
 		{
 			cin >>nn2;
 
 			if (arrr[nn2] == 0)
 				prqq.push(nn2);
 
 			++arrr[nn2];
 
 		}
 
 
 		nn1 = 0;
 
 		fun();
 
 		cout << "Case #" << itr << ": " << nn1 << endl;
 
 
 	}
 	return 0;
 }