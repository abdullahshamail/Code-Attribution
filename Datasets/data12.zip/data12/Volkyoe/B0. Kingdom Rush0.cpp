#include"stdio.h"
 #include"stdlib.h"
 int T,cs,i,n,j,star,count,tb,max;
 bool u[1005];
 typedef struct{
     int x,y,z;
 }node;
 node a[1005],b[1005];
 int cmp(const void *p,const void *q)
 {
     if( (*(node*)p).x==(*(node*)q).x) return (*(node*)q).y-(*(node*)p).y;
     return (*(node*)p).x-(*(node*)q).x;
 }
 int main()
 {
     freopen("1.in","r",stdin);
     freopen("1.txt","w",stdout);
     scanf("%d",&T);
     //printf("%d\n",T);
     /*
     for(cs=1;cs<=T;cs++)
     {
         scanf("%d",&n);
         printf("%d\n",n);
         for(;0<n--;)
         {
             scanf("%d%d",&i,&j);
             printf("%d %d\n",i,j);
         }
     }
     return 0;*/
     for(cs=1;cs<=T;cs++)
     {
         scanf("%d",&n);
         //printf("%d\n",n);
         star=count=tb=0;
         for(i=0;i<n;i++)
         {
             scanf("%d%d",&a[i].x,&a[i].y);
             b[i].y=a[i].x;
             b[i].x=a[i].y;
             a[i].z=b[i].z=i;
             //printf("%d %d\n",a[i].x,b[i].x);
         }
         qsort(a,n,sizeof(node),cmp);
         qsort(b,n,sizeof(node),cmp);
         a[n].x=2000000000;
         a[n].z=1003;
         for(j=i=0;i<n;i++)
         {
             for(;j<=n;j++)
             {
                 //printf("b=%d a=%d bz=%d az=%d star=%d\n",b[i].x,a[j].x,b[i].z,a[j].z,star);
                 if(b[i].x<=star)
                 {
                     count++;
                     if(u[b[i].z]) star++;
                     else u[b[i].z]=1,star+=2;
                     break;
                 }
                 if(a[j].x<=star&&!u[a[j].z]) count++,u[a[j].z]=1,star++;
                 else if(a[j].x>star)
                 {
                     tb=1;
                     break;
                 }
             }
             if(tb) break;
         }
         printf("Case #%d: ",cs);
         if(tb) printf("Too Bad\n");
         else printf("%d\n",count);
         for(i=0;i<=1000;i++) u[i]=0;
     }
     scanf(" ");
 }
 /*
 100
 3
 3 4
 3 5
 0 1
 5
 0 5
 0 1
 1 1
 4 7
 5 6
 5
 0 1
 0 5
 1 1
 4 7
 5 6 
 */
