#include <stdio.h>
 #include <algorithm>
 #include <vector>
 #include <string.h>
 using namespace std;
 
 #define MAX_N 25
 #define MAX_K 45
 
 int t; int k,n;
 int sk[MAX_K];
 int openk[MAX_N];
 vector<int> keyins[MAX_N];
 
 int dp[(1<<20)+10];
 
 int doit(int bm) {
 	if (dp[bm]!=-1)
 		return dp[bm];
 	dp[bm]=0;
 	int keysAv[210];
 	
 	memset(keysAv,0,sizeof(keysAv));
 
 	for (int i=0; i<k; i++)
 		keysAv[sk[i]]++;
 
 	for (int i=0; i<n; i++)
 		if ((1<<i)&bm) {
 			keysAv[openk[i]]--;
 
 			for (int j=0; j<(int)keyins[i].size(); j++)
 				keysAv[keyins[i][j]]++;
 		}
 
 	for (int i=0; i<n; i++) {
 		if (keysAv[openk[i]]==0) continue;
 		dp[bm]|=doit(bm|(1<<i));
 	}
 	
 	return dp[bm];
 }
 
 
 int main() {
 	scanf("%d", &t);
 
 	for (int casen=1; casen<=t; casen++) {
 		scanf("%d %d", &k,&n);
 		for (int i=0; i<n; i++)
 			keyins[i].clear();
 		
 		for (int i=0; i<k; i++)
 			scanf("%d", &sk[i]);
 
 		for (int i=0; i<n; i++) {
 			int tmp;
 			scanf("%d %d", &openk[i], &tmp);
 			
 			for (int j=0; j<tmp; j++) {
 				int ktmp;
 				scanf("%d", &ktmp);
 				keyins[i].push_back(ktmp);
 			}
 		}
 
 		memset(dp,-1,sizeof(dp));
 		dp[(1<<n)-1]=1;		
 
 		printf("Case #%d:", casen);
 
 		if (doit(0)==0) {
 			printf(" IMPOSSIBLE\n");
 			continue;
 		}
 
 		int mask=0;
 		while (mask!=((1<<n)-1)) {
 			for (int i=0; i<n; i++) {
 				if (mask&(1<<i)) continue;
 				int nmask=mask|(1<<i);
 
 				if (dp[nmask]==1) {
 					printf(" %d", i+1);
 					mask=nmask;
 					break;
 				}
 			}
 		}
 		printf("\n");
 	}
 	
 	return 0;
 }
