#include <vector>
 #include <list>
 #include <map>
 #include <set>
 #include <deque>
 #include <stack>
 #include <bitset>
 #include <algorithm>
 #include <functional>
 #include <numeric>
 #include <utility>
 #include <sstream>
 #include <iostream>
 #include <iomanip>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <queue>
 #include <string>
 #include <cstring>
 #include <cassert>
 
 using namespace std;
 
 #define sz(a) int((a).size()) 
 #define pb push_back 
 #define all(c) (c).begin(),(c).end() 
 #define present(c,x) ((c).find(x) != (c).end()) 
 #define sqr(x) ((x) * (x))
 #define dist(x1, y1, x2, y2) (sqrt(sqr((x1) - (x2)) + sqr((y1) - (y2))))
 #define pow2(x) (1 << (x))
 
 const int dir[8][2] = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
 
 typedef vector<int> vi;
 typedef vector<vi> vvi;
 typedef pair<int,int> ii;
 
 const int inf = 0x7f7f7f7f;
 const double eps = 1e-9;
 
 vi like[200], type[200];
 int a[20], b[20];
 int tot, ans;
 int n, m;
 
 void init(int c)
 {
     scanf("%d", &n);
     scanf("%d", &m);
     int t, x, y;
     for (int i = 0; i < m; ++i) {
 	scanf("%d", &t);
 	like[i].clear();
 	type[i].clear();
 	while (t--) {
 	    scanf("%d%d", &x, &y);
 	    --x;
 	    like[i].pb(x);
 	    type[i].pb(y);
 	}
     }
 }
 
 void check()
 {
     for (int i = 0; i < m; ++i) {
 	bool ok = false;
 	for (int j = 0; j < sz(like[i]); ++j) {
 	    if (a[like[i][j]] == type[i][j]) {
 		ok = true;
 		break;
 	    }
 	}
 	if (!ok)
 	    return;
     }
     if (tot < ans) {
 	ans = tot;
 	memcpy(b, a, sizeof(a));
     }
 }
 
 void dfs(int d)
 {
     if (d == n) {
 	check();
 	return;
     }
     a[d] = 0;
     dfs(d + 1);
     a[d] = 1;
     ++tot;
     dfs(d + 1);
 }
 
 void run()
 {
     ans = inf;
     tot = 0;
     dfs(0);
     if (ans == inf) {
 	printf(" IMPOSSIBLE\n");
     }
     else {
 	for (int i = 0; i < n; ++i) {
 	    printf(" %d", b[i]);
 	}
 	putchar('\n');
     }
 }
 
 int main(void)
 {
     int t;
     scanf("%d", &t);
     for (int i = 1; i <= t; ++i) {
 	printf("Case #%d:", i);
 	init(i);
 	run();
     }
     return 0;
 }
 
