#include <iostream>
 #include <fstream>
 #include <string>
 
 using namespace std;
 
 int X, R, C;
 int ** matrice;
 
 bool vide(int a)
 {
     for(int i=0; i<R; i++)
         for(int j=0; j<C; j++)
             if(matrice[i][j] >= a) return false;
     return true;
 }
 
 void vider()
 {
     for(int i=0; i<R; i++)
         for(int j=0; j<C; j++)
             matrice[i][j] = 0;
 }
 
 void clean(int a)
 {
     for(int i=0; i<R; i++)
         for(int j=0; j<C; j++)
             if(matrice[i][j] >= a) matrice[i][j] = 0;
 }
 
 bool adjacent(int a, int b, int o)
 {
     if(a>0 && matrice[a-1][b] == o) return true;
     if(a<R-1 && matrice[a+1][b] == o) return true;
     if(b>0 && matrice[a][b-1] == o) return true;
     if(b<C-1 && matrice[a][b+1] == o) return true;
     return false;
 }
 
 bool done()
 {
     for(int i=0; i<R; i++)
         for(int j=0; j<C; j++)
             if(matrice[i][j] == 0) return false;
     return true;
 }
 
 void init_mat()
 {
     matrice = new int* [R];
     for(int i=0; i<R; i++) matrice[i] = new int[C];
 }
 
 void free_mat()
 {
     for(int i=0; i<R; i++)
         delete matrice[i];
     delete matrice;
 }
 
 void aff()
 {
     for(int i=0; i<R; i++)
         for(int j=0; j<C; j++)
             cout << "matrice[" << i << "][" << j << "] = " << matrice[i][j] << endl;
     cout << endl;
 }
 
 bool solvable(int a)
 {
     int omino;
     for(int i=0; i<R; i++)
     {
         omino = 0;
         for(int j=0; j<C; j++)
         {
             if(matrice[i][j] == 0 && (adjacent(i,j,a) || vide(a)))
             {
                 matrice[i][j] = a;
                 omino++;
                 if(omino == X && done()) return true;
                 if(omino == X) return solvable(a+1);
             }
         }
         clean(a);
     }
     return false;
 }
 
 bool solvable()
 {
     init_mat();
     vider();
     bool soluce = solvable(1);
     aff();
     free_mat();
     return soluce;
 }
 
 int main(int argc, char *argv[])
 {
     ifstream file_input("D-small-attempt0.in", ios::in);
     ofstream file_output("D-small-attempt0(answer).in", ios::trunc | ios::out);
     if(file_input && file_output)
     {
         int games, test=1;
         string winner;
         file_input >> games;
         while(test<=games)
         {
             file_input >> X >> R >> C;
             (solvable())? winner = "GABRIEL" : winner = "RICHARD";
             file_output << "Case #" << test << ": " << winner << "\n";
             test++;
         }
         file_input.close();
         file_output.close();
     }
     else
         cerr << "Error : Cannot open the file !" << endl;
     return 0;
 }
