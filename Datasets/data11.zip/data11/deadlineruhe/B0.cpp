/*---------------------------
 Author		: Md. Atiqul Islam (deadlineruhe)
 University 	: AIUB
 E-mail  	: deadlineruhe@gmail.com
 Problem Name:
 Algorithm  	:
 Complexity  :
 Difficulty  :
 -----------------------------*/
 #include <set>
 #include <map>
 #include <list>
 #include <cmath>
 #include <ctime>
 #include <queue>
 #include <stack>
 #include <cstdio>
 #include <vector>
 #include <cctype>
 #include <cstring>
 #include <sstream>
 #include <cstdlib>
 #include <cassert>
 #include <iostream>
 #include <algorithm>
 
 using namespace std;
 //Constant Declaration
 
 const int SIZ=1000000;
 const int INF=(1<<29);
 const double EPS = 1e-11;
 const double PI = acos(-1.0);
 /*--------------------------*/
 // some essential funtion
 /*----------------------------------*/
 void SWAP(int &a,int &b){	int t=a;a=b;b=t;}
 int MAX(int a,int b){	return a>b?a:b;  }
 int MIN(int a,int b){	return a<b?a:b;  }
 int GCD(int a,int b){	while(b){b ^= a ^=b ^= a %=b;}	return a;}
 /*----------------------------------*/
 
 int main()
 {
 	freopen("B-small-attempt2.in","r",stdin);
 	freopen("B.out","w",stdout);
 	int ind,test,n,i,m,o,c,d,j,k;
 	char A[40][5],B[30][4],C[SIZ],D[SIZ];
 	char L[9] = {'Q', 'W', 'E', 'R', 'A', 'S', 'D', 'F'};
 	map<char,int>M,M1;
 	M['Q'] = 1,M['W'] = 1,M['E'] = 1,M['R'] = 1,M['A'] = 1,M['S'] = 1,M['D'] = 1,M['F'] = 1;
 
 	scanf("%d",&test);
 	for(ind = 1; ind <= test ;ind++){
 		scanf("%d",&c);
 		for(i = 0; i < c; i++){
 			scanf("%s",A[i]);
 		}
 		scanf("%d",&d);
 		for(i = 0; i < d; i++){
 			scanf("%s",B[i]);
 		}
 		scanf("%d",&n);
 		scanf("%s", C);
 		for(i = 0; i < d; i++){
 			for(j = 0; j < n - 1; j++){
 				if(C[j] == B[i][0]){
 					if(C[j+1] == B[j][1]){
 						C[j] = 0, C[j + 1] = 0;
 					} else if( j + 2 < n && C[j + 2] == B[i][1]){
 						C[j] = 0;
 						C[j + 2] = 0;
 						C[j+1] = 0;
 					}
 				}else if(C[j] == B[i][1]){
 					if(C[j+1] == B[j][0]){
 						C[j] = 0, C[j + 1] = 0;
 					} else if( j + 2 < n && C[j + 2] == B[i][0]){
 						C[j] = 0;
 						C[j + 2] = 0;
 						C[j+1] = 0;
 					}
 				}
 			}
 		}
 		for(i = j = 0; i < c; i++){
 			for(j = 0; j < n - 1; j++){
 				if((C[j] == A[i][0] && C[j+1] == A[i][1]) || (C[j+1] == A[i][0] && C[j] == A[i][1])){
 					C[j] = A[i][2];
 					M1[A[i][2]] = 1;
 					C[j + 1] = 0;
 				}
 			}
 		}
 		for(i = j = 0; i < n; i++){
 			if(C[i] != 0 && (M[C[i]] || M1[C[i]])) D[j++] = C[i];
 		}
 		D[j] = 0;
 		printf("Case #%d: [",ind);
 		if(D[0] == 0)printf("]\n");
 		else{
 			printf("%c",D[0]);
 			for(i = 1; i < j; i++){
 				printf(", %c",D[i]);
 			}
 			printf("]\n");
 		}
 		M1.clear();
 	}
 	return 0;
 }
