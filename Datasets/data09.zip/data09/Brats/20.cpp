#include<iostream.h>
 #include<string>
 using namespace std;
 
 int i,j,k,N;
 int R, F, C, c;
 string block[11];
 string end = "######";
 /* state :
          0 - came from right
          1 - came from left
          2 - fell
          */
 
 int rec(int i, int j, int state)
 {
     int D=-1;
     if(i == R-1)
         return 0;
     //go left
     if(state!=1 && j>0 && block[i][j-1]=='.')
     {
         if(block[i+1][j-1] == '#')
         {
             int D1 = rec(i, j-1, 0);
             if(D==-1 || D1<D)
                 D=D1;
         }
         else
         {
             int l=0;
             for(k=i+1; block[k][j-1]=='.'; k++) l++;
             if(l<=F)
             {
                 int D1 = rec(k-1, j-1, 2);
                 if(D==-1 || D1<D)
                          D=D1;
             }
         }
     }
     // go right
     if(state!=0 && j<C-1 && block[i][j+1]=='.')
     {
         if(block[i+1][j+1] == '#')
         {
             int D1 = rec(i, j+1, 1);
             if(D==-1 || D1<D)
                 D=D1;
         }
         else
         {
             int l=0;
             for(k=i+1; block[k][j+1]=='.'; k++) l++;
             if(l<=F)
             {
                 int D1 = rec(k-1, j+1, 2);
                 if(D==-1 || D1<D)
                          D=D1;
             }
         }
     }
     // dig right
     if( j+1<C && block[i][j+1]=='.' && block[i+1][j+1]=='#' )
     {
         block[i+1][j+1] = '.';
         int D1 = 1 + rec(i, j, 2);
         if(D1>0 && (D==-1 || D1<D))
             D=D1;
         block[i+1][j+1] = '#';
     }
     // dig left
     if( j>0 && block[i][j-1]=='.' && block[i+1][j-1]=='#' )
     {
         block[i+1][j-1] = '.';
         int D1 = 1 + rec(i, j, 2);
         if(D1>0 && (D==-1 || D1<D))
             D=D1;
         block[i+1][j-1] = '#';
     }
     
     return D;
 }
     
 int main()
 {
     cin>>N;
     for(c=1; c<=N; c++)
     {
         cin>>R>>C>>F;
         for(i=0; i<R; i++)
             cin>>block[i];
         block[R] = end;
         
         int D = rec(0,0,2);
         
         cout<<"Case #"<<c<<": ";
         
         if(D==-1)
             cout<<"No\n";
         else
             cout<<"Yes "<<D<<endl;
     }
 }
