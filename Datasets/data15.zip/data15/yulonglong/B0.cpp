#include <cstdio>
 #include <vector>
 using namespace std;
 
 int main() {
 	int tc; scanf("%d",&tc);
 	for(int d=1; d<=tc; d++ ){
 		int n; scanf("%d",&n);
 		vector<int> pancake;
 		for(int i=0;i<n;i++){
 			int temp; scanf("%d",&temp);
 			pancake.push_back(temp);
 		}
 
 		bool end = false;
 		int t = 0;
 		while(!end){
 			int maxPancake = 0;
 			int maxIndex = -1;
 			for(int i=0;i<(int)pancake.size();i++){
 				if(maxPancake < pancake[i]) {
 					maxPancake = pancake[i];
 					maxIndex = i;
 				}
 			}
 			if (maxPancake >= 4) {
 				int pancakeTaken = pancake[maxIndex]/2 + pancake[maxIndex]%2;
 				pancake[maxIndex] -= pancakeTaken;
 				pancake.push_back(pancakeTaken);
 				t++;
 			}
 			else {
 				end = true;
 				for(int i=0;i<(int)pancake.size();i++){
 					if(pancake[i] > 0) {
 						pancake[i]--;
 						end = false;
 					}
 				}
 				t++;
 			}
 		}
 
 		printf("Case #%d: %d\n",d,t-1);
 	}
 	return 0;
 }