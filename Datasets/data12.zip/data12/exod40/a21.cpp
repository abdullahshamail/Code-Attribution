#include <iostream>
 #include <cmath>
 #include <algorithm>
 
 using namespace std;
 
 pair < pair < int, double >, int > p[1024];
 int N;
 
 void scan(){
     cin >> N;
 
     for ( int i = 0; i < N; ++i )
         cin >> p[i].first.first;
 
     for ( int i = 0; i < N; ++i ){
         cin >> p[i].first.second;
         p[i].second = i;
     }
 
 }
 
 bool f ( pair < pair < int, double >, int >  t1, pair < pair < int, double >, int >  t2 ){
     if ( fabs ( ( 1. - t2.first.second / 100 ) * t1.first.first +  t2.first.first -
         ( 1. - t1.first.second / 100 ) * t2.first.first + t1.first.first ) < 1e-9 )
             return t1.second < t2.second;
 
     return ( 1. - t2.first.second / 100 ) * t1.first.first +  t2.first.first >
            ( 1. - t1.first.second / 100 ) * t2.first.first + t1.first.first;
 
 }
 void solve(){
     sort ( p, p + N, f );
 
     for ( int i = 0; i < N; ++i )
         cout << p[i].second << " ";
     cout << endl;
 }
 
 int main(){
     int tests;
     cin >> tests;
 
     for ( int i = 0; i < tests; ++i ){
         scan();
         cout << "Case #" << i + 1 << ": ";
         solve();
     }
 }
