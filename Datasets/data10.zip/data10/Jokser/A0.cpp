#include<iostream>
 #include<vector>
 #include<queue>
 #include<set>
 #include<cstdio>
 #include<algorithm>
 #include<string>
 #include<map>
 #include<cmath>
 #include<cstdlib>
 #include<ctime>
 using namespace std;
 
 bool p[11];
 int a[11];
 int j,k,n,t,i,r=0;
 
 int main() {
 	freopen("input.txt", "rt", stdin);
 	freopen("output.txt", "wt", stdout);
 	cin >> t;
 	for (j=0;j<t;j++) {
 		cin >> n >> k;
 		for (i=0;i<=n;i++) {
 			p[i]=false; a[i]=0; }
 		p[1]=true;
 		for (i=0;i<k;i++) {
 			if (i%2==0) {
 				p[1]=true; 
 				a[1]=1;
 				for (int it=2;it<=n;it++)
 					if (p[it-1] && a[it-1]==1) p[it]=true;
 			} else 
 			{
 				for (int it=n;it>=1;it--)
 					if (p[it]) {p[it]=false; a[it]=1-a[it]; }
 			}
 		}
 		cout << "Case #" << j+1 << ": ";
 		if (p[n] && a[n]==1) cout << "ON" << endl; else cout << "OFF" << endl;
 	}
 	return 0;
 }
