#include <cstdio>
 #include <algorithm>
 #include <iostream>
 #include <string>
 #include <cstring>
 #include <vector>
 #include <set>
 #include <map>
 #include <cmath>
 
 using namespace std;
 
 typedef long long ll;
 typedef pair<int, int> pii;
 typedef vector<int> vi;
 
 int T;
 
 const int inf = 1000000;
 
 int D, I, m, n;
 int a[110];
 
 int x[110];
 
 int check(const vi &p)
 {
   vi v;
   for (int i = 0; i < n; ++i)
     if (p[i] == 1)
       v.push_back(a[i]);
   bool b = true;
   for (int i = 1; i < v.size(); ++i)
     if (abs(v[i] - v[i-1]) > m)
       b = false;
   if (b)
     return 0;
   int res = inf;
 
   int mx = 0;
   for (int i = 0; i < v.size(); ++i)
 	  mx = max(mx, v[i]);
   if (m == 0)
   {
 	  for (int u = 0; u <= mx; ++u)
 	  {
 		  int h = 0;
 		  for (int i = 0; i < v.size(); ++i)
 			  h += abs(v[i] - u);
 		  res = min(res, h);
 	  }
   }
   else 
   {
 	  int h = 0;
 	  for (int i = 1; i < v.size(); ++i)
 	  {
 		  int e = abs(v[i] - v[i-1])/m;
 		  if ((abs(v[i] - v[i-1])%m) == 0)
 			  --e;
 		  int h1 = e*I;
 		  int h2 = min(abs(v[i] - (v[i-1] - m)), abs(v[i] -  (v[i-1] + m)));
 		  if (h2 < h1)
 		  {
 			  h += h2;
 			  if (abs(v[i] - (v[i-1] - m)) < abs(v[i] - (v[i-1] + m)))
 				  v[i] = v[i-1] - m;
 			  else
 				  v[i] = v[i-1] + m;
 		  }
 		  else
 		  {
 			  h += h1;
 		  }
 	  }
 	  res = min(res, h);
   }
   
   return res;
 }
 
 int main()
 {
   scanf("%d", &T);
   for (int t = 0; t < T; ++t)
   {
     scanf("%d %d %d %d", &D, &I, &m, &n);
     for (int i = 0; i < n; ++i)
       scanf("%d", &a[i]);
     int res = inf;
     for (int x1 = 0; x1 < 2; ++x1)
       for (int x2 = 0; x2 < 2; ++x2)
         for (int x3 = 0; x3 < 2; ++x3)
         {
           vi p;
           p.push_back(x1);
           p.push_back(x2);
           p.push_back(x3);
           int g = check(p);
           
           
             int s = 0;
             for (int j = 0; j < n; ++j)
               if (p[j] == 0)
                 s += D;
             res = min(res, s + g);
           
         }
     printf("Case #%d: %d\n", t+1, res);
   }
   return 0;
 }