#include<iostream>
 #include<fstream>
 #include<vector>
 using namespace std;
 
 int main() {
 
     ifstream infile("temp.txt");
 
 
     int num;
     infile>>num;
 
 
 
 
     for (int i = 0; i < num; i++) {
         int D;
         infile>>D;
 
         vector<int> P;
         int min = 10001;
         int max = 0;
         int minutes = 0;
 
         int hash[1000];
         for (int i = 0; i < 1000; i++)
             hash[i] = 0;
 
         for (int j = 0; j < D; j++) {
             int data;
             infile>>data;
             P.push_back(data);
 
             if (data < min)
                 min = data;
             if (data > max)
                 max = data;
 
             hash[data]++;
         }
 
         while (true) {
 
             //cout << "mm> " << min << ":" << max << ":" << minutes << "\n";
             if (min == 1 || (max - min > 1)) {
                 minutes++;
                 max = 0;
                 min = 10001;
                 for (std::vector<int>::iterator it = P.begin(); it != P.end(); ++it) {
 
                     hash[*it] = hash[*it] - 1;
                     *it -= 1;
                     hash[*it]++;
 
                     if (*it > 0 && *it < min)
                         min = *it;
 
                     if (*it > max)
                         max = *it;
 
                 }
             } else if (min == max) {
 
                 //cout << "here hash:" << hash[min] << "\n";
                 if (hash[min] >= (min - min / 2)) {
 
 
 
                     minutes++;
                     max = 0;
                     min = 10001;
                     for (std::vector<int>::iterator it = P.begin(); it != P.end(); ++it) {
 
                         hash[*it] = hash[*it] - 1;
                         *it -= 1;
                         hash[*it]++;
 
                         if (*it > 0 && *it < min)
                             min = *it;
 
                         if (*it > max)
                             max = *it;
 
                     }
 
 
                 } else {
                     minutes++;
 
                     int toRemove = max / 2;
 
                     hash[max]--;
                     hash[max - toRemove] = hash[max - toRemove] + 1;
 
                     int flag = 0;
                     int tofind = max;
                     max = 0;
                     min = 10001;
                     //cout << "toremove: " << toRemove << "\n";
                     for (std::vector<int>::iterator it = P.begin(); it != P.end(); ++it) {
 
                         if (flag == 0 && *it == tofind) {
                             *it = *it - toRemove;
                             flag = 1;
                         }
                         if (*it > 0 && *it < min)
                             min = *it;
                         if (*it > max)
                             max = *it;
                     }
 
                     //cout << "\n";
                 }
             } else {
                 minutes++;
 
                 int toRemove = max / 2;
 
 
                 hash[max - toRemove] = hash[max - toRemove] - 1;
 
                 int flag = 0;
                 int tofind = max;
                 max = 0;
                 min = 10001;
                 //cout << "toremove: " << toRemove << "\n";
                 for (std::vector<int>::iterator it = P.begin(); it != P.end(); ++it) {
 
                     if (flag == 0 && *it == tofind) {
                         *it = *it - toRemove;
                         flag = 1;
                     }
                     if (*it > 0 && *it < min)
                         min = *it;
                     if (*it > max)
                         max = *it;
                 }
 
                 //cout << "\n";
             }
 
 
             int flag = 0;
             for (std::vector<int>::iterator it = P.begin(); it != P.end(); ++it) {
                 //cout<<*it<<" ";
                 if (*it > 0) {
                     flag = 1;
                     break;
                 }
 
             }
             //int x;
             //cin>>x;
             if (flag == 0)
                 break;
         }
 
 
         cout << "Case #" << i + 1 << ": " << minutes << "\n";
     }
 
 
     return 0;
 }