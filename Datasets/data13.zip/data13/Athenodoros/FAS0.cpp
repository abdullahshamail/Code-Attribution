#include <stdio.h>
 #include <stdlib.h>
 #include <iostream>
 #include <fstream>
 #include <string>
 using namespace std;
 
 int palindrome();
 
 int main() 
 {
     int loops, counter, top, bottom;
     ifstream myfile("C-small-attempt1.in");
     ofstream outputfile;
     outputfile.open("output.txt");
     myfile >> loops;
 
     for (int loopnumber = 0; loopnumber < loops; loopnumber++)
     {
         myfile >> bottom >> top;
         counter = 0;
         if (top >= 1)
             counter++;
         if (top >= 4)
             counter++;
         if (top >= 9)
             counter++;
         if (top >= 121)
             counter++;
         if (top >= 484)
             counter++;
         if (bottom > 1)
             counter--;
         if (bottom > 4)
             counter--;
         if (bottom > 9)
             counter--;
         if (bottom > 121)
             counter--;
         if (bottom > 484)
             counter--;
 
         outputfile << "Case #" << loopnumber+1 << ": " << counter << endl;
     }
 
     outputfile.close();
 
     return 0;
 }
