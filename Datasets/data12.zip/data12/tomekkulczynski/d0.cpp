
 // Tomasz Kulczynski
 #include <cstdio>
 #include <iostream>
 #include <cstring>
 #include <algorithm>
 #include <vector>
 #include <set>
 #include <map>
 #include <string>
 #include <cmath>
 #include <cstdlib>
 #include <numeric>
 using namespace std;
 
 #define X first
 #define Y second
 #define MP make_pair
 #define PB push_back
 typedef long long LL;
 typedef double D;
 typedef long double LD;
 typedef vector<int> VI;
 typedef pair<int,int> PII;
 #define REP(i,n) for (int i=0;i<(n);++i)
 #define FOR(i,a,b) for (VAR(i,a);i<=(b);++i)
 #define FORD(i,a,b) for(VAR(i,a);i>=(b);--i)
 #define FORE(e,v) for(VAR(e,(v).begin());e!=(v).end();++e)
 #define VAR(a,b) __typeof(b) a=(b)
 #define SIZE(a) ((int)(a).size())
 #define ALL(x) (x).begin(),(x).end()
 #define CLR(x,a) memset(x,a,sizeof(x))
 
 #include <cassert>
 
 int xx[3] = {0, 0, 1}, yy[3] = {-1, 1, 0};
 
 bool moge(int k, const vector<VI>& c, const vector<VI> &czy, const vector<string>& s) {
     bool rusza = false;
     int n = SIZE(s) , m = SIZE(s[0]);
     REP(i, n) REP(j, m) if(c[i][j]) {
         if(s[i + xx[k]][j + yy[k]] == '#') 
             continue;
         if(!czy[i + xx[k]][j + yy[k]])
             return false;
         rusza = true;
     }
     return rusza;
 }
 
 void ruch(int k, vector<VI>& c, const vector<VI> &czy, const vector<string> &s) {
     int n = SIZE(s) , m = SIZE(s[0]);
     vector<VI> nc = vector<VI>(n, VI(m, 0));
     REP(i, n) REP(j, m) if(c[i][j]) {
         if(s[i + xx[k]][j + yy[k]] == '#') {
             nc[i][j] = 1;
             continue;
         }
         assert(czy[i + xx[k]][j + yy[k]]);
         nc[i + xx[k]][j + yy[k]] = 1;
     }
     c = nc;
 }
 
 vector<VI> czy;
 
 void dfs(int x, int y, const vector<string> &s) {
     czy[x][y] = 1;
     if(!czy[x-1][y] && s[x-1][y] != '#')
         dfs(x-1, y, s);
     if(!czy[x][y-1] && s[x][y-1] != '#')
         dfs(x, y-1, s);
     if(!czy[x][y+1] && s[x][y+1] != '#')
         dfs(x, y+1, s);
 }
 
 pair<int, bool> szuk(const vector<string> &s, int n, int m, int cc) {
     int cx = -1, cy = -1;
     REP(i, n) REP(j, m) if(s[i][j] == cc + '0') cx = i, cy = j;
     czy = vector<VI>(n, VI(m, 0));
     dfs(cx, cy, s);
     bool lucky = 0;
     int re = 0;
     REP(i, n) REP(j, m) if(czy[i][j]) re++;
     vector<VI> c = czy;
     bool ok = 1;
     while(ok) {
         ok = 0;
         int x1 = 0;
         REP(i, n) REP(j, m) if(c[i][j]) x1++;
         while(moge(0, c, czy, s)) ruch(0, c, czy, s);
         while(moge(1, c, czy, s)) ruch(1, c, czy, s);
         int x2 = 0;
         REP(i, n) REP(j, m) if(c[i][j]) x2++;
         if(x2 < x1) {
             ok = 1;
             continue;
         }
         while(1) {
             if(moge(2, c, czy, s)) {
                 ruch(2, c, czy, s);
                 ok = 1;
                 break;
             }
             if(!moge(0, c, czy, s))
                 break;
             ruch(0, c, czy, s);
         }
     }
     int x1 = 0;
     REP(i, n) REP(j, m) if(c[i][j]) x1++;
     if(x1 == 1) 
         lucky = true;
     return MP(re, lucky);
 }
 
 int main() {
     int tt;
     scanf("%d",&tt);
     char buf[113];
     FOR(cas, 1, tt) {
         int n,m;
         scanf("%d %d",&n,&m);
         vector<string> s(n);
         REP(i, n) {
             scanf("%s", buf);
             s[i] = buf;
         }
         int d = 0;
         REP(i, n) REP(j, m) if(s[i][j] <= '9') d = max(d, s[i][j] - '0' + 1);
         printf("Case #%d:\n",cas);
         REP(i, d) {
             pair<int, bool> r = szuk(s, n, m, i);
             printf("%d: %d %s\n", i, r.X, r.Y ? "Lucky" : "Unlucky");
         }
     }
     return 0;
 }
