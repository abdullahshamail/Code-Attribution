#include<cstdio>
 #include<iostream>
 #include<fstream>
 #include<sstream>
 #include<vector>
 #include<stack>
 #include<deque>
 #include<queue>
 #include<string>
 #include<list>
 #include<algorithm>
 #include<numeric>
 #include<cstdlib>
 #include<cmath>
 #include<set>
 #include<map>
 #include<ctime>
 #include<utility>
 using namespace std;
 
 #define pb push_back
 #define mp make_pair
 #define sz(x) ((int)x.size())
 #define all(qq) qq.begin(),qq.end()
 #define rall(qq) qq.rbegin(),qq.rend()
 #define clr(qq) memset((qq),0,sizeof(qq))
 #define fill(qq) memset((qq),0x3F,sizeof(qq))
 #define mset(qq,h) memset((qq),h,sizeof(qq))
 #define rep(i,n) for(int i=0;i<(int)(n);i++)
 #define repd(i,n) for(int i=(int)(n-1);i>=0;i--)
 #define rep2(i,a,b) for(int (i)=(int)(a);i<(int)(b);i++)
 #define fore(it,c) for(__typeof((c).begin()) it=(c).begin(); it!=(c).end(); it++)
 
 #define REP(i,n) for(__typeof(n) i=0;i<(n);++i)
 #define REPS(i,n) for(int(i)=0;i<int(n.size());++i)
 #define FOR(i,a,b) for(__typeof(b) i=(a);i<=(b);++i)
 #define FORD(i,a,b) for(__typeof(a) i=(a);i>=(b);--i)
 #define FORE(it,c) for(__typeof((c).begin()) it=(c).begin();it!=(c).end();++it)
 
 #define rint(qq) int(floor(qq+0.5))
 #define sqr(qq) ((qq) * (qq))
 #define LL long long
 #define LD long double
 #define inf 999999999
 #define pii pair<int,int>
 #define fi first
 #define se second
 #define PI 3.1415926535897932384626433832795
 #define EPS 1e-11
 
 int C;
 int N,M;
 int S[30][30],W[30][30],T[30][30];
 int K[30][30][2][2];
 
 int main ()
 {
 	scanf("%d",&C);
 	rep(t,C)
 	{
 		scanf("%d%d",&N,&M);
 		rep(i,N)
 		{
 			rep(j,M)
 			{
 				K[i][j][0][0]=K[i][j][0][1]=K[i][j][1][0]=K[i][j][1][1]=100100100;
 				scanf("%d%d%d",&S[i][j],&W[i][j],&T[i][j]);
 				T[i][j]%=S[i][j]+W[i][j];
 			}
 		}
 		K[N-1][0][1][0]=0;
 		int cas=0;
 		while(K[0][M-1][0][1]!=cas)
 		{
 			rep(i,N) rep(j,M)
 			{
 				int x=cas-T[i][j];
 				if (x<0) x+=S[i][j]+W[i][j];
 				if (K[i][j][0][0]<=cas)
 				{
 					if (i) K[i-1][j][1][0]<?=cas+2;
 					if (j) K[i][j-1][0][1]<?=cas+2;
 					if (x%(S[i][j]+W[i][j])<S[i][j]) K[i][j][1][0]<?=cas+1;
 					else K[i][j][0][1]<?=cas+1;
 				}
 				if (K[i][j][0][1]<=cas)
 				{
 					if (i) K[i-1][j][1][1]<?=cas+2;
 					K[i][j+1][0][0]<?=cas+2;
 					if (x%(S[i][j]+W[i][j])<S[i][j]) K[i][j][1][1]<?=cas+1;
 					else K[i][j][0][0]<?=cas+1;
 				}
 				if (K[i][j][1][0]<=cas)
 				{
 					K[i+1][j][0][0]<?=cas+2;
 					if (j) K[i][j-1][0][1]<?=cas+2;
 					if (x%(S[i][j]+W[i][j])<S[i][j]) K[i][j][0][0]<?=cas+1;
 					else K[i][j][1][1]<?=cas+1;
 				}
 				if (K[i][j][1][1]<=cas)
 				{
 					K[i+1][j][0][1]<?=cas+2;
 					K[i][j+1][1][0]<?=cas+2;
 					if (x%(S[i][j]+W[i][j])<S[i][j]) K[i][j][0][1]<?=cas+1;
 					else K[i][j][1][0]<?=cas+1;
 				}
 			}
 			++cas;
 		}
 		printf("Case #%d: %d\n",t+1,cas);
 	}
 	return 0;
 }
