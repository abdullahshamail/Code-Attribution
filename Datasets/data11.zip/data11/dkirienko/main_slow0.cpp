#include<iostream>
 
 using namespace std;
 
 int R, C, D;
 long long Map[500][500];
 
 void read()
 {
     cin >> R >> C >> D;
     char c;
     for(int i = 0; i < R; ++i)
         for(int j = 0; j < C; ++j)
         {
             cin >> c;
             Map[i][j] = c - '0';
         }
 }
 
 int solve()
 {
     int ans = 0;
     int k, startx, starty, x, y;
     long long sumx, sumy, sum;
     for (k = 3; k <= R && k <= C; ++k)
     {
         for(startx = 0; startx + k <= R; ++startx)
         {
             for(starty = 0; starty + k <= C; ++starty)
             {
                 sumx = 0;
                 sumy = 0;
                 sum = 0;
                 for(x = 0; x < k; ++x)
                     for(y = 0; y < k; ++y)
                     {
                         sumx += (startx + x) * Map[startx + x][starty + y];
                         sumy += (starty + y) * Map[startx + x][starty + y];
                         sum += Map[startx + x][starty + y];
                     }
                 sumx -= (startx + 0) * Map[startx + 0][starty + 0];
                 sumx -= (startx + k - 1) * Map[startx + k - 1][starty + 0];
                 sumx -= (startx + 0) * Map[startx + 0][starty + k - 1];
                 sumx -= (startx + k - 1) * Map[startx + k - 1][starty + k - 1];
                 sumy -= (starty + 0) * Map[startx + 0][starty + 0];
                 sumy -= (starty + k - 1) * Map[startx + 0][starty + k - 1];
                 sumy -= (starty + 0) * Map[startx + k - 1][starty + 0];
                 sumy -= (starty + k - 1) * Map[startx + k - 1][starty + k - 1];
                 sum -= Map[startx + 0][starty + 0];
                 sum -= Map[startx + 0][starty + k - 1];
                 sum -= Map[startx + k -1 ][starty + 0];
                 sum -= Map[startx + k - 1][starty + k - 1];
 
                 if (  (2 * startx + k - 1) * sum == 2 * sumx &&
                       (2 * starty + k - 1) * sum == 2 * sumy &&
                       k > ans)
                     ans = k;
             }
         }
     }
     return ans;
 }
 
 int main()
 {
     int T;
     cin >> T;
     int num;
     for(num = 1; num <= T; ++num)
     {
         read();
         cout << "Case #" << num << ": ";
         int ans = solve();
         if(ans == 0)
             cout << "IMPOSSIBLE" << endl;
         else
             cout << ans << endl;
     }
 }
