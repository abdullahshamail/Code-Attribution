#include <cstdio>
 #include <cmath>
 #include <algorithm>
 #include <cstdlib>
 #include <set>
 #include <queue>
 #include <vector>
 #include <cstring>
 #include <string>
 #include <map>
 #include <iostream>
 
 using namespace std;
 
 int main() {
 	int t,c,d,n,tes=1;
 	char magic[105],gabung[3],hancur[3],x;
 	
 	scanf("%d",&t);
 	while (t--) {
 		scanf("%d",&c);
 		for (int i=0;i<c;i++) {
 			scanf("%s",&gabung);	
 		}	
 		scanf("%d",&d);
 		for (int i=0;i<d;i++) {
 			scanf("%s",&hancur);	
 		}
 		scanf("%d",&n); getchar();
 		vector <int> vec;
 		for (int i=0;i<n;i++) {
 			scanf("%c",&x);	
 			if (vec.empty()) vec.push_back(x); else {
 			if (c>=1 && ((vec.back()==gabung[0] && x==gabung[1]) || (vec.back()==gabung[1] && x==gabung[0])) ) {
 					vec.pop_back();
 					vec.push_back(gabung[2]);	
 			} else {
 					int pos=-1;
 					for (int i=0;i<vec.size();i++) {
 						if ((vec[i]==hancur[0] && x==hancur[1]) ||	(vec[i]==hancur[1] && x==hancur[0])) {pos=i; break;}
 					}
 					if (pos!=-1) {
 					vec.clear();
 					}
 					else vec.push_back(x);	
 			}	
 			}
 		}
 		printf("Case #%d: [",tes++);
 		for (int i=0;i<vec.size();i++) if (i==0) printf("%c",vec[i]);else printf(", %c",vec[i]);
 		printf("]\n");
 		}
 	return 0;
 }
