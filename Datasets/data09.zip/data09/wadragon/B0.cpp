#include<stdio.h>
 #include<algorithm>
 #include<math.h>
 
 using namespace std;
 
 int main()
 {
 	int i,j,k,l;
 	int T,N;
 	long long Sx,Sy,Sz,Svx,Svy,Svz;
 	long long a,b,c,d;
 	double tmin, dmin;
 
 	scanf("%d", &T);
 	for(l=0;l<T;l++)
 	{
 		scanf("%d", &N);
 
 		Sx=0,Sy=0,Sz=0,Svx=0,Svy=0,Svz=0;
 		for(i=0;i<N;i++)
 		{
 			scanf("%lld",&d);
 			Sx+=d;
 			scanf("%lld",&d);
 			Sy+=d;
 			scanf("%lld",&d);
 			Sz+=d;
 			scanf("%lld",&d);
 			Svx+=d;
 			scanf("%lld",&d);
 			Svy+=d;
 			scanf("%lld",&d);
 			Svz+=d;
 		}
 
 		a = Svx*Svx + Svy*Svy + Svz*Svz;
 		b = Sx*Svx + Sy*Svy + Sz*Svz;
 		c = Sx*Sx + Sy*Sy + Sz*Sz;
 
 		if(a==0){
 			tmin=0;
 			dmin = (double)(c);
 			dmin = sqrt(dmin)/N;
 
 		}
 		else{
 		tmin = -(double)(b)/(double)(a);
 
 		dmin = c + 2*tmin*b + tmin*tmin*a;
 		dmin = sqrt(dmin)/N;
 		}
 
 		printf("Case #%d: %.8lf %.8lf\n", l+1,dmin,tmin);
 
 
 
 	}
 
 	return 0;
 }