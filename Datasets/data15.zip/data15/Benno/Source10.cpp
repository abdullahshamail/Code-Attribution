#include <iostream>
 #include <algorithm>
 #include <functional>
 #include <vector>
 #include <stdio.h>
 #include <string>
 #include <set>
 using namespace std;
 
 int main()
 {
 	FILE* handle;
 	freopen_s(&handle, "input.txt", "r", stdin);
 	freopen_s(&handle, "output.txt", "w", stdout);
 
 	int res = 0;
 	long long cases = 0, counter = 0;
 	cin >> cases;
 
 	while (counter < cases)
 	{
 		res = 0;
 		bool gab = false;
 		int X, R, C;
 		cin >> X >> R >> C;
 
 		if (X == 1)
 			gab = true;
 		
 		if (X == 2 && (R % X == 0 || C % X == 0))
 			gab = true;
 
 		if (X == 3 && ((R * C) % 6 == 0) && R > 1 && C > 1)
 			gab = true;
 
 		if (gab == false)
 			cout << "Case #" << counter + 1 << ": RICHARD";
 		else
 			cout << "Case #" << counter + 1 << ": GABRIEL";
 		cout << endl;
 
 		counter++;
 	}
 	return 0;
 }
