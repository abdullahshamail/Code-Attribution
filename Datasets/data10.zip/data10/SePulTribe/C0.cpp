#include <algorithm>
 #include <cstdio>
 #include <list>
 #include <utility>
 
 using namespace std;
 
 int T, yy, R, N, ii, t, end, len;
 list<pair<int, int> > q;
 list<pair<list<int>, long long> > part;
 list<pair<list<int>, long long> >::iterator it, it1;
 list<int> temp;
 long long total, otot, ans, k, stot;
 
 int main(void)
 {
     scanf("%d\n", &T);
     for (yy = 1; yy <= T; yy++)
     {
         scanf("%d %lld %d\n", &R, &k, &N);
         for (ii = 0; ii < N; ii++)
         {
             scanf("%d ", &t);
             q.push_back(make_pair(t, ii));
         }
 
         while (1)
         {
             total = 0;
             temp.clear();
             
             while (total + q.front().first <= k && find(temp.begin(),
                 temp.end(), q.front().second) == temp.end())
             {
                 temp.push_back(q.front().second);
                 total += q.front().first;
                 q.push_back(q.front());
                 q.pop_front();
             }
             if (!part.empty() && (it1 = find(part.begin(), part.end(),
                 make_pair(temp, total))) != part.end())
                 break;
             part.push_back(make_pair(temp, total));
         }
 
         
         stot = 0;
         for (it = part.begin(), ii = 0; ii < R && it != part.end();
         ii++, it++)
             stot += it->second;
 
         ans = stot;
 
         R -= ii;
 
         otot = 0;
         for (it = it1, len = 0; it != part.end(); it++, len++)
             otot += it->second;
 
         ans += otot * (R / len);
         end = R % len;
         for (ii = 0, it = it1; ii < end; ii++)
             ans += it->second;
 
         printf("Case #%d: %lld\n", yy, ans);
 
         q.clear();
         part.clear();
     }
 
     return 0;
 }
