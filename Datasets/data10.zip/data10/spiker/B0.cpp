#include <cstdio>
 #include <string>
 #include <vector>
 #include <memory>
 #include <cmath>
 #include <algorithm>
 #include <set>
 #include <deque>
 #include <stack>
 #include <numeric>
 #include <functional>
 #include <map>
 #include <queue>
 using namespace std;
 int main(void)
 {
 	freopen("Bsm.in","r",stdin);
 	freopen("Bsm.out","w",stdout);
 	int t,d,o,m,n,i,a,cost,c1,c2,c3,q;
 	vector<int> v;
 	scanf("%d",&t);
 	for (q=1;q<=t;q++)
 	{
 		v.clear();
 		scanf("%d%d%d%d",&d,&o,&m,&n);
 		for (i=0;i<n;i++)
 		{
 			scanf("%d",&a);
 			v.push_back(a);
 		}
 		cost=0;
 		for (i=1;i<n;i++)
 		{
 			if (abs(v[i-1]-v[i])>m)
 			{
 				c1=abs(v[i]-v[i-1])-m;
 				c2=d;
 				if (m!=0)
 					c3=(abs(v[i]-v[i-1])-1)/m*o; else
 					c3=2000000000;
 				if ((c1<=c2)&&(c1<=c3))
 				{
 					cost+=c1;
 					if (v[i]>v[i-1])
 						v[i]=v[i-1]+m; else
 						v[i]=v[i-1]-m;
 				} else
 				if ((c2<=c1)&&(c2<=c3))
 				{
 					cost+=c2;
 					v[i]=v[i-1];
 				} else
 				if ((c3<=c1)&&(c3<=c2))
 					cost+=c3;
 			}
 		}
 		printf("Case #%d: %d\n",q,cost);
 	}
 	fclose(stdin);
 //	fclose(stdout);
 	return 0;
 }
