#include <cstdio>
 #include <cstring>
 
 const int M = 512;
 const int p = 100003;
 int hash[M];
 
 int fibo(int n) {
 	if (hash[n] != -1)
 		return hash[n];
 	if (n == 0 || n == 1)
 		return hash[n] = 1;
 	else
 		return hash[n] = (fibo(n-1) + fibo(n-2)) % p;
 }
 
 int main() {
 	int T, n;
 	scanf("%d", &T);
 	for (int i = 0; i < M; ++i)
 		hash[i] = -1;
 	fibo(M - 1);
 	for (int kase = 0; kase < T; ++kase) {
 		scanf("%d", &n);
 		int ret = 0; 
 		for (int i = 0; i < n - 2; ++i)
 			ret += hash[i];
 		printf("Case #%d: %d\n", kase + 1, ret + 1);
 	}
 	return 0;
 }
 
