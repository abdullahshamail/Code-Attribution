#include <bits/stdc++.h>
 
 using namespace std;
 
 #ifdef LOCAL
 #include "delete_this.hpp"
 #define t(...) debug(#__VA_ARGS__, __VA_ARGS__);
 #else
 #define t(...)
 #endif
 vector<int> p;
 
 int bagi(int n) {
     if (n == 1) {
         return 1;
     }
     if (n & 1) {
         return 1 + max(bagi(n / 2), bagi(n / 2 + 1));
     } else {
         return 1 + bagi(n / 2);
     }
 }
 
 void sol() {
     int d;
     scanf("%d", &d);
     int maks = - 1;
     p.clear();
     for (int i = 0; i <= d - 1; i++) {
         int asd;
         scanf("%d", &asd);
         p.push_back(asd);
         maks = max(maks, asd);
     }
     // t(p);
     printf("%d", bagi(maks));
 }
 
 int main() {
     // for (int i = 2; i <= 9; i++) {
     //     t(i, bagi(i));
     // }
     int qwe;
     cin >> qwe;
     for (int i = 0; i <= qwe - 1; i++) {
         printf("Case #%d: ", i + 1);
         sol();
         puts("");
     }
     return 0;
 }