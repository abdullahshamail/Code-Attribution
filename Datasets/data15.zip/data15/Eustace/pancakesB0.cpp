#include <iostream>
 #include <fstream>
 #include <vector>
 using namespace std;
 int main() {
     ifstream input("B-small-attempt0.in");
     ofstream output("B-small-attempt0.out");
     int t;
     input >> t;
 
     for (int a = 0; a < t; a++) {
         int n, ans = 0;
         input >> n;
         vector<int> data;
         for (int i = 0; i < n; i++) {
             int temp;
             input >> temp;
             data.push_back(temp);
         }
         for (; ; ans++) {
             int maxVal = 0, maxI = 0, secondBest = 0;
             for (int i = 0; i < data.size(); i++) {
                 if (data[i] > maxVal) {
                     maxI = i;
                     secondBest = maxVal;
                     maxVal = data[maxI];
                 }
             }
             if (data.size() == 1)
                 secondBest = data[0];
             if (secondBest != 0 && (maxVal / 2 + maxVal % 2 + 1 < secondBest)) {
                 data[maxI] /= 2;
                 data.push_back(maxVal / 2 + maxVal % 2);
             } else {
                 ans += maxVal;
                 break;
             }
         }
         output << "Case #" << (a + 1) << ": " << ans << endl;
     }
     output.close();
     input.close();
     return 0;
 }
