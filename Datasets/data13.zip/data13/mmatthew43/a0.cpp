#include <iostream>
 #include <string>
 #include <sstream>
 #include <algorithm>
 #include <numeric>
 #include <iomanip>
 #include <climits>
 #include <vector>
 #include <functional>
 #include <cstring>
 #include <list>
 #include <fstream>
 #include <map>
 #include <cmath>
 #include <cctype>
 using namespace std;
 
 typedef long long ll;
 
 int main(){
     int t;
     cin >> t;
     int n=1;
     while(t+1>n){
         char ans = 'u';
         string s[5];
         bool f = false;
         for (int i = 0; i < 4; ++i)
             cin >> s[i];
         for (int i = 0; i < 4; ++i){
             if((s[i][0]=='X' && s[i][1]=='X' && s[i][2]=='X' && s[i][3]=='X') || (s[i][0]=='T' && s[i][1]=='X' && s[i][2]=='X' && s[i][3]=='X') || (s[i][0]=='X' && s[i][1]=='T' && s[i][2]=='X' && s[i][3]=='X') || (s[i][0]=='X' && s[i][1]=='X' && s[i][2]=='T' && s[i][3]=='X') || (s[i][0]=='X' && s[i][1]=='X' && s[i][2]=='X' && s[i][3]=='T')){
                 ans = 'X';
                 f = true;
                 }
             if((s[0][i]=='X' && s[1][i]=='X' && s[2][i]=='X' && s[3][i]=='X') ||(s[0][i]=='T' && s[1][i]=='X' && s[2][i]=='X' && s[3][i]=='X') ||(s[0][i]=='X' && s[1][i]=='T' && s[2][i]=='X' && s[3][i]=='X') ||(s[0][i]=='X' && s[1][i]=='X' && s[2][i]=='T' && s[3][i]=='X') ||(s[0][i]=='X' && s[1][i]=='X' && s[2][i]=='X' && s[3][i]=='T')){
                 ans = 'X';
                 f = true;
             }
             if ((s[0][0]=='X' && s[1][1]=='X' && s[2][2]=='X' && s[3][3]=='X') || (s[0][0]=='T' && s[1][1]=='X' && s[2][2]=='X' && s[3][3]=='X') || (s[0][0]=='X' && s[1][1]=='T' && s[2][2]=='X' && s[3][3]=='X') || (s[0][0]=='X' && s[1][1]=='X' && s[2][2]=='T' && s[3][3]=='X') || (s[0][0]=='X' && s[1][1]=='X' && s[2][2]=='X' && s[3][3]=='T')){
                 ans = 'X';
                 f = true;
             }
             if ((s[0][3]=='X' && s[1][2]=='X' && s[2][1]=='X' && s[3][0]=='X') || (s[0][3]=='T' && s[1][2]=='X' && s[2][1]=='X' && s[3][0]=='X') || (s[0][3]=='X' && s[1][2]=='T' && s[2][1]=='X' && s[3][0]=='X') || (s[0][3]=='X' && s[1][2]=='X' && s[2][1]=='T' && s[3][0]=='X') || (s[0][3]=='X' && s[1][2]=='X' && s[2][1]=='X' && s[3][0]=='T')){
                 ans = 'X';
                 f = true;
             }
             if((s[i][0]=='O' && s[i][1]=='O' && s[i][2]=='O' && s[i][3]=='O') || (s[i][0]=='T' && s[i][1]=='O' && s[i][2]=='O' && s[i][3]=='O') || (s[i][0]=='O' && s[i][1]=='T' && s[i][2]=='O' && s[i][3]=='O') || (s[i][0]=='O' && s[i][1]=='O' && s[i][2]=='T' && s[i][3]=='O') || (s[i][0]=='O' && s[i][1]=='O' && s[i][2]=='O' && s[i][3]=='T')){
                 ans = 'O';
                 f = true;
                 }
             if((s[0][i]=='O' && s[1][i]=='O' && s[2][i]=='O' && s[3][i]=='O') || (s[0][i]=='T' && s[1][i]=='O' && s[2][i]=='O' && s[3][i]=='O') || (s[0][i]=='O' && s[1][i]=='T' && s[2][i]=='O' && s[3][i]=='O') || (s[0][i]=='O' && s[1][i]=='O' && s[2][i]=='T' && s[3][i]=='O') || (s[0][i]=='O' && s[1][i]=='O' && s[2][i]=='O' && s[3][i]=='T')){
                 ans = 'O';
                 f = true;
             }
             if ((s[0][0]=='O' && s[1][1]=='O' && s[2][2]=='O' && s[3][3]=='O') || (s[0][0]=='T' && s[1][1]=='O' && s[2][2]=='O' && s[3][3]=='O') || (s[0][0]=='O' && s[1][1]=='T' && s[2][2]=='O' && s[3][3]=='O') || (s[0][0]=='O' && s[1][1]=='O' && s[2][2]=='T' && s[3][3]=='O') || (s[0][0]=='O' && s[1][1]=='O' && s[2][2]=='O' && s[3][3]=='T')){
                 ans = 'O';
                 f = true;
             }
             if ((s[0][3]=='O' && s[1][2]=='O' && s[2][1]=='O' && s[3][0]=='O') || (s[0][3]=='T' && s[1][2]=='O' && s[2][1]=='O' && s[3][0]=='O') || (s[0][3]=='O' && s[1][2]=='T' && s[2][1]=='O' && s[3][0]=='O') || (s[0][3]=='O' && s[1][2]=='O' && s[2][1]=='T' && s[3][0]=='O') || (s[0][3]=='O' && s[1][2]=='O' && s[2][1]=='O' && s[3][0]=='T')){
                 ans = 'O';
                 f = true;
             }
         }
         if(f){
             if(ans == 'O')
                 cout << "Case #" << n << ": O won" << endl;
             else if(ans == 'X')
                 cout << "Case #" << n << ": X won" << endl;
         }else{
             bool f2 = true;
             for (int i = 0; i < 4; ++i)
             {
                 for (int j = 0; j < 4; ++j)
                 {
                     if(s[i][j]=='.')
                         f2 = false;
                 }
             }
             if (f2)
                 cout << "Case #" << n << ": Draw" << endl;
             else
                 cout << "Case #" << n << ": Game has not completed" << endl;
         }
     n++;
     }
     
     
     
 	return 0;
 }
 
