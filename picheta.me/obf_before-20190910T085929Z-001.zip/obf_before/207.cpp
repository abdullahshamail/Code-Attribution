#include <cstdlib>
 #include <cstdio>
 #include <algorithm>
 #include <vector>
 #include <queue>
 #include <cmath>
 #include <stack>
 #include <map>
 #include <set>
 #include <deque>
 #include <cstring>
 #include <functional>
 #include <climits>
 #include <list>
 #include <ctime>
 #include <complex>
 
 #define F1(x,y,z) for(int x=(y);x<(z);x++)
 #define F2(x,y,z) for(int x=(y);x<=(z);x++)
 #define F3(x,y,z) for(int x=(y);x>(z);x--)
 #define F4(x,y,z) for(int x=(y);x>=(z);x--)
 #define mp make_pair
 #define pb push_back
 #define LL long long
 #define co complex<double>
 #define fi first
 #define se second
 
 #define MAX 100005
 #define AMAX 1025*1005
 #define MOD 1000000007
 
 #define f(c,d) ((1<<(c))*(d))
 
 using namespace std;
 
 int t,hd,ad,hk,ak,bb,dd,ans,st;
 
 int f2(int a,int b,int ha,int hb,int aa,int ab){
 	if(a==0&&b==0&&aa>=hb)return 1;
 	if(a){
 		if(max(0,ab-dd)>=ha)return 1+f2(a,b,hd-ab,hb,aa,ab);
 		else return 1+f2(a-1,b,ha-max(0,ab-dd),hb,aa,max(0,ab-dd));
 	}
 	if(ab>=ha)return 1+f2(a,b,hd-ab,hb,aa,ab);
 	if(b)return 1+f2(a,b-1,ha-ab,hb,aa+bb,ab);
 	if(aa>=hb)return 1;
 	return 1+f2(a,b,ha-ab,hb-aa,aa,ab);
 	
 }
 
 int f1(int a){
 	int re=INT_MAX,li=INT_MAX;
 	for(int b=0;b<li;b++){
 		int tt=f2(a,b,hd,hk,ad,ak);
 		if(tt>re)li=min(li,b+5);
 		re=min(re,tt);
 	}
 	return re;
 }
 
 int main(){
 	scanf("%d",&t);
 	F2(a,1,t){
 		ans=INT_MAX;
 		scanf("%d%d%d%d%d%d",&hd,&ad,&hk,&ak,&bb,&dd);
 		if(ad>=hk)ans=1;
 		else if(ak<hd){
 			if(ad*2>=hk||ad+bb>=hk)ans=2;
 			else if(ak+max(0,ak-dd)<hd){
 				if(ak*2<hd)st=0;
 				else st=1;
 				if(dd==0)ans=f1(0);
 				else for(int b=st;ak-(b-1)*dd>0;b++)ans=min(ans,f1(b));
 			}
 		}
 		if(ans==INT_MAX)printf("Case #%d: IMPOSSIBLE\n",a);
 		else printf("Case #%d: %d\n",a,ans);
 	}
 	return 0;
 }
#include <cstdlib>
 #include <cstdio>
 #include <algorithm>
 #include <vector>
 #include <queue>
 #include <cmath>
 #include <stack>
 #include <map>
 #include <set>
 #include <deque>
 #include <cstring>
 #include <functional>
 #include <climits>
 #include <list>
 #include <ctime>
 #include <complex>
 
 #define F1(x,y,z) for(int x=(y);x<(z);x++)
 #define F2(x,y,z) for(int x=(y);x<=(z);x++)
 #define F3(x,y,z) for(int x=(y);x>(z);x--)
 #define F4(x,y,z) for(int x=(y);x>=(z);x--)
 #define mp make_pair
 #define pb push_back
 #define LL long long
 #define co complex<double>
 #define fi first
 #define se second
 
 #define MAX 100005
 #define AMAX 1025*1005
 #define MOD 1000000007
 
 #define f(c,d) ((1<<(c))*(d))
 
 using namespace std;
 
 int t,hd,ad,hk,ak,bb,dd,ans,st;
 
 int f2(int a,int b,int ha,int hb,int aa,int ab){
 	if(a==0&&b==0&&aa>=hb)return 1;
 	if(a){
 		if(max(0,ab-dd)>=ha)return 1+f2(a,b,hd-ab,hb,aa,ab);
 		else return 1+f2(a-1,b,ha-max(0,ab-dd),hb,aa,max(0,ab-dd));
 	}
 	if(ab>=ha)return 1+f2(a,b,hd-ab,hb,aa,ab);
 	if(b)return 1+f2(a,b-1,ha-ab,hb,aa+bb,ab);
 	if(aa>=hb)return 1;
 	return 1+f2(a,b,ha-ab,hb-aa,aa,ab);
 	
 }
 
 int f1(int a){
 	int re=INT_MAX,li=INT_MAX;
 	for(int b=0;b<li;b++){
 		int tt=f2(a,b,hd,hk,ad,ak);
 		if(tt>re)li=min(li,b+5);
 		re=min(re,tt);
 	}
 	return re;
 }
 
 int main(){
 	scanf("%d",&t);
 	F2(a,1,t){
 		ans=INT_MAX;
 		scanf("%d%d%d%d%d%d",&hd,&ad,&hk,&ak,&bb,&dd);
 		if(ad>=hk)ans=1;
 		else if(ak<hd){
 			if(ad*2>=hk||ad+bb>=hk)ans=2;
 			else if(ak+max(0,ak-dd)<hd){
 				if(ak*2<hd)st=0;
 				else st=1;
 				if(dd==0)ans=f1(0);
 				else for(int b=st;ak-(b-1)*dd>0;b++)ans=min(ans,f1(b));
 			}
 		}
 		if(ans==INT_MAX)printf("Case #%d: IMPOSSIBLE\n",a);
 		else printf("Case #%d: %d\n",a,ans);
 	}
 	return 0;
 }
