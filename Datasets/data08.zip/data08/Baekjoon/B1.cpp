#include <cstdio>
 #include <queue>
 #include <memory.h>
 using namespace std;
 int d[20][20];
 char a[20][20];
 int dx[] = {0,0,1,-1};
 int dy[] = {1,-1,0,0};
 int main(){
 	freopen("input.txt","r",stdin);
 	freopen("output.txt","w",stdout);
 	int t;
 	scanf("%d\n",&t);
 	for(int tc=1; tc<=t; tc++){
 		int n,m;
 		scanf("%d %d\n",&n,&m);
 		for(int i=1; i<=n; i++)
 			for(int j=1; j<=m; j++)
 				d[i][j] = 1000000;
 		memset(a,0,sizeof(a));
 		for(int i=1; i<=n; i++)
 			scanf("%s\n",a[i]+1);
 		int sx,sy;
 		int ex,ey;
 		for(int i=1; i<=n; i++)
 			for(int j=1; j<=m; j++)
 				if(a[i][j]=='O')
 					sx=i,sy=j;
 		for(int i=1; i<=n; i++)
 			for(int j=1; j<=m; j++)
 				if(a[i][j]=='X')
 					ex=i,ey=j;
 		d[sx][sy]=0;
 		queue<pair<int,int>>q;
 		q.push(make_pair(sx,sy));
 		while(!q.empty()){
 			int x = q.front().first;
 			int y = q.front().second;
 			q.pop();
 			for(int k=0; k<4; k++){
 				if(x+dx[k]>=1 && x+dx[k]<=n && y+dy[k]>=1 && y+dy[k]<=m){
 					if(a[x+dx[k]][y+dy[k]]!='#' && d[x+dx[k]][y+dy[k]] > d[x][y]+1){
 						q.push(make_pair(x+dx[k],y+dy[k]));
 						d[x+dx[k]][y+dy[k]] = d[x][y]+1;
 					}
 				}
 				int tx,ty;
 				tx=x;
 				ty=y;
 				while(true){
 					if(tx+dx[k]>=1 && tx+dx[k]<=n && ty+dy[k]>=1 && ty+dy[k]<=m){
 						if(a[tx+dx[k]][ty+dy[k]]=='#')
 							break;
 					}
 					else
 						break;
 					tx+=dx[k];
 					ty+=dy[k];
 				}
 				if(d[tx][ty] > d[x][y]+1){
 					q.push(make_pair(tx,ty));
 					d[tx][ty] = d[x][y]+1;
 				}
 			}
 		}
 		int ans=d[ex][ey];
 		printf("Case #%d: ",tc);
 		if(ans==1000000)
 			printf("THE CAKE IS A LIE\n");
 		else
 			printf("%d\n",ans);
 
 	}
 	return 0;
 }