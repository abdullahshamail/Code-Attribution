#include<bits/stdc++.h>
 #define LL long long
 using namespace std;
 
 LL T,L,X;
 int w[500][500] = {0};
 
 int main(){
     scanf("%d", &T);
     w[1][1] = 1; w['i']['i'] = w['j']['j'] = w['k']['k'] = -1;
     w[1]['i'] = 'i'; w[1]['j'] = 'j'; w[1]['k'] = 'k';
     w['i'][1] = 'i'; w['i']['j'] = 'k'; w['i']['k'] = -'j';
     w['j'][1] = 'j'; w['j']['i'] = -'k'; w['j']['k'] = 'i';
     w['k'][1] = 'k'; w['k']['i'] = 'j'; w['k']['j'] = -'i';
 
     for(int qwe=1; qwe<=T;qwe++){
 	scanf("%lld%lld", &L, &X);
 	string s = "",t = "";
 	cin >> t;
 	s = t;
 	LL C = 1, signC = 0;
 	for(LL i=0, j=s.length(); i<j;i++){
 	    C = w[C][s[i]];
 	    if(C < 0) { C=-C; signC=!signC;}
 	}	    
 	if(C != 1){
 	    LL Y = X%4LL;
 
 	    if(Y == 2) { C = 1; signC = 1;}
 	    if(Y == 3) { signC = !signC;}
 	    if(Y == 0) { C = 1; signC = 0;}
 	}
 	C = w['i'][C];
 	if(C < 0) { C=-C; signC=!signC;}
 	C = w[C]['k'];
 	if(C < 0) { C=-C; signC=!signC;}
 
 	//if has prefix i && postfix k, no j	
 	if(C != 'j' || signC) printf("Case #%d: NO\n", qwe);
 	else{
 	    s = "";
 	    for(LL i=0; i<min(4LL, X); i++) s += t;
 	    LL fi = 1, signI = 0, pi = -1, fk = 1, signK = 0, pk = -1;
 	    for(LL i=0, j=s.length(); i<j;i++){
 		fi = w[fi][s[i]];
 		if(fi < 0) {fi=-fi; signI=!signI;}
 		if(fi == 'i' && !signI){ pi=i; break;}
 	    }
 	    if(pi!= -1){
 		for(LL i=s.length()-1, k=X*t.length()-1; i>=0; i--, k--){
 		    fk = w[s[i]][fk];
 		    if(fk < 0) {fk=-fk; signK=!signK;}
 		    if(fk == 'k' && !signK){ pk = k; break;}
 		}
 	    }
 	    if(pi!=-1 && pk!=-1 && pk>pi) printf("Case #%d: YES\n",qwe);
 	    else printf("Case #%d: NO\n", qwe);
 	}
     }
     return 0;
 }
