/* 
  * File:   Snapper.cpp
  * Author: enmand
  * 
  * Created on May 8, 2010, 2:56 PM
  */
 
 #include "Snapper.h"
 #include <fstream>
 
 Snapper::Snapper() {
 	this->next = 0;
 	this->prev = 0;
 	this->on = false;
 	this->powered = false;
 }
 
 Snapper::~Snapper() {
 	this->next = 0;
 	this->prev = 0;
 }
 
