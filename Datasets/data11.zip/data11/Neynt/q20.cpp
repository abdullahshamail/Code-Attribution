#include <stdio.h>
 
 int N;
 char deck[100];
 char dim;
 
 int C;
 char cmb1[36];
 char cmb2[36];
 char cmbpr[36];
 
 int D;
 char del1[28];
 char del2[28];
 
 
 
 int main(){
     int TT;
     freopen("data.in", "r", stdin);
     freopen("data.out", "w", stdout);
     scanf("%d", &TT);
     for(int t=1;t<=TT;t++){
         scanf("%d", &C);
         for(int i=0;i<C;i++){
             scanf(" %c%c%c", &cmb1[i], &cmb2[i], &cmbpr[i]);
         }
         scanf("%d", &D);
         for(int i=0;i<D;i++){
             scanf(" %c%c", &del1[i], &del2[i]);
         }
         scanf("%d", &N);
         dim = 0;
         for(int i=0;i<N;i++){
             scanf(" %c", &deck[dim]);
             dim++;
             bool red=true;
             while(red and dim>1){ // reduce forever!
                 red=false;
                 for(int j=0;j<C;j++){
                     if((cmb1[j] == deck[dim-1] and cmb2[j] == deck[dim-2]) or (cmb1[j] == deck[dim-2] and cmb1[j] == deck[dim-1])){
                         deck[dim-2] = cmbpr[j];
                         dim--;
                         red=true;
                         break;
                     }
                 }
             }
             for(int j=0;j<D;j++){ // find dangers
                 for(int k=0;k<N;k++){
                     if((deck[j] == del1[j] and deck[dim-1] == del2[j]) or (deck[j] == del2[j] and deck[dim-1] == del1[j])){
                        dim = 0;
                        break;
                     }
                 }
             }
         }
         printf("Case #%d: [", t);
         for(int i=0;i<dim;i++){
             if(i>0) printf(", ");
             printf("%c", deck[i]);
         }
         printf("]\n");
     }
     return 0;
 }
