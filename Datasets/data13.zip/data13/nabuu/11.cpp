#include <iostream>
 #include <fstream>
 #include <algorithm>
 #include <cmath>
 //#include <functional>
 using namespace std;
 ifstream filein;
 ofstream fileout;
 int size;
 long mote;
 long* motev;
 int* opt=new int[1000];
 int process();
 int main(int argc,char* argv[])
 {
 	filein.open(argv[1]);
 	fileout.open("result.out");
 	int counter;
 	filein>>counter;
 	for(int i=0;i<counter;i++)
 	{
 		filein>>mote>>size;
 		motev=new long[size];
 		for(int j=0;j<size;j++)
 		{
 			filein>>motev[j];
 		}
 		sort(motev,motev+size);
 		int result=process();
 		fileout<<"Case #"<<i+1<<": "<<result<<endl;
 		//delete motev;
 	}
 	return 0;
 }
 
 int step(long p1,long p2,long & num)
 {
 	int st=0;
 	long c=p1;
 	double a=(double)(p2-1)/(p1-1);
 	st=(int)log(a)/log(2)+1;
 	long cof=(long)pow(2,st);
 	num=cof*p1-cof+1;
 	return st;
 }
 
 int process()
 {
 	int op=0;
 	long tmp;
 	int co=0;
 	//bool flag=false;
 	if(mote==1)
 		return size;
 	for(int i=0;i<size;i++)
 	{
 		if(mote>motev[size-1])
 		{
 			break;
 		}
 		if(mote>motev[i])
 		{
 			mote+=motev[i];
 			continue;
 		}
 		else
 		{
 			opt[co]=op+size-i;
 			co++;
 			int st=step(mote,motev[i],tmp);
 			op+=st;
 			mote=tmp;
 			mote+=motev[i];
 			continue;
 		}
 	}
 	opt[co]=op;
 	sort(opt,opt+co+1);
 	return opt[0];
 }