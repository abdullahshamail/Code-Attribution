#include <iostream>
 #include <fstream>
 using namespace std;
 int main()
 {
 	ofstream fout ("A-small-attempt0.out");
     ifstream fin ("A-small-attempt0.in");
 	int T,N,K;
 	int P[11]={1,2,4,8,16,32,64,128,256,512,1024};
 	fin >> T;
 	for(int i=0;i<T;i++)
 	{
 		fin >> N;
 		fin >> K;
 		if(K==0) fout<<"Case #"<<i+1<<": OFF"<<endl;
 		else
 		{
 			int G=1;
 			if(K % P[N]==P[N]-1)
 				fout<<"Case #"<<i+1<<": ON"<<endl;
 			else
 				fout<<"Case #"<<i+1<<": OFF"<<endl;
 		}
 	}
 	return 0;
 }