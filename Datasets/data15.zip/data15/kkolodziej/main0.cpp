#include <iostream>
 #include <vector>
 #include <algorithm>
 #include <cmath>
 
 using namespace std;
 
 #define B(x) x.begin()
 #define E(x) x.end()
 
 bool not_all_zero(const vector<int>& v)
 {
   for (auto it = B(v); it < E(v); ++it)
   {
     if (*it != 0)
     {
       return true;
     }
   }
   return false;
 }
 
 
 bool check_if_special_round(const vector<int>& v)
 {
   vector<int> nv = v;
   int ST = *max_element(B(nv), E(nv));
   
   int PT = ST;
   int iters = 0;
   auto max_it = max_element(B(nv), E(nv));
   while (PT >= ST && *max_it > 3)
   {
     int move = *max_it / 2;
     *max_it -= move;
     nv.push_back(move);
     
     max_it = max_element(B(nv), E(nv));
     PT = iters + *max_it;
     ++iters;
   }
   return PT < ST;
 }
 
 int main()
 {
   ios::sync_with_stdio(false);
   int T, D;
 
   cin >> T;
   for (int i = 0; i < T; ++i)
   {
     cin >> D;
     vector<int> P(D, 0);
     
     for (int j = 0; j < D; ++j)
     {
       cin >> P[j];
     }
 
     int time = 0;
     
     // rounds
     while (not_all_zero(P))
     {
       if (check_if_special_round(P))
       {
 	auto max_it = max_element(B(P), E(P));
 	int move = *max_it / 2;
 	*max_it -= move;
 	P.push_back(move);
       } else
       {
 	for_each(B(P), E(P), [](int& a) -> void { if (a > 0) --a; });
       }
       ++time;
     }
 
     cout << "Case #" << i+1 << ": " << time << "\n";
   }
   return 0;
 }
