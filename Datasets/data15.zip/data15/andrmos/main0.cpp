#include <iostream>
 #include <queue>
 #include <cmath>
 
 using namespace std;
 
 int main() {
 
     int tc;
     cin >> tc;
 
     for (int i = 1; i <= tc; ++i) {
 
         int d;
         cin >> d;
 
         priority_queue<int> pq;
         for (int j = 0; j < d; ++j) {
 
             int p;
             cin >> p;
 
             pq.push(p);
         }
 
         int max = pq.top();
         int height = ceil(log2(pq.top()) + 1);
 
 
 //          height = std::round(log(pq.top())/log(2)) + 1;
 
         int res = 0;
 
         while(pq.top() > height) {
 
             res++;
             int number = pq.top();
             pq.pop();
 
             if (number % 2 == 0) {
                 pq.push(number/2);
                 pq.push(number/2);
             } else {
                 pq.push(number/2);
                 pq.push((number/2) + 1);
             }
 
         }
 
         res += pq.top();
 
         if (res > max) {
             res = max;
         }
 
         cout << "Case #" << i << ": " << res << endl;
     }
 
     return 0;
 }