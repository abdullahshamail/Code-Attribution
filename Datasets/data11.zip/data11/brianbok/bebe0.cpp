#include <fstream>
 #include <iso646.h>
 using namespace std;
 int main(){
 	long long int t,n,i,j,k,d,c;
 	ifstream in ("pruebabebe.in");
 	ofstream out ("pruebabebe.out");
 	in>>t;
 	for (i = 1;i<=t;i++){
 		in>>n;
 		long long int a = 0,b;
 		long long int g[n+5]; 
 		for (j = 1;j<=n;j++){
 			in>>g[j];
 		}
 		a = 0;
 		c = 0;
 		for (j = 1;j<=n;j++ ){
 			a^=g[j];
 			b = 0;
 			d = 0;
 			for (k = j+1;k<=n;k++){
 				b^= g[k];
 				d += g[k];
 			}
 			if (a == b){c = max(c,d);}
 		}
 		if (c == 0)out<<"Case #"<<i<<": "<<"NO"<<"\n";
 		else{out<<"Case #"<<i<<": "<<c<<"\n"; }
 	}
 }
