#include <iostream>
 #include <cmath>
 
 using namespace std;
 
 int index(char a) {
     switch(a) {
         case '1' : return 1;
         case 'i' : return 2;
         case 'j' : return 3;
         case 'k' : return 4;   
     }   
 }
 int getkmax(string s, int imax) {
     int n = s.length();
             int matrix[4][4] = {{1,2,3,4}, {2,-1,4,-3}, {3,-4,-1,2}, {4,3,-2,-1}};
     int a = index(s.at(n-1));
     int c = 0;
     int kmax = -1;
     if(a == 4) {
         return n-1;
     }
     if(n-2>0) {
         int b = index(s.at(n-2));
         int current = matrix[a-1][b-1];
         a = abs(current);
         int sign = current / a;
         if(current == -4) {
             return n-2;   
         }
         for(int k = n - 3 ; k > imax + 2 ; k--) {
             b = index(s.at(k));
             current = matrix[a-1][b-1] * sign;
             a = abs(current);
             sign = current / a;
             c++;
             if((current == 4 && c%2 == 1) || (current == -4 && c%2 == 0)) {
                 kmax = k;
                 break;   
             }
         }
         return kmax;
     }
     return -1;                  
 }
 int main() {
     int T, n, output , casen = 1;
     cin >> T;
     while(T--) {
         int l,N;
         cin >> l >> N;
         output = 0;
         string s = "", s1;
         cin >> s1;
         for(int m=0;m<N;m++)
             s = s + s1;
         int n = s.length();
         int matrix[4][4] = {{1,2,3,4}, {2,-1,4,-3}, {3,-4,-1,2}, {4,3,-2,-1}};
         int a,b;
         int A = index(s.at(0)), B, CURRENT, SIGN;
         for(int x = 1 ; x < n ; x++) {
             B = index(s.at(x));
             CURRENT = matrix[A-1][B-1];
             A = abs(CURRENT);
             SIGN = CURRENT / A;
         }
         if(CURRENT == -1) {
             if(s.length() > 0) {
                 a = index(s.at(0));
                 if(a == 2) {
                     int imax = 1;
                     int kmax = getkmax(s, imax);
                     if(kmax > 0) {
                         output = 1;   
                     }
                     else {
                         output = 0;   
                     }
                 }
                 else {
                     if(s.length() > 1) {
                         b = index(s.at(1));
                         
                         int current = matrix[a-1][b-1];
                         int sign = 1;
                         a = abs(current);
                         sign = current / a;
                         int imax = -1, jmax = -1, kmax = -1;
                         
                         if(current == 2) {
                             imax = 2;  
                             kmax = getkmax(s,imax);
                             if(kmax > 0) {
                                 output = 1;
                             }
                             else {
                                 output = 0;   
                             } 
                         }
                         else {
                             for(int i = 2 ; i < n - 2; i++) {
                                 b = index(s.at(i));
                                 current = matrix[a-1][b-1] * sign;
                                 a = abs(current);
                                 sign = current / a;
                                 if(current == 2) {
                                     imax = i;
                                     break;   
                                 }
                             }
                             
                             if(imax > 0) {
                                 kmax = getkmax(s,imax);
                                 if(kmax > 0) {
                                     output = 1;
                                 }
                                 else {
                                     output = 0;   
                                 }
                             }
 							else {
 								output = 0;   
 							} 
                         }
                     }
                     else {
                         output = 0;   
                     }
                 }
             }
             else {
                 output = 0;   
             }
         }
         else {
             output = 0;   
         }
         cout << "Case #" << casen++ << ": " << (output==0?"NO":"YES") << endl;
     }
     return 0;   
 }
