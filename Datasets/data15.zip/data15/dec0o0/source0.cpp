#include <fstream>
 #include <iostream>
 #include <cmath>
 #include <conio.h>
 #include <vector>
 #include <algorithm>
 using namespace std;
 bool comp(int i, int j){
 	return i>j;
 }
 
 int getP(vector<int> v){
 	for (int i=0; i < v.size(); i++)
 		if (v[i]%2==0 && v[i])
 			return i;
 	return -1;
 }
 
 int getTime(vector<int> v){
 	sort(v.begin(), v.end(), comp);
 	if (v[0] < 3) //max<3
 		return v[0];
 	else{
 		int p = getP(v);
 		int a,b;
 		a = b = v[0];
 		if (p!=-1){
 			vector<int> div(v);
 			div[p] = div[p] / 2;
 			div.push_back(div[p]);
 			a = 1 + getTime(div);
 		}
 		for(int i=0; i<v.size(); v[i++]--);
 		b = 1 + getTime(v);
 		return a < b ? a : b;
 	}
 }
 
 int main(){
 	ifstream f("pancakes.in");
 	ofstream g("pancakes.out");
 	int sets, diners;
 	f >> sets;
 	for (int set = 1; set <= sets; set++){
 		f >> diners;
 		vector<int> v(diners);
 		for (int d = 0; d < diners; d++){
 			f >> v[d];
 		}
 		int ans = getTime(v);
 		g << "Case #" << set << ": " << ans << endl;
 	}
 	f.close();
 	g.close();
 	return 0;
 }