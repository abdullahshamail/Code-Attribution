#include <iostream>
 #include <cmath>
 #include <string>
 #include <cstring>
 #include <vector>
 #include <fstream>
 #include <algorithm>
 #include <cstdio>
 #include <cstdlib>
 #define nextline { while (getchar() != '\n') ; }
 #define sqr(a) ((a)*(a))
 using namespace std ;
 
 #define mp make_pair
 #define pb push_back            
 typedef long long ll ;
 typedef long double dbl ;
 
 const int INF = (1 << 30) - 1 ;
 const dbl EPS = 1e-9 ;
 
 int D , I , m , n ;
 int a[105] ;
 void Load ()
 {
 	scanf ("%d%d%d%d", &D, &I, &m, &n) ;
 	for (int i = 1; i <= n; i++) scanf ("%d", &a[i]) ;
 }
 
 int dp[205][605] ;
 bool was[205][605] ;
 
 int Rec (int x , int lt)
 {
 	if (dp[x][lt] != -1) return dp[x][lt] ;
 	if (was[x][lt]) return INF ;
 	if (x > n) return 0 ;
 	was[x][lt] = 1 ;
 	int res = Rec (x + 1 , lt) + D ;
 	for (int i = max (0 , lt - m); i <= lt + m; i++)
 		res = min (res , Rec (x + 1 , i) + abs(a[x] - i)) ;
 	if (abs(a[x] - lt) <= m) res = min (res , Rec (x + 1 , a[x])) ;
 	else 
 	{
 		if (m == 0) res = min (res , Rec (x , a[x]) + abs(a[x] - lt) * I) ;
 		else res = min (res , Rec (x  , lt + m * ((a[x] - lt) / m)) + I * (abs(a[x] - lt) / m)) ;
 	}	
 	//cerr << x << " " << lt << " " << res << endl ;
 	return dp[x][lt] = res ;
 }
 
 void Solve ()
 {
 	memset (dp, -1, sizeof(dp)) ;
 	memset (was, false, sizeof(was)) ;
 	int res = INF ;
 	for (int i = 0; i <= 255; i++)
 		res = min(res , Rec (1 , i)) ;
 	printf ("%d\n", res) ;
 }
 
 int main()
 {
 	int t ;
 	scanf ("%d", &t) ;
 	for (int i = 1; i <= t; i++)
 	{
 		Load () ;
 		printf ("Case #%d: ", i) ;
 		Solve () ;
 	}	
 	return 0 ;
 }
 
