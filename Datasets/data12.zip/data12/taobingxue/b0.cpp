#include <iostream>
 #include <cstdio>
 #include <cstdlib>
 #include <algorithm>
 #include <cmath>
 using namespace std;
 
 class node
 {
 public:
 	int r,b;
 };
 
 int T,n,w,l,ha,li,le,hh,px[1005],py[1005],ansx[1005],ansy[1005];
 node yu[1005];
 bool cmp(node aa,node bb) {
     return (aa.r>bb.r);
 }
 int main() {
     freopen("a.in","r",stdin);
     freopen("a.out","w",stdout);
     scanf("%d",&T);
     for (int tsum=1;tsum<=T;tsum++) {
         printf("Case #%d:",tsum);
         scanf("%d%d%d",&n,&w,&l);
         for (int i=1;i<=n;i++) {
             scanf("%d",&yu[i].r);
             px[i]=-1;
             py[i]=-1;
             yu[i].b=i;}
         sort(yu+1,yu+n+1,cmp);
 //        ha=-yu[1].r;li=l;le=0;
         ha=2*yu[1].r;li=yu[1].r;le=2*yu[1].r;
         px[1]=yu[1].r;py[1]=0;
         for (int i=2;i<=n;i++) {
             if (px[i]>=0) continue;
             if (l-li<yu[i].r) {
                 li=yu[i].r;
                 ha=ha+yu[i].r+yu[i].r;
                 px[i]=ha-yu[i].r;   py[i]=0;
                 le=yu[i].r*2;
             } else {
                 px[i]=ha-le+yu[i].r;
                 py[i]=li+yu[i].r;
                 hh=px[i]+yu[i].r;
                 for (int j=i+1;j<=n;j++)
                     if (px[j]<0 && 2*yu[j].r+hh<=ha) {
                         px[j]=hh+yu[j].r;
                         py[j]=li+yu[j].r;
                         hh+=2*yu[j].r;
                         if (hh+yu[n].r>ha) break;
                     } 
                 li+=2*yu[i].r;
             }
         }
         for (int i=1;i<=n;i++) {ansx[yu[i].b]=px[i];ansy[yu[i].b]=py[i];}
         for (int i=1;i<=n;i++) printf(" %d.0 %d.0",ansx[i],ansy[i]);
         printf("\n");
     }
     return 0;
 }
 
