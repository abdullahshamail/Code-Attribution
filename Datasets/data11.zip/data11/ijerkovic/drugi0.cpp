#include<iostream>
 #include<map>
 #include<vector>
 #include<set>
 #include<string>
 #include<queue>
 #include<cstring>
 #include<algorithm>
 using namespace std;
 
 int rijesi( int n ) {
 
      int a[ 16 ];
      for( int i = 0; i < n; i++ )
      cin >> a[ i ];
      
      int maxi = 0;
      
      for( int i = 1; i < ( 1 << n ); i++ ) {
      
           int x = 0, y = 0;
           int k = 0;
           
           for( int j = 0; j < n; j++ )
           if( i & ( 1 << j ) ) x ^= a[ j ];
           else {
                y ^= a[ j ];
                k += a[ j ];
           }
           
           if( x == y )
           maxi >?= k;
           
      }
      
      return maxi;
 }
 
 int main() {
 
     int t;
     cin >> t;
     
     for( int i = 0; i < t; i++ ) {
     
          int n;
          cin >> n;
          int r = rijesi( n );
          
          cout << "Case #" << i + 1 << ": ";
          if( r ) cout << r;
          else cout << "NO";
          cout << endl;
          
     }
 
     return 0;
 }
