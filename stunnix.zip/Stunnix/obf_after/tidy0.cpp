
#include <bits/stdc++.h>
 using namespace std;
 
 
#define ReplacementFor_rep(ReplacementFor_i, ReplacementFor_from, ReplacementFor_to) for (int ReplacementFor_i = ReplacementFor_from; ReplacementFor_i < int(ReplacementFor_to); ++ReplacementFor_i)
 
#define ReplacementFor_trav(a, x) for (auto& a : x)
 
#define all(x) x.begin(), x.end()
 
#define ReplacementFor_sz(x) (int)(x).size()
 typedef long long ReplacementFor_ll;
 typedef pair<int, int> ReplacementFor_pii;
 typedef vector<int> ReplacementFor_vi;
 
 void ReplacementFor_solve() {
 	string ReplacementFor_num;
 	cin >> ReplacementFor_num;
 	char ReplacementFor_lo = ((char)(0x920+6227-0x2143));
 	ReplacementFor_rep(ReplacementFor_i,0,ReplacementFor_sz(ReplacementFor_num)) {
 		if (ReplacementFor_lo > ReplacementFor_num[ReplacementFor_i]) {
 			for (int ReplacementFor_j = ReplacementFor_i-1; ReplacementFor_j >= 0; --ReplacementFor_j) {
 				if (ReplacementFor_j == 0 || ReplacementFor_num[ReplacementFor_j] > ReplacementFor_num[ReplacementFor_j-1]) {
 					ReplacementFor_num[ReplacementFor_j]--;
 					ReplacementFor_rep(k,ReplacementFor_j+1,ReplacementFor_sz(ReplacementFor_num)) ReplacementFor_num[k] = ((char)(0x97b+2526-0x1320));
 					break;
 				}
 			}
 			break;
 		}
 		else {
 			ReplacementFor_lo = ReplacementFor_num[ReplacementFor_i];
 		}
 	}
 	while (ReplacementFor_num[0] == ((char)(0xc44+801-0xf35))) ReplacementFor_num.erase(ReplacementFor_num.begin());
 	cout << ReplacementFor_num << endl;
 }
 
 int main() {
 	cin.sync_with_stdio(false);
 	cin.exceptions(cin.failbit | cin.eofbit | cin.badbit);
 	cin.tie(0);
 	int T;
 	cin >> T;
 	ReplacementFor_rep(ReplacementFor_i,0,T) {
 		cout << "Case #" << ReplacementFor_i+1 << ": ";
 		ReplacementFor_solve();
 	}
 }
#include <bits/stdc++.h>
 using namespace std;
 
 
#define ReplacementFor_rep(ReplacementFor_i, ReplacementFor_from, ReplacementFor_to) for (int ReplacementFor_i = ReplacementFor_from; ReplacementFor_i < int(ReplacementFor_to); ++ReplacementFor_i)
 
#define ReplacementFor_trav(a, x) for (auto& a : x)
 
#define all(x) x.begin(), x.end()
 
#define ReplacementFor_sz(x) (int)(x).size()
 typedef long long ReplacementFor_ll;
 typedef pair<int, int> ReplacementFor_pii;
 typedef vector<int> ReplacementFor_vi;
 
 void ReplacementFor_solve() {
 	string ReplacementFor_num;
 	cin >> ReplacementFor_num;
 	char ReplacementFor_lo = ((char)(0x8c9+7340-0x2545));
 	ReplacementFor_rep(ReplacementFor_i,0,ReplacementFor_sz(ReplacementFor_num)) {
 		if (ReplacementFor_lo > ReplacementFor_num[ReplacementFor_i]) {
 			for (int ReplacementFor_j = ReplacementFor_i-1; ReplacementFor_j >= 0; --ReplacementFor_j) {
 				if (ReplacementFor_j == 0 || ReplacementFor_num[ReplacementFor_j] > ReplacementFor_num[ReplacementFor_j-1]) {
 					ReplacementFor_num[ReplacementFor_j]--;
 					ReplacementFor_rep(k,ReplacementFor_j+1,ReplacementFor_sz(ReplacementFor_num)) ReplacementFor_num[k] = ((char)(0xa32+5369-0x1ef2));
 					break;
 				}
 			}
 			break;
 		}
 		else {
 			ReplacementFor_lo = ReplacementFor_num[ReplacementFor_i];
 		}
 	}
 	while (ReplacementFor_num[0] == ((char)(0x1410+4242-0x2472))) ReplacementFor_num.erase(ReplacementFor_num.begin());
 	cout << ReplacementFor_num << endl;
 }
 
 int main() {
 	cin.sync_with_stdio(false);
 	cin.exceptions(cin.failbit | cin.eofbit | cin.badbit);
 	cin.tie(0);
 	int T;
 	cin >> T;
 	ReplacementFor_rep(ReplacementFor_i,0,T) {
 		cout << "Case #" << ReplacementFor_i+1 << ": ";
 		ReplacementFor_solve();
 	}
 }
#include <bits/stdc++.h>
 using namespace std;
 
 
#define ReplacementFor_rep(ReplacementFor_i, ReplacementFor_from, ReplacementFor_to) for (int ReplacementFor_i = ReplacementFor_from; ReplacementFor_i < int(ReplacementFor_to); ++ReplacementFor_i)
 
#define ReplacementFor_trav(a, x) for (auto& a : x)
 
#define all(x) x.begin(), x.end()
 
#define ReplacementFor_sz(x) (int)(x).size()
 typedef long long ReplacementFor_ll;
 typedef pair<int, int> ReplacementFor_pii;
 typedef vector<int> ReplacementFor_vi;
 
 void ReplacementFor_solve() {
 	string ReplacementFor_num;
 	cin >> ReplacementFor_num;
 	char ReplacementFor_lo = ((char)(0x1e43+1657-0x248c));
 	ReplacementFor_rep(ReplacementFor_i,0,ReplacementFor_sz(ReplacementFor_num)) {
 		if (ReplacementFor_lo > ReplacementFor_num[ReplacementFor_i]) {
 			for (int ReplacementFor_j = ReplacementFor_i-1; ReplacementFor_j >= 0; --ReplacementFor_j) {
 				if (ReplacementFor_j == 0 || ReplacementFor_num[ReplacementFor_j] > ReplacementFor_num[ReplacementFor_j-1]) {
 					ReplacementFor_num[ReplacementFor_j]--;
 					ReplacementFor_rep(k,ReplacementFor_j+1,ReplacementFor_sz(ReplacementFor_num)) ReplacementFor_num[k] = ((char)(0x1bc8+1875-0x22e2));
 					break;
 				}
 			}
 			break;
 		}
 		else {
 			ReplacementFor_lo = ReplacementFor_num[ReplacementFor_i];
 		}
 	}
 	while (ReplacementFor_num[0] == ((char)(0x144b+536-0x1633))) ReplacementFor_num.erase(ReplacementFor_num.begin());
 	cout << ReplacementFor_num << endl;
 }
 
 int main() {
 	cin.sync_with_stdio(false);
 	cin.exceptions(cin.failbit | cin.eofbit | cin.badbit);
 	cin.tie(0);
 	int T;
 	cin >> T;
 	ReplacementFor_rep(ReplacementFor_i,0,T) {
 		cout << "Case #" << ReplacementFor_i+1 << ": ";
 		ReplacementFor_solve();
 	}
 }

