#include <cstdio>
 #include <string.h>
 #include <cmath>
 #include <vector>
 using namespace std;
 
 int maxn = 1000;
 
 vector <int> fs;
 
 bool parli(char str[], int lf, int rt)
 {
     while ( lf < rt && str[lf] == str[rt] )
         lf ++, rt --;
     if (lf < rt)
         return false;
     return true;
 }
 
 int bisearch_lf(int key)
 {
     int lf = 0, rt = fs.size() - 1;
     while (lf <= rt)
     {
         int mid = (lf + rt) >> 1;
         if (fs[mid] >= key )
             rt = mid - 1;
         else lf = mid + 1;
     }
     if (rt >= 0 && fs[rt] >= key)
         return rt;
     if (lf < fs.size() && fs[lf] >= key)
         return lf;
     return -1;
 }
 
 int bisearch_rt(int key)
 {
     int lf = 0, rt = fs.size() - 1;
     while (lf <= rt)
     {
         int mid = (lf + rt) >> 1;
         if (fs[mid] > key )
             rt = mid - 1;
         else lf = mid + 1;
     }
 
     if (lf < fs.size() && fs[lf] <= key)
         return lf;
     if (rt >= 0 && fs[rt] <= key)
         return rt;
     return -1;
 }
 
 int main()
 {
     fs.clear();
     char str[20];
     for (int i = 1;  ;i ++)
     {
         if ( i*i > maxn )
             break;
         sprintf(str, "%d", i);
         if (parli(str, 0, strlen(str) - 1))
         {
             sprintf(str, "%d", i*i);
             if (parli(str, 0, strlen(str) - 1))
             {
                 fs.push_back(i*i);
                 //printf("%d ", i*i);
             }
         }
     }
     freopen("C-small-attempt4.in", "r", stdin);
     freopen("C-small-attempt0.out", "w", stdout);
 
     int t, cas = 1;
     scanf("%d", &t);
     while (t --)
     {
         int a, b;
         scanf("%d %d", &a, &b);
         int lf = bisearch_lf(a);
         int rt = bisearch_rt(b);
         int ans = 0;
         //printf("%d, %d\n", lf, rt);
         if (lf != -1 && rt != -1 && rt >= lf)
             ans = rt - lf + 1;
         printf("Case #%d: %d\n", cas++, ans);
     }
     return 0;
 }
