#include<stdio.h>
 #include<string.h>
 int main()
 {
 	char filename[32];
 	char infile[32], outfile[32];
 	scanf("%s", filename);
 	strcpy(infile, filename); strcpy(outfile, filename);
 	strcat(infile, ".in"); strcat(outfile, ".out");
 	FILE *fp=fopen(infile, "r"), *ofp=fopen(outfile, "w");
 	return 0;
 }
