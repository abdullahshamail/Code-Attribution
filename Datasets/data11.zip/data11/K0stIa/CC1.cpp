#include <algorithm>
 #include <cstdio>
 #include <cstdlib>
 #include <cctype>
 #include <cmath>
 #include <iostream>
 #include <queue>
 #include <list>
 #include <map>
 #include <numeric>
 #include <set>
 #include <sstream>
 #include <string>
 #include <vector>
 using namespace std;
 #define VAR(a,b) __typeof(b) a=(b)
 #define FOR(i,a,b) for (int _n(b), i(a); i < _n; i++)
 #define FORD(i,a,b) for(int i=(a),_b=(b);i>=_b;--i)
 #define FOREACH(it,c) for(VAR(it,(c).begin());it!=(c).end();++it)
 #define REP(i,n) FOR(i,0,n)
 #define ALL(c) (c).begin(), (c).end()
 #define SORT(c) sort(ALL(c))
 #define REVERSE(c) reverse(ALL(c))
 #define UNIQUE(c) SORT(c),(c).resize(unique(ALL(c))-(c).begin())
 #define INF 1000000000
 #define X first
 #define Y second
 #define pb push_back
 #define SZ(c) (c).size()
 typedef pair<int, int> PII;
 typedef vector<long long> VI;
 typedef vector<PII> VPII;
 typedef vector<VI> VVI;
 
 long long l, h;
 
 long long gcd(long long x, long long y)
 {
   if (!x || !y)
     return max(x, y);
 
   return gcd (y, x%y);
 }
 
 long long gcd(VI a)
 {
   long long res = a[0];
 
   REP(i, a.size())
     res = gcd (res, a[i]);
 
   return res;
 }
 
 long long solve(VI for_lcm, VI for_gcd)
 {
   long long lcm = 1;
 
   if (for_lcm.size())
     {
       lcm = for_lcm[0];
 
       FOR(i, 1, for_lcm.size())
 	{
 	  long long v = for_lcm[i] / gcd(lcm, for_lcm[i]);
 
 	  if (h / v < lcm)
 	    return -1;
 
 	  lcm *= v;
 	}
     }
 
   if (!for_gcd.size())
     {
       long long res = l/lcm*lcm;
       if (res < l)
 	res += lcm;
 
       if (res <= h)
 	return res;
       else
 	return -1;
     }
 
   long long G = gcd(for_gcd);
 
   if (G % lcm)
     return -1;
 
   long long g = G/lcm;
 
   VI div;
   VI c;
 
   FOR (i, 2, sqrt(g)+2)
     {
       int cc = 0;
       while (g % i == 0)
 	{
 	  cc++;
 	  g/=i;
 	}
 
       if (cc)
 	{
 	  div.pb(i);
 	  c.pb(cc);
 	}
     }
   if (g > 1)
     {
       div.pb(g);
       c.pb (1);
     }
 
   long long p = 1;
   REP (i, div.size())
     p*=(c[i]+1);
 
   long long res = -1;
 
   REP(pp, p)
     {
       long long r = lcm;
 
       int P = pp;
       REP (i, div.size())
 	{
 	  REP (j, P%(c[i]+1))
 	    r*=div[i];
 	  P/=c[i];
 	}
 
       if (r>=l && r<=h)
 	{
 	  if (res == -1 || res > r)
 	    res = r;
 	}
     }
 
     return res;
 }
 
 int main()
 {
   freopen("C-large.in", "r", stdin);
   freopen("output.txt", "w+", stdout);
 
   int t;
   cin >> t;
   REP(tt, t)
     {
       cout << "Case #" << tt+1 << ": ";
 
       int n;
 
       cin >> n >> l >> h;
 
       VI a(n);
 
       REP (i, n)
 	cin >> a[i];
 
       SORT(a);
 
       VI for_lcm, for_gcd;
       for_gcd = a;
       reverse(ALL(for_gcd));
 
       REP (i, n+1)
 	{
 	  long long res = solve(for_lcm, for_gcd);
 	  if (res != -1)
 	    {
 	    cout << res << endl;
 	    goto next;
 	    }
 
 	  if (for_gcd.size())
 	    {
 	    for_lcm.pb(for_gcd.back());
 	    for_gcd.pop_back();
 	    }
 	}
       cout << "NO" << endl;
       next:;
     }
 
   return 0;
 }
