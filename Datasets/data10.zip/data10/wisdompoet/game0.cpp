
 #include <iostream>
 #include <map>
 
 using namespace std;
 
 map<pair<int,int>,bool> m, n;
 
 bool rec(int a, int b);
 
 bool rec2(int i, int a, int b) {
   if (i*a < b) {
     int c = b - i*a, d = a;
     if (d < c) {
       int tmp = c;
       c = d;
       d = tmp;
     }
     if (d%c == 0) return false;
     
     pair<int,int> q(a, b - i*a);
     if (n.find(q) != n.end()) return n[q];
     
     bool x = true;
     for (int j = 1; x && j*c < d; j++)
       x = rec(c, d - j*c);
     
     if (x == false) x = rec2(i+1, a, b);
     n[q] = x;
     return x;
   }
   return false;
 }
 
 bool rec(int a, int b) {
   if (b < a) {
     int tmp = a;
     a = b;
     b = tmp;
   }
   if (b%a == 0) return true;
   pair<int,int> p(a, b);
   if (m.find(p) != m.end()) return m[p];
 
   //cout << a << "," << b << "\n";
 
   bool y = rec2(1, a, b);
 
   m[p] = y;
   return y;
 }
 
 int main() {
   int T, A1, A2, B1, B2;
   cin >> T;
   for (int z = 1; z <= T; z++) {
     int sum = 0;
     cin >> A1 >> A2 >> B1 >> B2;
     //cout << A1 << "-" << A2 << "," << B1 << "-" << B2 << "\n";
     for (int i = A1; i <= A2; i++)
       for (int j = B1; j <= B2; j++) {
 	//cout << i << "," << j << "\n";
 	sum += rec(i, j);
       }
     cout << "Case #" << z << ": " << sum << "\n";
   }
 }
