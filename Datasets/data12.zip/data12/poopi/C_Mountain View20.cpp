									/* in the name of Allah */
 #include <iostream>
 #include <algorithm>
 #include <memory.h>
 #include <fstream>
 #include <string>
 #include <vector>
 #include <queue>
 #include <cstdio>
 #include <cmath>
 #include <map>
 
 using namespace std;
 
 ifstream fin("C_Mountain View.in");
 ofstream fout("C_Mountain View.out");
 
 #define cin fin
 #define cout fout
 #define P pair<double, double>
 #define int64 long long
 
 int n, arr[2010];
 int dif[2010];
 vector <int> v;
 int h[2010];
 
 int main(){
 	int T, test = 0;
 	for(cin >> T; T--; ){
 		bool can = true;
 		cin >> n;
 		v.clear();
 		memset(dif, 0, sizeof dif);
 		for(int i = 0; i < n - 1; i++){
 			cin >> arr[i];
 			arr[i]--;
 			if(!v.empty() && i == v.back())
 				v.pop_back();
 			if(!v.empty() && arr[i] > v.back())
 				can = false;
 			if(v.empty() || arr[i] < v.back()){
 				if(!v.empty())
 					dif[i]--;
 				dif[arr[i]]++;
 				v.push_back(arr[i]);
 			}
 		}
 		memset(h, 0, sizeof h);
 		memset(dif, 0, sizeof dif);
 		int cur = 0;
 		for(int i = 0; i < n - 1; i++){
 			cur += dif[i];
 			h[i] = cur;
 			cur--;
 			dif[arr[i]]++;
 			
 		}
 		cur += dif[n - 1];
 		h[n - 1] = cur;
 		cout << "Case #" << ++test << ":";
 		if(!can)
 			cout << " Impossible" << endl;
 		else{
 			for(int i = 0; i < n; i++){
 				cout << ' ' << h[i] + 1000000000;
 			}
 			cout << endl;
 		}
 	}
 	return 0;
 }
