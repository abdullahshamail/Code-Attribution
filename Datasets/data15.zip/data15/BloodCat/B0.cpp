#include <cstdio>
 #include <queue>
 #define M(a,b) ((a) > (b) ? (a) : (b))
 
 int main(int argc, char **argv)
 {
     int T, C = 1, D, t, t2, m;
     std::priority_queue<int> P;
     freopen(argv[1], "r", stdin);
     freopen("out.txt", "w", stdout);
     scanf("%d", &T);
     while (T--)
     {
         P = std::priority_queue<int>();
         scanf("%d", &D);
         do
         {
             scanf("%d", &t);
             P.push(t);
         } while (--D);
         while (!P.empty())
         {
             t = P.top();
             P.pop();
             if (P.empty())
             {
                 t2 = -1;
                 P.push(t2);
             }
             else
             {
                 t2 = P.top();
             }
             if (t <= M(t / 2 + (t % 2), t2) + 1)
             {
                 m = t + D;
                 break;
             }
             else
             {
                 D++;
                 P.push(t / 2);
                 P.push(t / 2 + (t % 2));
             }
         }
         printf("Case #%d: %d\n", C++, m);
     }
     return 0;
 }