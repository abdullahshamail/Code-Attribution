#include <bits/stdc++.h>
 
 using namespace std;
 
 #ifdef LOCAL
 #include "delete_this.hpp"
 #define t(...) debug(#__VA_ARGS__, __VA_ARGS__);
 #else
 #define t(...)
 #endif
 
 const char ri[] = "RICHARD";
 const char ga[] = "GABRIEL";
 
 void sol() {
     int x, r, c;
     scanf("%d", &x);
     scanf("%d", &r);
     scanf("%d", &c);
     // t(x, r, c);
     if (x == 1) {
         if (r == 1 && c == 1) {
             puts(ri);
             return;
         }
         puts(ga);
         return;
     }
     if (x == 2) {
         if (r >= 2 && c >= 2) {
             puts(ga);
             return;
         }
         puts(ri);
         return;
     }
     if (x == 3) {
         if ((r == 2 && c == 3) || (r == 3 && c == 2)) {
             puts(ga);
             return;
         }
         if ( (r >= 3 && c >= 3) ) {
             puts(ga);
             return;
         }
         puts(ri);
         return;
     }
     if (x == 4) {
         if ( (r <= 2 && c <= 2) || (c <= 2 && r <= 2) ) { //kotak / ga muat
             puts(ri);
             return;
         }
         if (c == 4) {
             if (r == 1 || r == 2) { //r=1 lurus, r=2 t
                 puts(ri);
                 return;
             }
         }
         if (r == 4) {
             if (c == 1 || c == 2) { //c=1 lurus , c=2 t
                 puts(ri);
                 return;
             }
         }
         if (c == 3) {
             if (r == 1 || r == 2) { // r = 3 t, r = 2 t, r=1 penuh
                 puts(ri);
                 return;
             }
         }
         if (r == 3) {
             if (c == 1 || c == 2) {
                 puts(ri);
                 return;
             }
         }
         puts(ga);
         return;
     }
 }
 
 
 int main() {
     int qwe;
     cin >> qwe;
     for (int i = 0; i <= qwe - 1; i++) {
         printf("Case #%d: ", i + 1);
         sol();
     }
     return 0;
 }