#include<cstdio>
 
 bool ispalindrom (int k) {
 	int l = k, p=0;
 	while(l>0) {
 		p = p*10 + l%10;
 		l/=10;
 	}
 	return p == k;
 }
 int main() {
 	int cs, a, b;
 	scanf("%d", &cs);
 	int fair[100], fi=0;
 	for(int i=1; i*i <1000;i++)
 		if(ispalindrom(i*i) && ispalindrom(i))
 			fair[fi++] = i*i;
 	for(int c=1; c<=cs; c++) {
 		printf("Case #%d: ", c);
 		scanf("%d %d", &a, &b);
 		int count = 0, c=0;
 		while(fair[c] < a) c++;
 		while(fair[c] <= b) {
 			count++;
 			c++;
 		}
 		printf("%d\n", count);
 	}
 	return 0;
 }
