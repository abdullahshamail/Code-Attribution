#include "stdafx.h"
 #include <iostream> 
 #include <vector>
 #include <string>
 
 using namespace std;
 
 int main()
 {
 	vector<int> xVec(10,0);
 	vector<int> oVec(10,0);
 
 	int N;
 	cin >> N;
 
 	for (int i = 0; i < N; i++)
 	{
 		for (int v = 0; v < xVec.size(); v++)
 		{
 			xVec[v] = 0; oVec[v] = 0;
 		}
 		string str;
 		bool hasDot = false;
 		for (int j = 0; j < 4; j++)
 		{
 			cin >> str;
 			for (int k = 0; k < 4; k++)
 			{
 				if (str[k] == 'X') 
 				{
 					xVec[j] += 1;
 					xVec[k + 4] += 1;
 					if (k == j) xVec[8] += 1;
 					if (k + j == 3) xVec[9] += 1;
 				}
 				if (str[k] == 'O')
 				{
 					oVec[j] += 1;
 					oVec[k + 4] += 1;
 					if (k == j) oVec[8] += 1;
 					if (k + j == 3) oVec[9] += 1;
 				}
 				if (str[k] == 'T')
 				{
 					xVec[j] += 1;     oVec[j] += 1;
 					xVec[k + 4] += 1; oVec[k + 4] += 1;
 					if (k == j) xVec[8] += 1;
 					if (k == j) oVec[8] += 1;
 					if (k + j == 3) xVec[9] += 1;
 					if (k + j == 3) oVec[9] += 1;
 				}
 				if (!hasDot && str[k] == '.')
 				{
 					hasDot = true;
 				}
 			}
 		}
 		bool isOneWin = false;
 		for (int v = 0; v < xVec.size(); v++)
 		{
 			if (xVec[v] == 4)
 			{
 				isOneWin = true;
 				cout << "Case #" << i+1 << ": X won" << endl;
 				break;
 			}else if (oVec[v] == 4)
 			{
 				isOneWin = true;
 				cout << "Case #" << i+1 << ": O won" << endl;
 				break;
 			}
 		}
 		if (!isOneWin)
 		{
 			if (hasDot)
 				cout << "Case #" << i+1 << ": Game has not completed" << endl;
 			else
 				cout << "Case #" << i+1 << ": Draw" << endl;
 		}
 
 	}
 	return 0;
 }
 
