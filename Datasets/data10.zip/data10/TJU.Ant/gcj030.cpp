#include <iostream>
 #include <cstdio>
 using namespace std;
 int t,r,k,n;
 int g[1001];
 int main()
 {
 	int i,j,tp,sum,cnt,left;
 	long long int ans;
 	freopen("C-small-attempt0.in","r",stdin);
 	freopen("C-small.out","w",stdout);
 	int case_t;
 	while(scanf("%d",&t)!=EOF)
 	{
 		case_t = 1;
 		while(t--)
 		{
 			scanf("%d%d%d",&r,&k,&n);
 			for(i=0;i<n;i++)
 			{
 				scanf("%d",&g[i]);
 			}
 			tp = 0;
 			ans = 0;
 			sum = 0;
 			for(i=0;i<r;i++)
 			{
 				cnt = 0;
 				while(sum<=k)
 				{
 					cnt++;
 					sum += g[tp];
 					if(sum > k)
 					{
 						sum -= g[tp];
 						ans = (long long int)ans + sum;
 						sum = 0;
 						break;
 					}
 					if(cnt == n)
 					{
 						ans = (long long int)ans + sum;
 						sum = 0;
 						break;
 					}
 					tp++;
 					if(tp == n)
 						tp = 0;
 				}
 			}
 			printf("Case #%d: ",case_t++);
 			printf("%lld\n",ans);
 		}
 	}
 	return 0;
 }
