#include <bits/stdc++.h>
 // iostream is too mainstream
 #include <cstdio>
 // bitch please
 #include <iostream>
 #include <algorithm>
 #include <cstdlib>
 #include <vector>
 #include <set>
 #include <map>
 #include <queue>
 #include <stack>
 #include <list>
 #include <cmath>
 #include <iomanip>
 #include <time.h>
 #define dibs reserve
 #define OVER9000 1234567890
 #define ALL_THE(CAKE,LIE) for(auto LIE =CAKE.begin(); LIE != CAKE.end(); LIE++)
 #define tisic 47
 #define soclose 1e-8
 #define chocolate win
 // so much chocolate
 #define patkan 9
 #define ff first
 #define ss second
 #define abs(x) ((x < 0)?-(x):x)
 #define uint unsigned int
 #define dbl long double
 #define pi 3.14159265358979323846
 using namespace std;
 // mylittledoge
 
 #ifdef DONLINE_JUDGE
 	// palindromic tree is better than splay tree!
 	#define lld I64d
 #endif
 
 int main() {
 	cin.sync_with_stdio(0);
 	cin.tie(0);
 	cout << fixed << setprecision(10);
 	int T, M =24*60;
 	cin >> T;
 	int minex[2][2][M+1][M+1];
 	int fr[2][M];
 	for(int t =0; t < T; t++) {
 		cout << "Case #" << t+1 << ": ";
 		int N[2];
 		for(int i =0; i < 2; i++) cin >> N[i];
 		for(int i =0; i < 2; i++) {
 			for(int k =0; k < M; k++) fr[i][k] =1;
 			for(int j =0; j < N[i]; j++) {
 				int a,b;
 				cin >> a >> b;
 				for(int k =a; k < b; k++) fr[i][k] =0;}
 			for(int j =0; j < 2; j++) for(int k =0; k <= M; k++) for(int l =0; l <= k; l++)
 				minex[i][j][k][l] =10*M+100;
 			minex[i][i][0][0] =0;}
 		for(int i =0; i < M; i++) for(int a =0; a < 2; a++) for(int b =0; b < 2; b++) {
 			for(int k =0; k < 2; k++) if(fr[k][i]) for(int j =0; j <= i; j++)
 				minex[a][k][i+1][j+k] =min(minex[a][k][i+1][j+k],minex[a][b][i][j]+(k^b));
 			}
 		minex[0][1][M][M/2]++;
 		minex[1][0][M][M/2]++;
 		int ans =10*M+100;
 		for(int i =0; i < 4; i++) ans =min(ans,minex[i/2][i%2][M][M/2]);
 		cout << ans << "\n";}
 	return 0;}
 
 // look at my code
 // my code is amazing
#include <bits/stdc++.h>
 // iostream is too mainstream
 #include <cstdio>
 // bitch please
 #include <iostream>
 #include <algorithm>
 #include <cstdlib>
 #include <vector>
 #include <set>
 #include <map>
 #include <queue>
 #include <stack>
 #include <list>
 #include <cmath>
 #include <iomanip>
 #include <time.h>
 #define dibs reserve
 #define OVER9000 1234567890
 #define ALL_THE(CAKE,LIE) for(auto LIE =CAKE.begin(); LIE != CAKE.end(); LIE++)
 #define tisic 47
 #define soclose 1e-8
 #define chocolate win
 // so much chocolate
 #define patkan 9
 #define ff first
 #define ss second
 #define abs(x) ((x < 0)?-(x):x)
 #define uint unsigned int
 #define dbl long double
 #define pi 3.14159265358979323846
 using namespace std;
 // mylittledoge
 
 #ifdef DONLINE_JUDGE
 	// palindromic tree is better than splay tree!
 	#define lld I64d
 #endif
 
 int main() {
 	cin.sync_with_stdio(0);
 	cin.tie(0);
 	cout << fixed << setprecision(10);
 	int T, M =24*60;
 	cin >> T;
 	int minex[2][2][M+1][M+1];
 	int fr[2][M];
 	for(int t =0; t < T; t++) {
 		cout << "Case #" << t+1 << ": ";
 		int N[2];
 		for(int i =0; i < 2; i++) cin >> N[i];
 		for(int i =0; i < 2; i++) {
 			for(int k =0; k < M; k++) fr[i][k] =1;
 			for(int j =0; j < N[i]; j++) {
 				int a,b;
 				cin >> a >> b;
 				for(int k =a; k < b; k++) fr[i][k] =0;}
 			for(int j =0; j < 2; j++) for(int k =0; k <= M; k++) for(int l =0; l <= k; l++)
 				minex[i][j][k][l] =10*M+100;
 			minex[i][i][0][0] =0;}
 		for(int i =0; i < M; i++) for(int a =0; a < 2; a++) for(int b =0; b < 2; b++) {
 			for(int k =0; k < 2; k++) if(fr[k][i]) for(int j =0; j <= i; j++)
 				minex[a][k][i+1][j+k] =min(minex[a][k][i+1][j+k],minex[a][b][i][j]+(k^b));
 			}
 		minex[0][1][M][M/2]++;
 		minex[1][0][M][M/2]++;
 		int ans =10*M+100;
 		for(int i =0; i < 4; i++) ans =min(ans,minex[i/2][i%2][M][M/2]);
 		cout << ans << "\n";}
 	return 0;}
 
 // look at my code
 // my code is amazing
