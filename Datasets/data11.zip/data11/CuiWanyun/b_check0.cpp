#include<string>
 #include<algorithm>
 #include<cstdlib>
 #include<vector>
 #include<cmath>
 #include<iostream>
 using namespace std;
 const int maxn=1100,maxm=110;
 int n,m,im;
 string info[maxn],tabc[maxm],abc;
 string now;
 int bj[maxn];
 void init()
 {
   int i;
   cin>>n>>m;
   for (i=1;i<=n;i++)
     cin>>info[i];
   for (i=1;i<=m;i++)
     cin>>tabc[i];
 }
 int you(int ii,char t)
 {
   int i;
   for (i=0;i<(int)info[ii].size();i++)
     if (info[ii][i]==t) return 1;
   return 0;
 }
 void jia(int ii,char t)
 {
   int i;
   for (i=0;i<(int)info[ii].size();i++)
     if (info[ii][i]==t) now[i]=t;
 }
 int pipei(int ii)
 {
   int i;
   if (info[ii].size()!=now.size()) return 0;
   for (i=0;i<now.size();i++)
   {
     if (info[ii][i]==now[i]) continue;
     if (now[i]=='_') continue;
     return 0;
   }
   return 1;
 }
 void work()
 {
   int i,j,k,l,z,zz=0,ll;
   string zzz;
   for (i=1;i<=m;i++)
   {
     zz=-1;
     abc=tabc[i];
     if (i==2)
     {
       i++;
       i--;
     }
     for (j=1;j<=n;j++)
     {
       memset(bj,0,sizeof(bj));
       z=0;
       now="";
       for (k=0;k<(int)info[j].size();k++)
         now=now+'_';
       for (k=1;k<=n;k++)
         if (pipei(k)==0) bj[k]=1;
       for (k=0;k<26;k++)
         for (l=1;l<=n;l++)
           if (you(l,abc[k])&&pipei(l)&&bj[l]==0)
           {
             if (you(j,abc[k]))
             {
               jia(j,abc[k]);
               break;
             }
             else 
             {
               z++;
               for (ll=1;ll<=n;ll++)
                 if (you(ll,abc[k])) bj[ll]=1;
             }
           }
       if (z>zz)
       {
         zz=z;
         zzz=info[j];
       }
     }
     cout<<" "<<zzz;
   }
   cout<<endl;
 }
 int main()
 {
   freopen("b3.in","r",stdin);
   freopen("cb3.out","w",stdout);
   int cas,ii;
   cin>>cas;
   for (ii=1;ii<=cas;ii++)
   {
     init();
     printf("Case #%d:",ii);
     work();
   }
   return 0;
 }
