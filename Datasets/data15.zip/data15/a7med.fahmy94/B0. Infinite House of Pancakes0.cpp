#include <bits/stdc++.h>
 #define _SPEED_ ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
 #define ADJ vector< vector<int> > 
 #define VI vector<int>
 #define sz(x) (int)(x.size())
 #define endl '\n'
 #define pb push_back
 #define mp make_pair
 #define ll long long
 #define ii pair<int,int>
 #define F first
 #define S second
 #define all(x) (x).begin(),(x).end()
 #define oo numeric_limits<int>::max()
 #define OO numeric_limits<ll>::max()
 
 using namespace std;
 
 
 int main(){
 	_SPEED_
 	freopen("b.in" , "r" , stdin);
 	freopen("b.out" , "w" , stdout);
 	int T;
 	cin >> T;
 	for(int t = 1 ; t <= T ; ++t){
 		int n;
 		cin >> n;
 		priority_queue<int> q;
 		for(int i = 0 ; i < n ; ++i){
 			int x;cin >> x;
 			q.push(x);
 		}
 		int ans = q.top();
 		int step = 1;
 		while(q.top() != 1){
 			int top = q.top();
 			q.pop();
 			q.push(top/2);
 			q.push((top+1)/2);
 			ans = min(ans , step + q.top());
 			step++;
 		}
 		cout << "Case #" << t << ": " << ans << endl;
 	}
 }
