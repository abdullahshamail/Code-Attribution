#include <iostream>
 #include <string>
 #include <algorithm>
 #include <iomanip>
 #include <cstdio>
 #include <set>
 #include <cstdlib>
 #include <ctime>
 #include <sstream>
 #include <vector>
 #include <string.h>
 using namespace std;
 #define NN 100000
 #define ll long long
 #define pii pair<int,int>
 
 bool vowel(char c)
 {
 	if(c == 'a' || 
 	   c == 'e' || 
 	   c == 'i' || 
 	   c == 'o' ||
 	   c == 'u')
 	   return false;
 	return true;
 }
 
 int main()
 {
 	int t;
 	cin >> t;
 	
 	int n;
 	string s;
 	bool ok;
 	int res;
 	for(int cas = 1; cas <= t; cas ++)
 	{
 		cin >> s >> n;
 		// cout << s << endl;
 		res = 0;
 		for(int i = 0; i < s.size(); i ++)
 		{
 			for(int j = i; j < s.size(); j ++)
 			{
 				int now = 0;
 				ok = false;
 				for(int k = i; k <= j; k ++)
 				{
 					if(now >= n)
 						ok = true;
 					if( vowel(s[k]) == true )
 					{
 						now ++;
 					}
 					else
 					{
 						now = 0;
 					}
 					if(now >= n)
 						ok = true;
 				}
 				if(now >= n)
 					ok = true;
 				if(ok == true)
 				{
 					res ++;
 					// cout << i << " " << j << endl;
 				}
 			}
 		}
 		cout << "Case #" << cas << ": " << res << endl;
 	}
 	
 	return 0;
 }