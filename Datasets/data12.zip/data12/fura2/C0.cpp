#include<cstdio>
 
 #define rep(i,n) for(int i=0;i<(n);i++)
 
 using namespace std;
 
 int n,x[2000],ans[2000];
 
 bool dfs(int l,int r,int y){
 	ans[l]=y;
 
 	if(l==r-1) return true;
 	for(int i=l;i<r-1;i++) if(x[i]>=r) return false;
 
 	if(x[l]==l+1){
 		return dfs(l+1,r,y+1000);
 	}
 	else{
 		return dfs(l+1,x[l]+1,y-100) && dfs(x[l],r,y+1000);
 	}
 }
 
 void solve(){
 	scanf("%d",&n);
 	rep(i,n-1) scanf("%d",x+i), x[i]--;
 
 	if(!dfs(0,n,1000000)) puts("Impossible");
 	else{
 		rep(i,n) printf("%d%c",ans[i],i<n-1?' ':'\n');
 	}
 }
 
 int main(){
 	int T; scanf("%d",&T);
 	for(int t=1;t<=T;t++) printf("Case #%d: ",t), solve();
 	return 0;
 }
