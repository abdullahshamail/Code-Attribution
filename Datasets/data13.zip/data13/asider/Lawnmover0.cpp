#include <iostream>
 #include <vector>
 
 using namespace std;
 
 int main(int argc, char** argv)
 {
 	int T;
 	cin >> T;
 
 	int N, M;
 	for (int i = 0; i < T; i++)
 	{
 		cin >> N >> M;
 		vector<vector<int> >  lawn(N, vector<int>(M,0));
 		vector<vector<bool> > flag(N, vector<bool>(M,false));
 		for (int j = 0; j < N; j++)
 		{
 			for (int k = 0; k < M; k++){
 				cin >> lawn[j][k];
 				if (j == 0 || j == N-1 || k == 0 || k == M-1)
 					flag[j][k] = true;
 			}
 		}
 
 		// for each row except boundary
 		for (int j = 1; j < N-1; j++)
 		{
 			for (int k = 1; k < M-1; k++)
 			{
 				if (lawn[j][k] < lawn[j][k-1])
 					break;
 				flag[j][k] = true;
 			}
 			for (int k = M-2; k > 0; k--)
 			{
 				if (lawn[j][k] < lawn[j][k+1])
 					break;
 				flag[j][k] = true;
 			}
 		}
 
 		// for each column except boundary
 		for (int j = 1; j < M-1; j++)
 		{
 			for (int k = 1; k < N-1; k++)
 			{
 				if (lawn[k][j] < lawn[k-1][j])
 					break;
 				flag[k][j] = true;
 			}
 			for (int k = N-2; k > 0; k--)
 			{
 				if (lawn[k][j] < lawn[k+1][j])
 					break;
 				flag[k][j] = true;
 			}
 		}
 
 		bool resFlag = true;
 		for (int j = 0; j < N && resFlag; j++)
 		{
 			for (int k = 0; k < M && resFlag; k++)
 			{
 				if (!flag[j][k])
 				{
 					resFlag = false;
 					break;
 				}
 			}
 		}
 		if (resFlag)
 			cout << "Case #" << i+1 << ": YES" << endl;
 		else
 			cout << "Case #" << i+1 << ": NO" << endl;
 
 	}
 
 	return 0;
 }
 
