#include <iostream>
 #include <cstdio>
 #include <math.h>
 using namespace std;
 #define For(i,a,b) for(int i=a;i<=b;i++)
 
 float x[5], y[5], r[5], res;
 int n;
 
 float sqr (float a) { return a*a;}
 
 int main(){
     freopen("d.in", "r", stdin);
     freopen("d.out","w", stdout);
     int n0ftest;
     cin>>n0ftest;
     For(test,1,n0ftest){
         cin>>n;
         For(i,1,n) cin>>x[i]>>y[i]>>r[i];
         if (n==1) res=r[1]; else {
             res=1000000000;
             For(i,1,n-1)    
                 For(j,i+1,n) {
                     float tmp = sqrt ( sqr (x[i]-x[j]) + sqr (y[i]-y[j]) );
                     tmp += r[i] + r[j];
                     tmp /= 2;
                     res = min (res, tmp);
                 }
         }
         printf("Case #%d: %0.10f\n", test, res);
     }
 }
