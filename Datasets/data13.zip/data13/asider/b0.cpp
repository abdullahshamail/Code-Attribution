#include <iostream>
 
 using namespace std;
 int main(int argc, char* argv[])
 {
 	int T;
 	cin >> T;
 
 	for (int caseId = 1; caseId <= T; caseId++)
 	{
 		int X, Y;
 		cin >> X >> Y;
 
 		string path;
 
 		int num = abs(X);
 		if (X > 0)
 		{
 			path.append(num, 'E');
 		}else if (X < 0)
 		{
 			path.append(num, 'W');
 		}
 
 		num = abs(Y);
 		if (Y > 0)
 		{
 			path.append(num, 'N');
 		}else if (Y < 0)
 		{
 			path.append(num, 'S');
 		}
 		cout << "Case #" << caseId << ": " << path.c_str() << endl;
 	}
 
 
 	return 0;
 }
 
