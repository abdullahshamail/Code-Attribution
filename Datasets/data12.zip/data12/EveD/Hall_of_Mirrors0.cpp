#include <iostream>
 #include <fstream>
 #include <conio.h>
 #include <ios>
 #include <map>
 #include <sstream>
 #include <malloc.h>
 
 using namespace std;
 
 char mrrMatrix[128][128];
 
 #define OrzX 55
 #define OrzY 55
 #define iDirection int
 #define EAST 11
 #define WEST 22
 #define NORTH 33
 #define SOUTH 44
 
 class MirrorSpace
 {
 public:
 	int NEst, SEst, WEst, EEst;
 	int XposX, XposY;
 	int width, height, sight;
 	map<string, int> reflectSet;
 	void BuildSpace(int initX, int initY, iDirection toDir)
 	{
 		if (initX<=0 || initX>=128 || initY<=0 || initY>=128)
 		{
 			return;
 		}
 		if (mrrMatrix[initY][initX])
 		{
 			// built already
 			return;
 		}
 		if (OutOfSight(initX-XposX, initY-XposY)
 			&& OutOfSight(initX-XposX+width-1, initY-XposY)
 			&& OutOfSight(initX-XposX, initY-XposY+height-1)
 			&& OutOfSight(initX-XposX+width-1, initY-XposY+height-1))
 		{
 			// cannot see this space 
 			return;
 		}
 
 		if (toDir == EAST)
 		{
 			for (int i=0; i<height; i++)
 			{
 				for (int j=0; j<width; j++)
 				{
 					mrrMatrix[initY+i][initX+j] = mrrMatrix[initY+i][initX-j-1];
 					if (mrrMatrix[initY+i][initX+j] == 'X')
 					{
 						RecordReflect(initX+j, initY+i);
 					}
 				}
 			}
 			EEst<initX+width-1 ? EEst=initX+width-1 : NULL;
 			BuildSpace(initX, initY-height, NORTH);
 			BuildSpace(initX, initY+height, SOUTH);
 			BuildSpace(initX+width, initY, EAST);
 		}
 		else if (toDir == WEST)
 		{
 			for (int i=0; i<height; i++)
 			{
 				for (int j=0; j<width; j++)
 				{
 					mrrMatrix[initY+i][initX+j] = mrrMatrix[initY+i][initX+width*2-j-1];
 					if (mrrMatrix[initY+i][initX+j] == 'X')
 					{
 						RecordReflect(initX+j, initY+i);
 					}
 				}
 			}
 			WEst>initX ? WEst=initX : NULL;
 			BuildSpace(initX, initY+height, SOUTH);
 			BuildSpace(initX, initY-height, NORTH);
 			BuildSpace(initX-width, initY, WEST);
 		}
 		else if (toDir == SOUTH)
 		{
 			for (int i=0; i<height; i++)
 			{
 				for (int j=0; j<width; j++)
 				{
 					mrrMatrix[initY+i][initX+j] = mrrMatrix[initY-i-1][initX+j];
 					if (mrrMatrix[initY+i][initX+j] == 'X')
 					{
 						RecordReflect(initX+j, initY+i);
 					}
 				}
 			}
 			SEst<initY+height-1 ? SEst=initY+height-1 : NULL;
 			BuildSpace(initX+width, initY, EAST);
 			BuildSpace(initX-width, initY, WEST);
 			BuildSpace(initX, initY+height, SOUTH);
 		}
 		else if (toDir == NORTH)
 		{
 			for (int i=0; i<height; i++)
 			{
 				for (int j=0; j<width; j++)
 				{
 					mrrMatrix[initY+i][initX+j] = mrrMatrix[initY+height*2-i-1][initX+j];
 					if (mrrMatrix[initY+i][initX+j] == 'X')
 					{
 						RecordReflect(initX+j, initY+i);
 					}
 				}
 			}
 			NEst>initY ? NEst=initY : NULL;
 			BuildSpace(initX-width, initY, WEST);
 			BuildSpace(initX+width, initY, EAST);
 			BuildSpace(initX, initY-height, NORTH);
 		}
 		return;
 	}
 	bool OutOfSight(int destX, int destY)
 	{
 		return ((destX*destX + destY*destY) > sight*sight);
 	}
 	void RecordReflect(int X, int Y)
 	{
 		int iX = X-XposX, iY = Y-XposY;
 		double angle;
 		int areaNO;
 		double fX = (double)iX;
 		double fY = (double)iY;
 		if (!OutOfSight(iX, iY))
 		{
 			if (iX == 0 && iY > 0)
 			{
 				angle = 1111;
 				areaNO = 0;
 			}
 			else if (iX == 0 && iY < 0)
 			{
 				angle = -1111;
 				areaNO = 0;
 			}
 			else if (iX > 0 && iY == 0)
 			{
 				angle = 0.001;
 				areaNO = 0;
 			}
 			else if (iX < 0 && iY == 0)
 			{
 				angle = -0.001;
 				areaNO = 0;
 			}
 			else if (iX > 0 && iY > 0)
 			{
 				angle = fY/fX;
 				areaNO = 1;
 			} 
 			else if (iX < 0 && iY > 0)
 			{
 				angle = fY/fX;
 				areaNO = 2;
 			} 
 			else if (iX < 0 && iY < 0)
 			{
 				angle = fY/fX;
 				areaNO = 3;
 			} 
 			else if (iX > 0 && iY < 0)
 			{
 				angle = fY/fX;
 				areaNO = 4;
 			} 
 			else
 			{
 				return;
 			}
 			reflectSet[showRef(angle, areaNO)] = 1;
 		}
 	}
 	string showRef(double angle, int areaNO)
 	{
 		stringstream ss;
 		ss << areaNO << " : " << angle;
 		string s = ss.str();
 		return s;
 	}
 	void reduceMirror(int X, int Y)
 	{
 		double fY = (double)Y;
 		double fX = (double)X;
 		if (X > XposX && Y == XposY)
 		{
 			double highRatio = 0.5/(double)(X-XposX);
 			double lowRatio = -highRatio;
 			for (int i=X; i<=EEst; i++)
 			{
 				for (int j=(int)(fY+(lowRatio)*(i-XposX)); (double)j<fY+(highRatio)*(i-XposX); j++)
 				{
 					// copy
 					CopyBlock(X*2-i-1, j, i, j);
 				}
 			}
 		}
 	}
 	void CopyBlock(int fromX, int fromY, int toX, int toY)
 	{}
 	void PrintSpace()
 	{
 		for (int i=NEst; i<=SEst; i++)
 		{
 			for (int j=WEst; j<=EEst; j++)
 			{
 				cout << mrrMatrix[i][j];
 			}
 			cout << endl;
 		}
 		cout << endl;
 	}
 protected:
 private:
 };
 
 void main()
 {
 	cout << "Press any key to execute." << endl;
 	_getch();
 
 	/*loading file section*/
 	ifstream inFile;
 	inFile.open("D-small-attempt3.in");
 	if (!inFile.is_open())
 	{
 		cout << "Input File dose not exist." << endl;
 		return;
 	}
 
 	/*reading file section*/
 	//pre-reading
 	ofstream outFile;
 	outFile.open("D-small-attempt3.out", ios_base::out|ios_base::trunc);
 	if (!inFile.is_open())
 	{
 		cout << "Output File could not open." << endl;
 		return;
 	}
 	int case_Count;
 	//add parameter to be used here
 	int H, W;
 
 	//reading procedure
 	inFile >> case_Count;
 	for (int i=0; i<case_Count; i++)
 	{
 		//
 		MirrorSpace mSpace;
 		inFile >> H/*input data receiver*/;
 		mSpace.height = H-2;
 		inFile >> W/*input data receiver*/;
 		mSpace.width = W-2;
 		inFile >> mSpace.sight/*input data receiver*/;
 		//
 		memset(mrrMatrix, 0, sizeof(char)*128*128);
 		mSpace.NEst = OrzY; mSpace.SEst = OrzY+mSpace.height-1;
 		mSpace.WEst = OrzX; mSpace.EEst = OrzX+mSpace.width-1;
 		char ch;
 		for (int j=0; j<H; j++)
 		{
 			for (int k=0; k<W; k++)
 			{
 				inFile >> ch;
 				if (ch == 'X')
 				{
 					mSpace.XposY = OrzY+j-1;
 					mSpace.XposX = OrzX+k-1;
 				}
 				if (j>0 && j<H-1 && k>0 && k<W-1)
 				{
 					mrrMatrix[OrzY+j-1][OrzX+k-1] = ch;
 				}
 			}
 		}
 		//PrintSpace();
 		int west = mSpace.WEst, east = mSpace.EEst,
 			north = mSpace.NEst, south = mSpace.SEst;
 		mSpace.BuildSpace(west+mSpace.width, north, EAST);
 		mSpace.BuildSpace(west-mSpace.width, north, WEST);
 		mSpace.BuildSpace(west, north+mSpace.height, SOUTH);
 		mSpace.BuildSpace(west, north-mSpace.height, NORTH);
 		mrrMatrix[mSpace.XposY][mSpace.XposX] = 'Y';
 		//mSpace.PrintSpace();
 
 		//
 		outFile << "Case #" << i+1 << ": " << mSpace.reflectSet.size() << endl;
 		outFile.flush();
 	}
 
 	/*exit section*/
 	cout << "Press any key to exit." << endl;
 	_getch();
 	inFile.close();
 	outFile.close();
 	return;
 }