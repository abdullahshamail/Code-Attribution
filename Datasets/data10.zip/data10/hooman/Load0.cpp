#include <stdio.h>
 #include <math.h>
 
 void main()
 {
 	FILE *in,*out;
 	in = fopen("Load.in","r");
 	out = fopen("Load.out","w+");
 
 	int T,t;
 	fscanf(in,"%d\n",&T);
 
 	for(t=0; t<T; t++)
 	{
 		int i,j,k;
 		int L,P,C;
 
 		printf("%d...",t+1);
 		fscanf(in,"%d %d %d\n",&L,&P,&C);
 //		printf("%d %d %d\n",L,P,C);
 		for(i=0;P>(L*C);i++)
 		{
 			L=(int)(sqrt(P)*sqrt(L));
 //			if(P%C)
 //				j=((P/C)+1);
 //			else
 //				j=P/C;
 //			if(j>L)
 //				L=j;
 //			else
 //				break;
 		}
 
 		fprintf(out,"Case #%d: %d\n",t+1,i);
 		printf("Done!\n");
 	}
 	fclose(in);
 	fclose(out);
 }
