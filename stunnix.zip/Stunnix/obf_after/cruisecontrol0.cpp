
#include<bits/stdc++.h>
 using namespace std;
 
 int main(){
     ios_base::sync_with_stdio(0);cin.tie(0);
     freopen("input.in","r",stdin);
     freopen("output.txt","w",stdout);
     cout<<fixed<<setprecision(6);
     int t,ReplacementFor_i,n,ReplacementFor_d,k,s;
     double ReplacementFor_z;
     cin>>t;
     for(ReplacementFor_i=1;ReplacementFor_i<=t;++ReplacementFor_i){
         ReplacementFor_z=0.0;
         cin>>ReplacementFor_d>>n;
         while(n--){
             cin>>k>>s;
             ReplacementFor_z=max(ReplacementFor_z,(double)(ReplacementFor_d-k)/s);
         }
         cout<<"Case #"<<ReplacementFor_i<<": "<<ReplacementFor_d/ReplacementFor_z<<"\n";
     }
 }
#include<bits/stdc++.h>
 using namespace std;
 
 int main(){
     ios_base::sync_with_stdio(0);cin.tie(0);
     freopen("input.in","r",stdin);
     freopen("output.txt","w",stdout);
     cout<<fixed<<setprecision(6);
     int t,ReplacementFor_i,n,ReplacementFor_d,k,s;
     double ReplacementFor_z;
     cin>>t;
     for(ReplacementFor_i=1;ReplacementFor_i<=t;++ReplacementFor_i){
         ReplacementFor_z=0.0;
         cin>>ReplacementFor_d>>n;
         while(n--){
             cin>>k>>s;
             ReplacementFor_z=max(ReplacementFor_z,(double)(ReplacementFor_d-k)/s);
         }
         cout<<"Case #"<<ReplacementFor_i<<": "<<ReplacementFor_d/ReplacementFor_z<<"\n";
     }
 }
#include<bits/stdc++.h>
 using namespace std;
 
 int main(){
     ios_base::sync_with_stdio(0);cin.tie(0);
     freopen("input.in","r",stdin);
     freopen("output.txt","w",stdout);
     cout<<fixed<<setprecision(6);
     int t,ReplacementFor_i,n,ReplacementFor_d,k,s;
     double ReplacementFor_z;
     cin>>t;
     for(ReplacementFor_i=1;ReplacementFor_i<=t;++ReplacementFor_i){
         ReplacementFor_z=0.0;
         cin>>ReplacementFor_d>>n;
         while(n--){
             cin>>k>>s;
             ReplacementFor_z=max(ReplacementFor_z,(double)(ReplacementFor_d-k)/s);
         }
         cout<<"Case #"<<ReplacementFor_i<<": "<<ReplacementFor_d/ReplacementFor_z<<"\n";
     }
 }
#include<bits/stdc++.h>
 using namespace std;
 
 int main(){
     ios_base::sync_with_stdio(0);cin.tie(0);
     freopen("input.in","r",stdin);
     freopen("output.txt","w",stdout);
     cout<<fixed<<setprecision(6);
     int t,ReplacementFor_i,n,ReplacementFor_d,k,s;
     double ReplacementFor_z;
     cin>>t;
     for(ReplacementFor_i=1;ReplacementFor_i<=t;++ReplacementFor_i){
         ReplacementFor_z=0.0;
         cin>>ReplacementFor_d>>n;
         while(n--){
             cin>>k>>s;
             ReplacementFor_z=max(ReplacementFor_z,(double)(ReplacementFor_d-k)/s);
         }
         cout<<"Case #"<<ReplacementFor_i<<": "<<ReplacementFor_d/ReplacementFor_z<<"\n";
     }
 }
#include<bits/stdc++.h>
 using namespace std;
 
 int main(){
     ios_base::sync_with_stdio(0);cin.tie(0);
     freopen("input.in","r",stdin);
     freopen("output.txt","w",stdout);
     cout<<fixed<<setprecision(6);
     int t,ReplacementFor_i,n,ReplacementFor_d,k,s;
     double ReplacementFor_z;
     cin>>t;
     for(ReplacementFor_i=1;ReplacementFor_i<=t;++ReplacementFor_i){
         ReplacementFor_z=0.0;
         cin>>ReplacementFor_d>>n;
         while(n--){
             cin>>k>>s;
             ReplacementFor_z=max(ReplacementFor_z,(double)(ReplacementFor_d-k)/s);
         }
         cout<<"Case #"<<ReplacementFor_i<<": "<<ReplacementFor_d/ReplacementFor_z<<"\n";
     }
 }

