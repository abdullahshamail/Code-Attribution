#include<iostream>
 #include<string>
 #include<fstream>
 #include<vector>
 using namespace std;
 
 int slarge(vector<int> arr)
 {
 	int index=0;
 	int largest = arr[0];
 	for(int i=0;i<arr.size();i++)
 	{
 		if(arr[i]>largest)
 		{
 			largest = arr[i];
 		}
 	}
 	int s=0;;
 	for(int i=0;i<arr.size();i++)
 	{
 		if(arr[i]>s && arr[i]!=largest)
 		{
 			s = arr[i];
 			index =i;
 		}
 	}
 	return index;
 }
 int largest(vector<int> arr)
 {
 	int index=0;
 	int largest = arr[0];
 	for(int i=0;i<arr.size();i++)
 	{
 		if(arr[i]>largest)
 		{
 			largest = arr[i];
 			index =i;
 		}
 
 	}
 	return index;
 }
 int main()
 {
 	ifstream fin;
 	fin.open("in.txt");
 	ofstream out;
 	out.open("output.txt");
 	int cases;
 	fin>>cases;
 	int size;
 	int cake;
 	
 	for(int i=0;i<cases;i++)
 	{
 		vector<int> arr;
 		int mints =0;
 		fin>>size;
 		for(int j=0;j<size;j++)
 		{
 			fin>>cake;
 			arr.push_back(cake);
 		}
 		bool end = false;
 		int mylarge = arr[largest(arr)];
 		while(!end)
 		{
 			int i = largest(arr);
 			if(arr[i]<=3)
 			{
 				mints = mints+arr[i];
 			    end = true;
 			}
 			else if(arr[i]==4 && arr.size()>1)
 			{
 				int s = slarge(arr);
 				if(arr[s]<3)
 				{
 					mints = mints +3;
 					end  = true;
 				}
 				else
 				{
 					mints = mints +4;
 					end = true;
 				}
 			}
 			else if(arr[i]==4)
 			{
 				mints = mints+3;
 				end = true;
 			}
 			else if(arr[i]>mylarge/2)
 			{
 				if(arr[i]%2==0)
 				{
 					arr.push_back(arr[i]/2);
 					arr[i]=arr[i]/2;
 					mints++;
 				}
 				else
 				{
 					mints++;
 					for(int i=0;i<arr.size();i++)
 					{
 						arr[i]=arr[i]-1;
 					}
 				}
 			}
 			else
 			{
 				mints = mints + arr[i];
 				end = true;
 			}
 		}
 		out<<"Case #"<<i+1<<": "<<mints<<endl;
 	}
 	system("pause");
 	return 0;
 }