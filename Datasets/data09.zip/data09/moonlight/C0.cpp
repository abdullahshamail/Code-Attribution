#include<iostream>
 #include<cmath>
 #include<vector>
 using namespace std;
 
 int a[50][50];
 
 int q[50][50];
 int ql[50];
 
 bool flag[50];
 int main()
 {
     freopen("1.txt","r",stdin);//B-large.in
 	freopen("2.txt","w",stdout);
 	int cas,ca;
 	scanf("%d",&cas);
 	for(ca=1;ca<=cas;ca++)
 	{
 		int i,j,k;
 		int n,K;
 		scanf("%d %d",&n,&K);
 		for(i=0;i<n;i++)
 			for(j=0;j<K;j++)
 				scanf("%d",a[i]+j);
 		for(i=0;i<n;i++)
 		{
 			int mi = i;
 			for(j=i+1;j<n;j++)
 			{
 				for(k=0;k<K;k++)
 					if(a[j][k]!=a[mi][k])
 						break;
 				if(k<K && a[j][k] < a[mi][k] )
 					mi = j;
 			}
 			if(mi!=i)
 				for(k=0;k<K;k++)
 					swap(a[i][k],a[mi][k]);
 		}
 		/*for(i=0;i<n;i++,cout<<endl)
 			for(j=0;j<K;j++)
 				cout<<a[i][j]<<' ';*/
 		int num=0,t;
 		memset(flag,0,sizeof(flag));
 		for(i=0;i<n;i++)
 			if(flag[i]==0)
 			{
 				//cout<<"I"<<i<<endl;
 				flag[i]==1;
 				num++;
 				t = i;
 				for(j=i+1;j<n;j++)
 				{
 					if(flag[j])
 						continue;
 					for(k=0;k<K;k++)
 						if(a[j][k]<=a[t][k])
 							break;
 					if(k==K)
 					{
 						flag[j]=1;
 						t = j;
 						//cout<<"J"<<j<<endl;
 					}
 				}
 			}
 		printf("Case #%d: %d\n",ca,num);
 	}
 }
