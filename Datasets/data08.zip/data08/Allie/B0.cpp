#include <vector>
 #include <algorithm>
 #include <utility>
 #include <iostream>
 #include <sstream>
 
 using namespace std;
 
 typedef pair<int, int> pii;
 typedef vector<bool> VB; 
 
 #define SZ(c) ((int) (c).size())
 
 char buf[256];
 
 int readInt() {
 	cin.getline(buf, 256);
 	int x;
 	istringstream(string(buf)) >> x;
 	return x;
 }
 
 inline int mininutes(int h, int m) {
 	return h * 60 + m;
 }
 
 void dfs(int at, const vector<pii> a, const vector<pii> &b, int t, VB &markA, VB &markB) {
 	markA[at] = true;
 	int j = -1;
 	for (int i = 0; i < SZ(b); ++i) 
 		if (!markB[i] && a[at].second + t <= b[i].first && (j == -1 || b[i].second <= b[j].second))
 			j = i;
 	if (j != -1)
 		dfs(j, b, a, t, markB, markA);
 }
 
 pii need(const vector<pii> &a, const vector<pii> &b, int t) {
 	int rA = 0;
 	int rB = 0;
 	int nA = SZ(a);
 	int nB = SZ(b);
 	VB markA(nA);
 	VB markB(nB);
 	int i = 0;
 	int j = 0;
 	while (true) {
 		while (i < nA && markA[i])
 			++i;
 		while (j < nB && markB[j])
 			++j;
 		if (i >= nA && j >= nB)
 			break;
 		if (i >= nA) {
 			markB[j++] = true;
 			++rB;
 			continue;
 		}
 		if (j >= nB) {
 			markA[i++] = true;
 			++rA;
 			continue;
 		}
 		if (a[i].first <= b[j].first) {
 			dfs(i++, a, b, t, markA, markB);
 			++rA;
 		} else {
 			dfs(j++, b, a, t, markB, markA);
 			++rB;
 		}
 	}
 	return make_pair(rA, rB);		
 }
 
 int main() {
 	freopen("B-small.in", "r", stdin);
 	freopen("B-small.out", "w", stdout);
 	int numCases = readInt();
 	for (int c = 1; c <= numCases; ++c) {
 		int t = readInt();
 		int na, nb;
 		cin.getline(buf, 256);
 		istringstream(string(buf)) >> na >>  nb;
 		vector<pii> a;
 		for (int i = 0; i < na; ++i) {
 			int h1, m1, h2, m2;
 			cin.getline(buf, 256);
 			sscanf(buf, "%d:%d %d:%d", &h1, &m1, &h2, &m2);
 			a.push_back(make_pair(mininutes(h1, m1), mininutes(h2, m2)));
 		}
 		sort(a.begin(), a.end());
 		vector<pii> b;
 		for (int i = 0; i < nb; ++i) {
 			int h1, m1, h2, m2;
 			cin.getline(buf, 256);
 			sscanf(buf, "%d:%d %d:%d", &h1, &m1, &h2, &m2);
 			b.push_back(make_pair(mininutes(h1, m1), mininutes(h2, m2)));
 		}
 		sort(b.begin(), b.end());
 		pii res = need(a, b, t);
 		printf("Case #%d: %d %d\n", c, res.first, res.second);
 	}
 	return 0;
 }