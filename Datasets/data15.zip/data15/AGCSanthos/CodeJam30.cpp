#include <iostream>
 #include <cstdio>
 #include <string>
 
 void multiply( std::string &str, int &numNeg );
 void addNeg( std::string &str, int &numNeg );
 
 int main(){
 	std::freopen( "C-small-attempt2.in", "r", stdin );
 	std::freopen( "C-small-attempt2.out", "w", stdout );
 	int numCases;
 	std::cin >> numCases;
   for( int curCase = 1; curCase <= numCases; curCase++ ) {
 		std::string original;
 		std::string originalm = "";
 		int uneeded;
 		int repetition;
 		std::cout << "Case #" << curCase << ": ";
 
 		std::cin >> uneeded;
 		std::cin >> repetition;
 		std::cin >> original;
 		
 		for( int m = 0; m < repetition; ++m ){
 			originalm = originalm + original;
 		}
 		if( (int) originalm.length() < 3 ){
 			if( curCase != numCases ){
 				std::cout << "NO" << std::endl;
 			}
 			else {
 					std::cout << "NO";
 			}
 		}
 		else{
 			int numNeg = 0;
 			int third = ((int)(originalm.length()))/3;
 			std::string third1 = originalm.substr(0,third);
 			std::string third2 = originalm.substr(third, third);
 			std::string third3 = originalm.substr(2*third);
 			multiply( third1, numNeg );
 			addNeg( third1, numNeg );
 			numNeg = 0;
 			multiply( third2, numNeg );
 			addNeg( third2, numNeg );
 			numNeg = 0;
 			multiply( third3, numNeg );
 			addNeg( third3, numNeg );
 			
 			if( curCase != numCases ){
 				if( third1 == "i" && third2 == "j" && third3 == "k" ){
 					std::cout << "YES" << std::endl;
 				}
 				else {
 					std::cout << "NO" << std::endl;
 				}
 			}
 			else {		
 				if( third1 == "i" && third2 == "j" && third3 == "k" ){
 					std::cout << "YES";
 				}
 				else {
 					std::cout << "NO";
 				}
 			}
 		}
 		
 	}
 	
 	return 0;
 }
 
 void multiply( std::string &str, int &numNeg ){
 	while( (int)str.length() > 1 ){
 		
 		if( str[0] == str[1] && str[0] != '1' ) {
 			numNeg += 1;
 			str.erase( str.begin() );
 			str[ 0 ] = '1';
 		}
 		else {
 			char tempInsert;
 			if( str[0] == '1' ){
 				tempInsert = str[1];
 			}
 			else if( str[1] == '1' ){
 				tempInsert = str[0];
 			}
 			else if( str[0] == 'i' ){
 				if( str[1] == 'j' ){
 					tempInsert = 'k';
 				}
 				else {
 					tempInsert = 'j';
 					numNeg += 1;
 				}
 			}
 			else if( str[0] == 'j' ){
 				if( str[1] == 'i' ){
 					tempInsert = 'k';
 					numNeg += 1;
 				}
 				else {
 					tempInsert = 'i';
 				}
 			}
 			//else if( str[0] == 'k' ){
 			else {
 				if( str[1] == 'i' ){
 					tempInsert = 'j';
 				}
 				else {
 					tempInsert = 'i';
 					numNeg += 1;
 				}
 			}
 			str.erase( str.begin() + 1 );
 			str[0] = tempInsert;
 		}			
 	}
 }
 
 void addNeg( std::string &str, int &numNeg ){
 	if( (int)str.length() == 0 ) {
 		if( numNeg % 2 != 0 ) {
 			str = "-1";
 		}
 		else {
 			str = "1";
 		}
 	}
 	else {
 		if( numNeg % 2 != 0 ){
 			str = "-" + str;
 		}
 	}
 }