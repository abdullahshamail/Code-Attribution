#include <cstdio>
 #include <cmath>
 #include <algorithm>
 #include <cstdlib>
 #include <set>
 #include <queue>
 #include <vector>
 #include <cstring>
 #include <string>
 #include <map>
 #include <iostream>
 
 using namespace std;
 
 int hasil;
 int n,arr[25],flag[25];
 
 int f(int x){
 	int sum1=0,sum2=0,tt=0;
 	int hasil1=0;
 	if (x>n) return 0;
 	for (int i=0;i<n;i++) {
 		tt+=flag[i];
 		if (flag[i]==0) {
 			sum1=sum1^arr[i];	
 			hasil1=hasil1+arr[i];
 		} else
 		{
 			sum2=sum2^arr[i];	
 		}
 	}	
 	if (tt!=0 && tt!=n && sum1==sum2)hasil=max(hasil,hasil1);
 	flag[x]=0;
 	f(x+1);
 	flag[x]=1;
 	f(x+1);
 }
 
 int main() {
 	int t,tes=1;
 	scanf("%d",&t);
 	while (t--) {
 		memset(flag,0,sizeof(flag));
 	scanf("%d",&n);
 	hasil=-1;
 	for (int i=0;i<n;i++) {
 		scanf("%d",&arr[i]);	
 	}
 	f(0);
 	printf("Case #%d: ",tes++);
 	if (hasil==-1) printf("NO\n"); else printf("%d\n",hasil);
 	}
 	return 0;
 }
