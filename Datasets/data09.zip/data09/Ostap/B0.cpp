#include <iostream>
 #include <sstream>
 #include <cstdio>
 #include <cstdlib>
 #include <cmath>
 #include <string>
 #include <cctype>
 #include <memory>
 #include <vector>
 #include <list>
 #include <queue>
 #include <deque>
 #include <stack>
 #include <map>
 #include <set>
 #include <algorithm>
 
 using namespace std;
 
 typedef long long Int;
 typedef long double Double;
 typedef vector<int> VInt;
 typedef vector< vector<int> > VVInt;
 typedef pair<int,int> PII;
 
 #define FOR(i,n,m) for(i=(n); i<(m); ++i)
 #define RFOR(i,n,m) for(i=(n)-1; i>=(m); --i)
 #define CLEAR(x,y) memset((x), (y), sizeof(x))
 #define COPY(x,y) memcpy((x),(y),sizeof(x))
 #define PB push_back
 #define MP make_pair
 #define SIZE(v) ((int)((v).size()))
 #define ALL(v) (v).begin(), (v).end()
 
 int R[55][55][55][55];
 char B[55][55];
 
 int main()
 {
 	freopen("B-small.in", "r", stdin);
 	freopen("B-small.out", "w", stdout);
 //	freopen("-large.in", "r", stdin);
 //	freopen("-large.out", "w", stdout);
 	int t, T;
 	scanf("%d", &T);
 	for (t = 0; t < T; ++t)
 	{
 		int N, M, F;
 		scanf("%d%d%d", &N, &M, &F);
 		int i, j;
 		for (i = 0; i < N; ++i)
 			scanf("%s", B[i]);
 		CLEAR(R, -1);
 		R[0][0][0][0] = 0;
 		int b, e;
 		for (i = 0; i < N-1; ++i)
 			for (b = 0; b < M; ++b)
 				for (e = 0; e <= M; ++e)
 				{
 					// right
 					for (j = 0; j < M; ++j)
 						if (R[i][j][b][e] != -1)
 							if (j + 1 < M && (B[i][j+1] == '.' || (j+1 >= b && j+1 < e)))
 							{
 								int cr = R[i][j][b][e];
 								if (B[i+1][j+1] != '.')
 								{
 									if (R[i][j+1][b][e] == -1 || R[i][j+1][b][e] > cr)
 										R[i][j+1][b][e] = cr;
 								}
 								else
 								{
 									int q;
 									for (q = i+2; q < N; ++q)
 										if (B[q][j+1] != '.')
 											break;
 									--q;
 									if (q-i <= F)
 									{
 										if (R[q][j+1][0][0] == -1 || R[q][j+1][0][0] > cr)
 											R[q][j+1][0][0] = cr;
 									}
 								}
 							}
 					// left
 					for (j = 0; j < M; ++j)
 						if (R[i][j][b][e] != -1)
 							if (j - 1 >= 0 && (B[i][j-1] == '.' || (j-1 >= b && j-1 < e)))
 							{
 								int cr = R[i][j][b][e];
 								if (B[i+1][j-1] != '.')
 								{
 									if (R[i][j-1][b][e] == -1 || R[i][j-1][b][e] > cr)
 										R[i][j-1][b][e] = cr;
 								}
 								else
 								{
 									int q;
 									for (q = i+2; q < N; ++q)
 										if (B[q][j-1] != '.')
 											break;
 									--q;
 									if (q-i <= F)
 									{
 										if (R[q][j-1][0][0] == -1 || R[q][j-1][0][0] > cr)
 											R[q][j-1][0][0] = cr;
 									}
 								}
 							}
 					// dig
 					for (j = 0; j < M; ++j)
 						if (R[i][j][b][e] != -1)
 						{
 							int cr = R[i][j][b][e];
 							// right
 							if (j > 0 && (B[i][j-1] == '.' || (j-1 >= b && j-1 < e)) && B[i+1][j-1] != '.')
 							{
 								int q;
 								for (q = i+2; q < N; ++q)
 									if (B[q][j-1] != '.')
 										break;
 								--q;
 								if (q-i <= F)
 								{
 									if (R[q][j-1][0][0] == -1 || R[q][j-1][0][0] > cr+1)
 										R[q][j-1][0][0] = cr+1;
 								}
 								int p;
 								for (p = j; p < N; ++p)
 								{
 									if (!(B[i][p] == '.' || (p >= b && p < e)))
 										break;
 									if (B[i+1][p] == '.')
 										break;			
 									if (i+2 >= N || B[i+2][p-1] == '.')
 										break;
 									if (R[i+1][p-1][j-1][p] == -1 || R[i+1][p-1][j-1][p] > cr+p-j+1)
 										R[i+1][p-1][j-1][p] = cr+p-j+1;
 								}
 							}
 							// left
 							if (j < M-1 && (B[i][j+1] == '.' || (j+1 >= b && j+1 < e)) && B[i+1][j+1] != '.')
 							{
 								int q;
 								for (q = i+2; q < N; ++q)
 									if (B[q][j+1] != '.')
 										break;
 								--q;
 								if (q-i <= F)
 								{
 									if (R[q][j+1][0][0] == -1 || R[q][j+1][0][0] > cr+1)
 										R[q][j+1][0][0] = cr+1;
 								}
 								int p;
 								for (p = j; p >= 0; --p)
 								{
 									if (!(B[i][p] == '.' || (p >= b && p < e)))
 										break;
 									if (B[i+1][p] == '.')
 										break;			
 									if (i+2 >= N || B[i+2][p+1] == '.')
 										break;
 									if (R[i+1][p+1][p+1][j+1] == -1 || R[i+1][p+1][p+1][j+1] > cr+j-p+1)
 										R[i+1][p+1][p+1][j+1] = cr+j-p+1;
 								}
 							}
 						}
 
 				}
 		int res = 1000000000;
 		for (b = 0; b < N; ++b)
 			for (e = b; e <= N; ++e)
 				for (j = 0; j < M; ++j)
 					if (R[N-1][j][b][e] != -1)
 						res = min(res, R[N-1][j][b][e]);
 		printf("Case #%d: ", t+1);
 		if (res == 1000000000)
 			printf("No\n");
 		else
 			printf("Yes %d\n", res);
 
 		fprintf(stderr, "%d\n", t+1);
 	}
 
 
 	return 0;
 }