#include <cstdio>
 #include <cstring>
 
 int R, k, N;
 int g[1024], a[1024][2];
 int main() {
 	int T; scanf("%d", &T);
 	for (int cas=0;cas<T;++cas) {
 		memset(a, -1, sizeof(a));
 		int ret = 0;
 		scanf("%d%d%d", &R, &k, &N);
 		for (int i=0;i<N;++i) scanf("%d", g+i);
 		int m = 0, gp = 0;
 		for (int i=1;i<=R;++i) {
 			a[gp][0] = ret;
 			a[gp][1] = i;
 			int j = gp;
 			for (m=0,j=gp;m+g[j]<=k;) {
 				m+=g[j];
 				++j; if (j>=N) j=0;
 				if (j==gp) break;
 			}
 			gp = j;
 			ret += m;
 			if (a[gp][1] != -1) {
 				int tmp = ret - a[gp][0];
 				int rnd = i - a[gp][1] + 1;
 				ret += tmp * ((R - i) / rnd);
 				i += (R - i) / rnd * rnd;
 			}
 		}
 		printf("Case #%d: %d\n", cas+1, ret);
 	}
 	return 0;
 }
