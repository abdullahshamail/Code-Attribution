#include <cstdio>
 #include <cstring>
 #include <algorithm>
 #include <iostream>
 
 using namespace std;
 typedef long long ll;
 const int maxn=1000+123;
 
 struct Node{
     int num, a, b;
 }s[maxn], t[maxn];
 
 bool cmp1(Node a, Node b)
 {
     if(a.b==b.b)return a.a>b.a;
     return a.b<b.b;
 }
 
 bool cmp2(Node x, Node y)
 {
     if(x.a==y.a)return x.b>y.b;
     return x.a<y.a;
 }
 int flag[maxn];
 
 int main ()
 {
     int cas;
     freopen ("bbbb.in", "r", stdin);
     freopen ("b.out", "w", stdout);
     scanf("%d", &cas);
     int n;
     for (int I=1; I<=cas; ++I)
     {
         scanf("%d", &n);
         //printf("%d\n", n);
         int ans=0, star=0;
         for (int i=0; i<n; ++i)
         {
             scanf("%d %d", &s[i].a, &s[i].b);
             //printf("%d %d\n", s[i].a, s[i].b);
             s[i].num=t[i].num=i;
             t[i].a=s[i].a; t[i].b=s[i].b;
         }
         memset (flag, 0, sizeof(flag));
         sort(s, s+n, cmp1);
         sort(t, t+n, cmp2);
         for (int i=0; i<n;)
         {
             const int & id=s[i].num;
             //printf("%d %d\n", i, j);
             if(flag[id]==2)
             {
                 ++i;
                 continue;
             }
             if(star>=s[i].b)
             {
                 star+=2-flag[id]; ans++;
                 flag[id]=2;
                 ++i;
                 continue;
             }
             else
             {
                 bool is=false;
                 for (int j=0; j<n; ++j)
                 {
                     const int &jd=t[j].num;
                     if(flag[jd]==0)
                     if(star>=t[j].a)
                     {
                         star++;
                         flag[jd]=1;
                         ans++;
                         is=true;
                         break;
                     }
                 }
                 if(!is)break;
             }
         }
         bool sus=true;
         for (int i=0; i<n; ++i)
         {
             if(flag[i]!=2)sus=false;
         }
         if(sus)
             printf("Case #%d: %d\n", I, ans);
         else
             printf("Case #%d: Too Bad\n", I);
     }
     return 0;
 }
 
