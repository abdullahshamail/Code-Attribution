#include <iostream>
 using namespace std;
 int main()
 {
 	cout<<"hello"<<endl;
 #ifdef _DEBUG
 	system("pause");
 #endif
 	return 0;
 }