#include <stdio.h>
 #include <stdlib.h>
 #include <string>
 #include <iostream>
 #include <fstream>
 #include <sstream>
 
 using namespace std;
 
 ifstream inputFile;
 ofstream outputFile;
 
 void OpenInputFile(char* filename);
 void OpenOutputFile(char* filename);
 void FindSolution(int caseNum, int googler, int surpriseCase, int maxScore, int totalScores[]);
 
 int main()
 {
     OpenInputFile("B-small-attempt2.in");
     OpenOutputFile("output.out");
 
     if (inputFile.is_open())
     {
        int numCase;
        inputFile >> numCase;
        
        for (int i = 0; i < numCase; ++i)
        {
            int googler, surprise, maxScore;
            inputFile >> googler;
            inputFile >> surprise;
            inputFile >> maxScore;
            int score[googler];
            for (int j = 0; j < googler; ++j)
            { 
                inputFile >> score[j];
            }
            FindSolution(i, googler, surprise, maxScore, score);
        }
     }
     else
     {
         cout << "Failed to open input file.\n";
     }
     
     inputFile.close();
     outputFile.close();
     
     cin.get();
     cin.get();
     return 0;
 }
 
 void OpenInputFile(char* filename)
 {
      inputFile.open(filename);
 }
 
 void OpenOutputFile(char* filename)
 {
      outputFile.open(filename);
 }
 
 void FindSolution(int caseNum, int googler, int surpriseCase, int maxScore, int totalScores[])
 {
      struct scorePlaceHolder {
             int divident;
             int modulus;
      };
      scorePlaceHolder judgesScore[googler];
      
      int answer = 0;
      int tempSurpriseHold = surpriseCase;
      for (int i = 0; i < googler; ++i)
      {
          judgesScore[i].divident = totalScores[i] / 3;
          judgesScore[i].modulus = totalScores[i] % 3;
          
          if (judgesScore[i].divident >= maxScore)
          {
             ++answer;
          }
          else if (judgesScore[i].divident + judgesScore[i].modulus >= maxScore)
          {    
               if (judgesScore[i].modulus == 1)
               {
                  ++answer;
               }
               if (judgesScore[i].modulus == 2)
               {
                  if (tempSurpriseHold > 0)
                  {
                     ++answer;
                     --tempSurpriseHold;
                  }
                  else if (abs(maxScore - judgesScore[i].divident) == 1)
                  {
                       ++answer;
                  }
               }
          }
          else if (judgesScore[i].divident >= 2 && tempSurpriseHold > 0 && 
                   abs(maxScore - (judgesScore[i].divident + judgesScore[i].modulus)) <= 2)
          {
               ++answer;
               --tempSurpriseHold;
          } 
      }
      
      cout << "answer: " << answer << endl;
      outputFile << "Case #" <<caseNum + 1 << ": " << answer << "\n";
 }
