// myproj.cpp : Defines the entry point for the console application.
 //
 
 #include "stdafx.h"
 #include "iostream"
 #include "fstream"
 #include "stdio.h"
 #include <string>
 #include "conio.h"
 
 using namespace std;
 
 
 void processData (string * pEngineNames, int pEngineCount, string* pData, int pDataStart, int pDataCount, int & pSwitches)
 {
 	if(pEngineCount == 0)
 		return;
 
 	int* posArray = new int [pEngineCount];
 
 	for (int i=0; i<pEngineCount; i++)
 	{	
 		string engine = pEngineNames[i];
 		posArray[i] = -1;
 		for(int j=pDataStart; j<pDataCount; j++)
 		{
 			string data = pData[j];
 			if(stricmp(engine.c_str(), data.c_str()) == 0)
 			{
 				posArray[i] = j;
 				break;
 			}
 		}
 	}
 	
 	int maxElem = posArray[0];
 	for (int i=0; i<pEngineCount; i++)
 	{
 		if(posArray[i] == -1)
 			return;
 		else if(posArray[i] > maxElem)
 			maxElem = posArray[i];
 	}
 	pSwitches++;
 	processData(pEngineNames, pEngineCount, pData, maxElem, pDataCount, pSwitches);
 }
 
 int main(int argc, char* argv[])
 {
 	string line;
 	if (argc != 3)
 	{
 		cout <<"Wrong input!!! \n Correct syntax: <program name>  <abs path to input file> <abs path to out file>";
 		return 1;
 	}
 
 	string* engineNames = new string[100];
 	string* data = new string[1000];
 
 	string output;
 
 	ifstream myfile (argv[1]);
 	ofstream outFile;
 	if (myfile.is_open())
 	{
 		int lineNum = 0;
 		int numOfTests = 0;
 		bool isEngineInfo = true;
 		bool isData = false;
 		bool isDataHeader = false;
 		bool isEngineHeader = true;
 
 		int counter = 0;
 		int numOfEngines = 0;
 		int dataCount = 0;
 		int numOfSwitches = 0;
 		int caseNum = 0;
 		char buf[100];
 
 		while (! myfile.eof() )
 		{
 		  getline (myfile,line);
 		  lineNum ++;
 		  if (lineNum == 1)
 		  {
 			numOfTests = atoi(line.c_str());
 			continue;
 		  }
 		  else if(isEngineInfo == true ) {
 			  if (isEngineHeader == true) {
 				   if(lineNum != 2)
 				   {
 
 					   processData(engineNames, numOfEngines, data, 0, dataCount, numOfSwitches);
 
 					   output.append("Case #");
 					   itoa(caseNum,buf, 10);
 					   output.append(buf);
 					   itoa(numOfSwitches, buf, 10);
 					   output.append(": ");
 					   output.append(buf);
 					   output.append("\n");
 					   
 					   delete [] engineNames;
 					   delete [] data;
 					   numOfSwitches = 0;
 					   engineNames = new string[100];
 					   data = new string[1000];
 				   }
 
 				   numOfEngines = atoi(line.c_str());
 				   counter = 0;
 				   isEngineHeader = false;
 				}
 			  else {
 				  engineNames[counter] = line;
 				  counter++;
 				  if(counter == numOfEngines) {
 					  isEngineInfo = false;
 					  isEngineHeader = true;
 					  counter = 0;
 					  isData = true;
 					  isDataHeader = true;
 				  }
 			  }
 		  }
 		  else if(isData ==  true) {
 			if (isDataHeader == true) {
 			  		dataCount = atoi(line.c_str());
 					if(dataCount == 0)
 					{
 					  isEngineInfo = true;
 					  isEngineHeader = true;
 					  counter = 0;
 					  isData = false;
 					  isDataHeader = true;
 					  caseNum++;
 					}
 					counter = 0;
 					isDataHeader = false;
 				}
 			  else {
 				  data[counter] = line;
 				  counter++;
  				  if(counter == dataCount) {
 					  isEngineInfo = true;
 					  isEngineHeader = true;
 					  counter = 0;
 					  isData = false;
 					  isDataHeader = true;
 					  caseNum++;
 				  }
 			  }
 		  }
 		}
 	   outFile.open(argv[2], ios::out);
 		if (!outFile)
 		  cerr << "Can't open output file " << argv[2] << endl;
 		else
 			outFile << output;
 		outFile.close();
 
 		delete [] engineNames;
         delete [] data;
 		myfile.close();
 	}
 
 	return 0;
 }
 
