using namespace std;
 
 #include <set>
 #include <map>
 #include <list>
 #include <deque>
 #include <stack>
 #include <queue>
 #include <cmath>
 #include <cctype>
 #include <cstdio>
 #include <vector>
 #include <string>
 #include <bitset>
 #include <utility>
 #include <iomanip>
 #include <cstring>
 #include <sstream>
 #include <iostream>
 #include <algorithm>
 #include <functional>
 
 #define pb push_back
 #define size(V) ((int)(V.size()))
 #define f first
 #define s second
 #define II inline
 #define ll long long
 #define db double
 #define FORit(it, x) for (__typeof((x).begin()) it = (x).begin(); it != (x).end(); ++it)
 #define REP(i, N) for (int i = 0; i < (int)(N); ++i)
 #define FOR(i,a,b) for(int i=a;i<=b;++i)
 #define all(v) v.begin() , v.end()
 #define CC(v) memset((v),0,sizeof((v)))
 #define CP(v,w) memcpy((v),(w),sizeof((w)))
 #define mp make_pair
 #define oo 1<<30
 
 #define IN "code.in"
 #define OUT "code.out"
 #define N_MAX 1<<12
 
 typedef vector<int> VI;
 typedef pair<int,int> pi;
 typedef vector<string> VS;
 template<class T> string toString(T n) {ostringstream ost;ost<<n;ost.flush();return ost.str();}
 typedef vector<string> VS;
 typedef pair<pi,pi> ppi;
 
 int T;
 vector< pair<pi,pi> > V;
 bool viz[N_MAX];
 vector<VI> A;
 
 II void scan()
 {
 	freopen(IN,"r",stdin);
 	freopen(OUT,"w",stdout);
 	scanf("%d",&T);
 }
 
 II int arie(pi k1,pi k2,pi k3)
 {
 	int rez = k1.f * k2.s + k2.f * k3.s + k3.f * k1.s
 			- k1.s * k2.f - k2.s * k3.f - k3.s * k1.f;
 	if(!rez)
 		return 0;
 	if(rez < 0)
 		return -1;
 	return 1;
 }
 
 II bool intersect(ppi X,ppi Y) 
 {
 	if(!arie(X.f,Y.f,Y.s) || !arie(X.s,Y.f,Y.s) || !arie(Y.f,X.f,X.s) || !arie(Y.s,X.f,X.s) )
 		return false;
 	
 	if(arie(X.f,Y.f,Y.s) == arie(X.s,Y.f,Y.s) )
 		return false;
 	if(arie(Y.f,X.f,X.s) == arie(Y.s,X.f,X.s) )
 		return false;
 	
 	return true;
 }
 
 II int DF(int nod)
 {
 	if(viz[nod])
 		return 0;
 	viz[nod] = true;
 
 	int count = 1;
 	for(VI::iterator it = A[nod].begin();it != A[nod].end();++it)
 		count += DF(*it);
 
 	return count;
 }
 
 II void solve(int TestCase)
 {
 	int N,K;
 	scanf("%d%d",&N,&K);
 	
 	A.clear();
 	A.resize(N * K);
 	V.clear();
 	V.resize(0);
 	V.pb( mp(mp(0,0),mp(0,0)) );
 	CC(viz);
 	
 	FOR(i,1,N)
 	{
 		int y1,y2;
 		
 		scanf("%d",&y1);
 		FOR(j,1,K-1)
 		{
 			scanf("%d",&y2);
 			V.pb( mp( mp(j-1,y1),mp(j,y2) ) );
 			
 			y1 = y2;
 		}
 	}
 	--K;
 	
 	FOR(i,1,N * K)
 	FOR(j,i+1,N * K)
 		if( intersect(V[i],V[j]) )
 		{
 			A[i].pb(j);
 			A[j].pb(i);
 		}
 	
 	int rez = 0;
 	FOR(i,1,N * K)
 		if(!viz[i])
 			rez = max(rez,DF(i) );
 		
 	printf("Case #%d: %d\n",TestCase,rez);
 }
 
 int main()
 {
 	scan();
 	FOR(i,1,T)
 		solve(i);
 	return 0;
 }
