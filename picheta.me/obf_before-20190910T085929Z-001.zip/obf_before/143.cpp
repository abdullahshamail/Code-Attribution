#include <cstdio>
 #include <algorithm>
 
 using namespace std;
 
 const int maxN = 60;
 const double eps = 1e-12;
 
 int N, K;
 double U;
 double P[maxN], M[maxN];
 double ans;
 
 inline double min(double a, double b) {return a < b ? a : b;}
 
 inline double tooSmall(double a) {return a < 1e-9;}
 
 inline double tooLarge(double a) {return 1-a < 1e-6;}
 
 void solveEasy(double p[], int n) {
     while(U > eps) {
         int cnt;
         for(cnt = 1; cnt < n; ++cnt) {
             if(p[cnt] < p[cnt+1]-eps) break;
         }
 
         double hei = min(p[cnt+1]-p[cnt], U/cnt);
         for(int i = 1; i <= cnt; ++i) {
             p[i] += hei;
         }
         U -= cnt*hei;
         if(cnt == n) break;
     }
 
     ans = 1.;
     for(int i = 1; i <= n; ++i) ans *= p[i];
 }
 
 void select(int n, int k, double cur) {
     if(!k) {
         ans += cur; return;
     }
     if(tooSmall(cur * (M[n-k+1]/M[n+1]))) return;
 
     for(int i = n; i >= k; --i) {
         select(i-1, k-1, cur*P[i]);
         if(tooLarge(ans)) return;
         cur *= 1-P[i];
     }
 }
 
 void solveHard() {
     for(int i = N-K, j = K; i && U > eps; --i, ++j) {
         solveEasy(P+i, j);
     }
 
     M[N+1] = 1.;
     for(int i = N; i; --i) M[i] = M[i+1]*P[i];
 
     ans = 0.;
     select(N, K, 1.);
 }
 
 int main() {
     #ifdef RS16
     //freopen("inp.txt", "r", stdin);
     //freopen("out.txt", "w", stdout);
     freopen("C-small-2-attempt2.in", "r", stdin);
     freopen("C-small-2-attempt2.out", "w", stdout);
 #endif // RS16
 
     int T; scanf("%d", &T);
     for(int t = 1; t <= T; ++t) {
         printf("Case #%d: ", t);
 
         scanf("%d%d", &N, &K);
         scanf("%lf", &U);
         for(int i = 1; i <= N; ++i) scanf("%lf", P+i);
 
         sort(P+1, P+N+1); P[N+1] = 1.;
         if(K == N) {
             solveEasy(P, N);
         }
         else {
             solveHard();
         }
         printf("%.12f\n", ans);
     }
 }
 
 
#include <cstdio>
 #include <algorithm>
 
 using namespace std;
 
 const int maxN = 60;
 const double eps = 1e-12;
 
 int N, K;
 double U;
 double P[maxN], M[maxN];
 double ans;
 
 inline double min(double a, double b) {return a < b ? a : b;}
 
 inline double tooSmall(double a) {return a < 1e-9;}
 
 inline double tooLarge(double a) {return 1-a < 1e-6;}
 
 void solveEasy(double p[], int n) {
     while(U > eps) {
         int cnt;
         for(cnt = 1; cnt < n; ++cnt) {
             if(p[cnt] < p[cnt+1]-eps) break;
         }
 
         double hei = min(p[cnt+1]-p[cnt], U/cnt);
         for(int i = 1; i <= cnt; ++i) {
             p[i] += hei;
         }
         U -= cnt*hei;
         if(cnt == n) break;
     }
 
     ans = 1.;
     for(int i = 1; i <= n; ++i) ans *= p[i];
 }
 
 void select(int n, int k, double cur) {
     if(!k) {
         ans += cur; return;
     }
     if(tooSmall(cur * (M[n-k+1]/M[n+1]))) return;
 
     for(int i = n; i >= k; --i) {
         select(i-1, k-1, cur*P[i]);
         if(tooLarge(ans)) return;
         cur *= 1-P[i];
     }
 }
 
 void solveHard() {
     for(int i = N-K, j = K; i && U > eps; --i, ++j) {
         solveEasy(P+i, j);
     }
 
     M[N+1] = 1.;
     for(int i = N; i; --i) M[i] = M[i+1]*P[i];
 
     ans = 0.;
     select(N, K, 1.);
 }
 
 int main() {
     #ifdef RS16
     //freopen("inp.txt", "r", stdin);
     //freopen("out.txt", "w", stdout);
     freopen("C-small-2-attempt2.in", "r", stdin);
     freopen("C-small-2-attempt2.out", "w", stdout);
 #endif // RS16
 
     int T; scanf("%d", &T);
     for(int t = 1; t <= T; ++t) {
         printf("Case #%d: ", t);
 
         scanf("%d%d", &N, &K);
         scanf("%lf", &U);
         for(int i = 1; i <= N; ++i) scanf("%lf", P+i);
 
         sort(P+1, P+N+1); P[N+1] = 1.;
         if(K == N) {
             solveEasy(P, N);
         }
         else {
             solveHard();
         }
         printf("%.12f\n", ans);
     }
 }
 
 
