#include <bits/stdc++.h>
 using namespace std;
 
 typedef complex<int> int_c;
 typedef vector<int_c> quaternion;
 typedef long long ll;
 
 quaternion make(int_c a, int_c b, int_c c, int_c d){
   return quaternion({a, b, c, d});
 }
 
 quaternion operator*(quaternion a, quaternion b){
   return make(
       a[0] * b[0] + a[1] * b[2],
       a[0] * b[1] + a[1] * b[3],
       a[2] * b[0] + a[3] * b[2],
       a[2] * b[1] + a[3] * b[3]);
 }
 
 quaternion operator-(quaternion a){
   return make(-a[0], -a[1], -a[2], -a[3]);
 }
 
 ostream& operator<<(ostream &out, quaternion q){
   for(int_c c : q) out << c << " ";
   out << endl;
   return out;
 }
 
 const quaternion E = make(int_c(1, 0), int_c(0, 0), int_c(0, 0), int_c(1, 0));
 const quaternion I = make(int_c(0, 1), int_c(0, 0), int_c(0, 0), int_c(0, -1));
 const quaternion J = make(int_c(0, 0), int_c(1, 0), int_c(-1, 0), int_c(0, 0));
 const quaternion K = make(int_c(0, 0), int_c(0, 1), int_c(0, 1), int_c(0, 0));
 
 quaternion pow(quaternion q, ll x){
   quaternion res = E;
   x %= 4;
   if(x > 0) res = res * q;
   if(x > 1) res = res * q;
   if(x > 2) res = res * q;
   return res;
 }
 
 const int MAXL = 1000005;
 int T, L, res;
 ll X;
 string _S, S;
 quaternion Q[MAXL];
 
 quaternion get(char c){
   if(c == 'i') return I;
   if(c == 'j') return J;
   if(c == 'k') return K;
   return E;
 }
 
 int main(){
   cin >> T;
   for(int _t = 1; _t <= T; _t++){
     cin >> L >> X >> _S;
     printf("Case #%d: ", _t);
     res = 0;
     quaternion cur = E;
     for(int i = 0; i < X; i++){
       for(int j = 0; j < L; j++){
         cur = cur * get(_S[j]);
         if(res == 0 && cur == I) res += 1;
         if(res == 1 && cur == K) res += 1;
       }
     }
     if(res == 2 && cur == -E) cout << "YES\n";
     else cout << "NO\n";
   }
 }
