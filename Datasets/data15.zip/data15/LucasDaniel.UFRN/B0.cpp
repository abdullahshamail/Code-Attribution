#include <bits/stdc++.h>
 using namespace std;
 #define FOR(i, a, b) for(int i = int(a); i < int(b); ++i)
 #define FORR(i, n) FOR(i, 0, n)
 #define sz(a) int((a).size())
 #define pb push_back
 
 int total[1000005];
 bool compare(int a, int b) {
 	return a > b;
 }
 int main() {
 	int t, d, p;
 	scanf("%d", &t);
 	FOR(k, 1, t+1) {
 		scanf("%d", &d);
 		FORR(i, d) {
 			scanf("%d", &total[i]);
 		}
 		//Ordenou não-decrescente
 		sort(total, total+d, compare);
 		int special, eaten;
 		special = eaten = 0;
 		while(d != 0) {
 			int aux = total[0]/2;
 			if(total[0]&1) aux++;
 			int maior = aux;
 			//Dividiu, vê se é melhor dividir ou não
 			if(d > 1) maior = max(maior, total[1]);
 			if(maior+2 <= total[0]) {
 				total[d++] = total[0]/2;
 				total[0] = aux;
 				special++;
 				sort(total, total+d, compare);
 			}
 			else {
 				eaten++;
 				FORR(i, d) {
 					total[i]--;
 					if(total[i] == 0) {
 						d = i;
 						break;
 					}
 				}
 			}
 			
 		}
 		printf("Case #%d: %d\n", k, special+eaten);
 	}
 }
