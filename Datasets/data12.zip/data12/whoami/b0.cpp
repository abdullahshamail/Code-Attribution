#include <stdio.h>
 #include <algorithm>
 int w,l,n;
 double r[10001],print[10001][2],save[10001];
 bool check[10001];
 void pro(){
 	int i,j;
 	double x,y=0,maxx=0,minx=0,maxy=0;
 	std::sort(r,r+n);
 	maxx=-r[n-1];
 	for(i=n-1;i>=0;i--){
 		if(check[i]) continue;
 		if(y+r[i]>l){
 			y=0;
 			minx=maxx;
 			maxx=minx+2*r[i];
 			y=r[i];
 			print[i][0]=minx+r[i];
 			print[i][1]=0;
 			check[i]=1;
 			if(minx+r[i]>=w)
 				while(1);
 		}
 		else{
 			x=minx;
 			if(minx<0)
 				x=-r[i];
 			y+=r[i];
 			print[i][0]=x+r[i];
 			print[i][1]=y;
 			x+=2*r[i];
 			check[i]=1;
 			for(j=i-1;j>=0;j--){
 				if(check[j]) continue;
 				if(x+2*r[j]<maxx){
 					print[j][0]=x+r[j];
 					print[j][1]=y;
 					check[j]=1;
 					x+=2*r[j];
 				}
 			}
 			y+=r[i];
 		}
 	}
 }
 int main(){
 	int testt,i,test,j;
 	FILE *in,*out;
 	in=fopen("input.txt","r");
 	fscanf(in,"%d",&testt);
 	out=fopen("output.txt","w");
 	for(test=1;test<=testt;test++){
 		fscanf(in,"%d %d %d",&n,&w,&l);
 		for(i=0;i<n;i++){
 			fscanf(in,"%lf",&r[i]);
 			save[i]=r[i];
 		}
 		pro();
 		fprintf(out,"Case #%d:",test);
 		for(i=0;i<n;i++){
 			for(j=0;j<n;j++){
 				if(save[i]==r[j] && check[j]){
 					check[j]=0;
 					fprintf(out," %.0lf %.0lf",print[j][0],print[j][1]);
 					break;
 				}
 			}
 		}
 		fprintf(out,"\n");
 	}
 	fcloseall();
 	return 0;
 }
