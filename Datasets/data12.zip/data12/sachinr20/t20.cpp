#include <iostream>
 #include <fstream>
 #include <stdio.h>
 #include <stdlib.h>
 using namespace std;
 void fillArrays(char* enc, char* dec);
 int main(){
 	char enc[256];
 	char dec[256];
 	for(int i=0; i<256; i++){
 		enc[i] = (char)i;
 		dec[i] = (char)i;
 	}
 	fillArrays(enc, dec);
 	
 	ifstream fi;
 	fi.open("A-small-attempt1.in");
 	
 	ofstream fo;
 	fo.open("out_Asmall1.out");
 	
 	int caseNo = 1;
 	int t = 0;
 	char lineIn[101];
 	char lineOut[101];
 	if(fi.good()){
 		fi.getline(lineIn, 101);
 		t = atoi(lineIn);
 
 		if(t<=0)return 1;
 
 		for(int i=0; i<t; i++){
 			fi.getline(lineIn, 101);
 			cout<<"Linein="<<lineIn<<endl;
 			for(int j=0; j<101; j++){
 				lineOut[j] = dec[(int)lineIn[j]];
 			}
 			
 			fo<<"Case #"<<caseNo<<": "<<lineOut<<endl;
 			caseNo++;
 		
 		}
 		
 		
 	}
 	
 	fi.close();
 	fo.close();
 	
 	
 	return 0;
 }
 
 
 void fillArrays(char* enc, char* dec){
 	if(enc == NULL || dec==NULL)return;
 	char a = ' ';
 	char b = ' ';
 	
 	ifstream fi;
 	fi.open("c.txt");		//"c.txt" contains encoding info
 	while(fi.good()){
 	char c[4];
 	fi.getline(c,4);
 		//while(a==' ' || a=='\n') a = fi.get();
 		//while(b==' ' || a=='\n') b = fi.get();
 		a = c[0]; b=c[2];
 		enc[int(a)] = b;
 		dec[int(b)] = a;
 	}
 	fi.close();
 return;
 }
