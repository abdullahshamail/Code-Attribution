#include <fstream>
 #include <vector>
 #include <map>
 #include <vector>
 #include <list>
 #include <map>
 #include <set>
 #include <deque>
 #include <queue>
 #include <stack>
 #include <bitset>
 #include <algorithm>
 #include <functional>
 #include <numeric>
 #include <utility>
 #include <sstream>
 #include <iostream>
 #include <iomanip>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <cctype>
 #include <string>
 #include <cstring>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <ctime>
 
 #include <assert.h>
 using namespace std;
 
 /*
  * define macros
   */
 //#define TEST 
 //#define DEBUG_OUTPUT
 //#define TRACE_OUTPUT
 
 /*
  * framework functions
  * */
 void solveProblem(ifstream &inputfile, ofstream &outputfile);
 void test();
 
 /* *
  * define limits
  * */
 
 /*
  * define gloab variables
  * */
 //避免重复计算,将中间值用map来保存
 
 /**
  * problem-related functions
  */
 
 /**
  * problem-related test functions
  */
 
 /*
  * argv[1] : input file name
  * argv[2] : output file name
 */
 int main( int argc, char* argv[] )
 {
 
 #ifdef TEST
 	test();
 	return 0;
 #endif
 
 	if( argc != 3 )
 	{
 		cout << "err: no input data file or output data file" << endl;
 		return -1;
 	}
 
 	ifstream inFile( argv[1], ifstream::in );
 	if( !inFile )
 	{
 		cout << "error: input file" << endl;
 		return -1;
 	}
 
 	ofstream outFile( argv[2], ofstream::out|ofstream::trunc );
 	if( !outFile)
 	{
 		cout << "error: output File" << endl;
 		return -1;
 	}
 
 	solveProblem(inFile, outFile);
 	
 	inFile.close();
 	outFile.close();
 
 	return 0;
 }
 
 int nN, nL, nH;
 int check(vector<int>& input)
 {
 	int ans = -1;
 	int endidx = input.size() - 1;
 	for (int i=0; i<input.size()-1; i++)
 	{
 		if (input[endidx] % input[i] != 0)
 		{
 			int ans = 1;
 
 			for (int j=0; j<input.size(); j++)
 			{
 				ans *= input[j];
 				if ((ans > nH) || (ans < nL))
 				{
 #ifdef TRACE_OUTPUT
 					cout << "haha break 1" << endl;
 #endif
 					return -1;
 				}
 			}
 
 			return ans;
 		}
 	}
 
 	//nL to input[endidx]
 	for (int i = nL; i < input[endidx]; i++)
 	{
 		if (i > nH)
 			return false;
 
 		if (input[endidx] % i == 0)
 		{
 			if (find (input.begin(), input.end(), i) == input.end())
 				return i;
 		}
 	}
 
 	for (int i=input[endidx]+1; i<nH+1; i++)
 	{
 		if (i % input[endidx] == 0)
 		{
 				return i;
 		}
 	}
 
 #ifdef TRACE_OUTPUT
 				cout << "haha break 3" << endl;
 #endif
 	return -1;
 }
 
 void solveProblem( ifstream &inputfile, ofstream &outputfile )
 {
 	int nTestCase, nCurCase;
 
 	inputfile >> nTestCase;
 
 	for (nCurCase = 0; nCurCase < nTestCase; nCurCase++)
 	{
 		vector<int> freqs;
 		int ans;
 
 		inputfile >> nN >> nL >> nH;
 		for (int i=0; i<nN; i++)
 		{
 			int tmp;
 			inputfile >> tmp;
 			freqs.push_back(tmp);
 		}
 		sort(freqs.begin(), freqs.end());
 
 #ifdef TRACE_OUTPUT
 		cout << " " << endl;
 		for (int i=0; i<nN; i++)
 		{
 			cout << freqs[i] << " ";
 		}
 		cout << " " << endl;
 #endif
 
 		ans = check(freqs);
 
 		//output the result
 		if (ans == -1)
 			outputfile << "Case #" << nCurCase + 1 << ": " << "NO" << endl;
 		else
 			outputfile << "Case #" << nCurCase + 1 << ": " << ans << endl;
 	}
 }
 
 void test()
 {
 	cout << "--- test start --- "<< endl;
 	cout << "--- test end --- "<< endl;
 }
