#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 int t[1010], diff[1010];
 int gcd(int a, int b)
 {  
     if (a < b) return gcd(b, a);
     if (b == 0) return a;
     else return gcd(b, a % b);
 }
 int main()
 {
     int c, n, i, k, count = 1;
     //printf("%d", (-24)%5);
     //system("pause");
     FILE *finp = fopen("B-small-attempt4.in","r");
 	FILE *foutp = fopen("B.out","w");
 	//scanf("%d", &c);
 	fscanf(finp, "%d", &c);
 	while (c--)
 	{
         //scanf("%d", &n);
         fscanf(finp, "%d", &n);
         for (i = 0; i < n; i++) fscanf(finp, "%d", &t[i]);//scanf("%d", &t[i]);
         for (i = 0; i < n - 1; i++) diff[i] = abs (t[i] - t[i+1]); 
         k = diff[0];
         for (i = 1; i < n - 1; i++) k = gcd(k, diff[i]);
         //if (k == 1 || k == 0) fprintf(foutp, "Case #%d: 0\n", count++);//printf("Case #%d: 0\n", count++);
         fprintf(foutp, "Case #%d: %d\n", count++, ceil(double(t[0])/double(k))*k-t[0]);//printf("Case #%d: %d\n", count++, GCD - t[0]%GCD);
     }
     return 0;
 } 
