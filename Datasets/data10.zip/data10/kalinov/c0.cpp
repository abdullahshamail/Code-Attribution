#include <cstdio>
 #include <cstring>
 
 #define MAX 25
 #define MOD 100003
 
 int memo[MAX+1][MAX+1][MAX+1];
 
 int rec( int next, int must, int size ) {
    if( size == 0 ) return must == 1;
    if( next == 1 ) return 0;
    if( next == must ) return rec( next-1, size, size-1 );
 
    int &ret = memo[next][must][size];
    if( ret >= 0 ) return ret;
 
    ret = rec( next-1, must, size ) + rec( next-1, must, size-1 );
    if( ret >= MOD ) ret -= MOD;
    
    return ret;
 }
 
 int main( void ) {
    memset( memo, -1, sizeof memo );
 
    int T;
    scanf( "%d", &T );
    for( int tt = 1; tt <= T; ++tt ) {
       int n;
       scanf( "%d", &n );
       int ret = 0;
       for( int size = 1; size <= n-1; ++size ) {
          ret += rec( n, n, size );
          if( ret >= MOD ) ret -= MOD;
       }
       printf( "Case #%d: %d\n", tt, ret );
    }
 
    return 0;
 }
