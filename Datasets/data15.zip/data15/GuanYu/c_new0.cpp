#include <cstdio>
 #define MAXS 10002
 #define I 0
 #define J 1
 #define K 2
 #define O 3
 #define NI 4
 #define NJ 5
 #define NK 6
 #define NO 7
 using namespace std;
 typedef long long int llint;
 
 // String
 char str[MAXS];
 
 // Left & Right
 int left[MAXS], right[MAXS];
 
 // Mapping
 int mp(char ch)
 {
 	switch(ch)
 	{
 		case 'i': return I; break;
 		case 'j': return J; break;
 		case 'k': return K; break;
 	}
 	return -1;
 }
 
 // Operation
 int op[10][10];
 
 // I, K-positions
 int posi[4][MAXS], posic[4];
 int posk[4][MAXS], poskc[4];
 
 // Main
 int main(void)
 {
 	int tc, cs, now, tmp, i, j, rpl, rpr, shiftL, shiftR, MID;
 	bool OK;
 	llint len, X, siz;
 
 	// Pre-processing
 	op[O][O]=O, op[O][I]=I, op[O][J]=J, op[O][K]=K;
 	op[I][O]=I, op[I][I]=NO, op[I][J]=K, op[I][K]=NJ;
 	op[J][O]=J, op[J][I]=NK, op[J][J]=NO, op[J][K]=I;
 	op[K][O]=K, op[K][I]=J, op[K][J]=NI, op[K][K]=NO;
 
 	// Read Input
 	scanf("%d",&tc);
 	for(cs=1;cs<=tc;cs++)
 	{
 		scanf("%lld%lld",&len,&X);
 		scanf("%s",str);
 		printf("Case #%d: ", cs);
 
 		// Impossible
 		if(len*X<3) puts("NO");
 		else
 		{
 			// Left
 			left[0]=mp(str[0]);
 			now=left[0];
 			for(i=1;i<len;i++)
 			{
 				tmp=mp(str[i]);
 				if(now>=4)
 				{
 					now=op[now-4][tmp];
 					now=(now+4)%8;
 				}
 				else now=op[now][tmp];
 				left[i]=now;
 			}
 
 			// Recording I's positions
 			shiftL=O;
 			for(i=0;i<4;i++)
 			{
 				posic[i]=0;
 				for(j=0;j<len;j++)
 				{
 					// Positive
 					if((shiftL>=4&&left[j]>=4)||(shiftL<4&&left[j]<4))
 					{
 						tmp=op[shiftL%4][left[j]%4];
 					}
 					// Negative
 					else
 					{
 						tmp=op[shiftL%4][left[j]%4];
 						tmp=(tmp+4)%8;
 					}
 					if(tmp==I) posi[i][posic[i]++]=j;
 				}
 				tmp=op[shiftL%4][left[len-1]%4];
 				if((left[len-1]>=4&&shiftL<4)||(left[len-1]<4&&shiftL>=4)) tmp=(tmp+4)%8;
 				shiftL=tmp;
 			}
 
 			// Right
 			right[len-1]=mp(str[len-1]);
 			now=right[len-1];
 			for(i=len-2;i>=0;i--)
 			{
 				tmp=mp(str[i]);
 				if(now>=4)
 				{
 					now=op[tmp][now-4];
 					now=(now+4)%8;
 				}
 				else now=op[tmp][now];
 				right[i]=now;
 			}
 
 			// Recording K's positions
 			shiftR=O;
 			for(i=0;i<4;i++)
 			{
 				poskc[i]=0;
 				for(j=len-1;j>=0;j--)
 				{
 					// Positive
 					if((right[j]>=4&&shiftR>=4)||(right[j]<4&&shiftR<4))
 					{
 						tmp=op[right[j]%4][shiftR%4];
 					}
 					// Negative
 					else
 					{
 						tmp=op[right[j]%4][shiftR%4];
 						tmp=(tmp+4)%8;
 					}
 					if(tmp==K) posk[i][poskc[i]++]=j;
 				}
 				tmp=op[right[0]%4][shiftR%4];
 				if((right[0]>=4&&shiftR<4)||(right[0]<4&&shiftR>=4)) tmp=(tmp+4)%8;
 				shiftR=tmp;
 			}
 
 			// Check
 			OK=false;
 			for(rpl=0;rpl<X&&rpl<4;rpl++)
 			{
 				for(i=0;i<posic[rpl];i++)
 				{
 					for(rpr=0;rpr<X&&rpr<4&&rpl+rpr<X;rpr++)
 					{
 						// overlapping part
 						if(rpl+rpr==X-1)
 						{
 							for(j=0;j<poskc[rpr]&&posk[rpr][j]>posi[rpl][i]+1;j++)
 							{
 								now=right[posi[rpl][i]+1];
 								tmp=right[posk[rpr][j]];
 								// Positive
 								if((now>=4&&tmp>=4)||(now<4&&tmp<4))
 								{
 									now=now%4;
 									tmp=tmp%4;
 									now=op[now][tmp];
 									now=(now+4)%8;
 								}
 								// Negative
 								else
 								{
 									now=now%4;
 									tmp=tmp%4;
 									now=op[now][tmp];
 								}
 								if(now==J)
 								{
 									OK=true;
 									break;
 								}
 							}
 						}
 						// Non-overlapping
 						else
 						{
 							MID=O;
 							siz=(X-(rpl+rpr)-2)%4;
 							for(j=0;j<siz;j++)
 							{
 								tmp=op[MID%4][left[len-1]%4];
 								if((MID>=4&&left[len-1]<4)||(MID<4&&left[len-1]>=4)) tmp=(tmp+4)%8;
 								MID=tmp;
 							}
 							for(j=0;j<poskc[rpr];j++)
 							{
 								if(posi[rpl][i]+1<len)
 								{
 									tmp=op[right[posi[rpl][i]+1]%4][MID%4];
 									if((right[posi[rpl][i]+1]>=4&&MID<4)
 										||(right[posi[rpl][i]+1]<4&&MID>=4))
 										tmp=(tmp+4)%8;
 								}
 								else tmp=MID;
 								if(posk[rpr][j]-1>=0)
 								{
 									now=op[tmp%4][left[posk[rpr][j]-1]%4];
 									if((tmp>=4&&left[posk[rpr][j]-1]<4)
 										||(tmp<4&&left[posk[rpr][j]-1]>=4))
 										now=(now+4)%8;
 								}
 								else now=tmp;
 								if(now==J)
 								{
 									OK=true;
 									break;
 								}
 							}
 						}
 						if(OK) break;
 					}
 					if(OK) break;
 				}
 				if(OK) break;
 			}
 
 			// Output
 			if(OK) puts("YES");
 			else puts("NO");
 		}
 	}
 	return 0;
 }