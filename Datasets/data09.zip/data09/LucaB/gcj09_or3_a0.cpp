#include <iostream>
 #include <fstream>
 #include <vector>
 #include <algorithm>
 #include <limits.h>
 #include <cstring>
 using namespace std;
 
 ifstream in;
 ofstream out;
 
 int R, C;
 
 char board[256];
 
 typedef unsigned pos_t;
 
 unsigned char start[8];
 int nstart;
 unsigned char goal[8];
 int ngoal = 0;
 
 pos_t startv;
 pos_t goalv;
 
 int moves[4] = {-1, 1, -16, 16};
 
 int mem[256 * 256];
 
 #define STABLE (1 << 31)
 
 int is_stable(pos_t p)
 {
 	int delta = ((p >> 8) & 0xff) - (p & 0xff);
 	if(delta == 1 || delta == -1 || delta == -16 || delta == 16)
 		return 1;
 	else
 		return 0;
 }
 
 int go(pos_t p)
 {
 	int res = mem[p];
 	if(res >= 0)
 		return res;
 
 	mem[p] = INT_MAX;
 
 	res = INT_MAX;
 
 	if(p == goalv)
 		res = 0;
 	else
 	{
 		int s = is_stable(p);
 
 		for(int i = 0; i < nstart; ++i)
 		{
 			unsigned v = (p >> (i * 8)) & 0xff;
 			for(int j = 0; j < 4; ++j)
 			{
 				unsigned n = v + moves[j];
 				if(!board[n])
 					continue;
 
 				//cout << v << ' ' << n << endl;
 				pos_t p2 = (p & ~(0xff << (i * 8))) | (n << (i * 8));
 				if(!s && !is_stable(p2))
 					continue;
 
 				sort((char*)&p2, (char*)&p2 + nstart);
 				res = min(res, go(p2));
 			}
 		}
 		if(res < INT_MAX)
 			++res;
 	}
 	mem[p] = res;
 	return res;
 }
 
 int main(int argc, char** argv)
 {
         in.open(argv[1]);
         out.open(argv[2]);
 
         int T;
         in >> T;
 
         for(int test = 1; test <= T; ++test)
         {
         	in >> R >> C;
         	memset(board, 0, sizeof(board));
         	memset(start, 0, sizeof(start));
         	memset(goal, 0, sizeof(goal));
         	memset(mem, 0xff, sizeof(mem));
         	nstart = 0;
         	ngoal = 0;
         	for(int r = 0; r < R; ++r)
         	{
         		string s;
         		in >> s;
         		for(int c = 0; c < C; ++c)
         		{
         			board[((r + 1) << 4) | (c + 1)] = s[c] != '#';
         			if(s[c] == 'o' || s[c] == 'w')
         				start[nstart++] = ((r + 1) << 4) | (c + 1);
         			if(s[c] == 'x' || s[c] == 'w')
         				goal[ngoal++] = ((r + 1) << 4) | (c + 1);
         		}
         	}
         	sort(start, start + nstart);
         	sort(goal, goal + nstart);
         	startv = *(pos_t*)start;
         	goalv = *(pos_t*)goal;
 
         	cout << (int)start[0] << ' ' << (int)start[1] << ' ' << nstart << ' ' << startv << endl;
 
         	int res = go(startv);
         	if(res == INT_MAX)
         		res = -1;
 
         	out << "Case #" << test << ": " << res << endl;
         }
         return 0;
 }
