#include<stdio.h>
 #include<string.h>
 #include <cassert>
 #include <cctype>
 #include <climits>
 #include <cmath>
 #include <cstdio>
 #include <cstdlib>
 #include <cstring>
 #include <iostream>
 #include <sstream>
 #include <iomanip>
 #include <string>
 #include <vector>
 #include <list>
 
 #define CLR(p) memset(p, 0, sizeof(p))
 
 int main(){
 // freopen("input.cpp","r",stdin);
 // freopen("output.txt","w",stdout);
 
     char ch[10005];
     int mat[4][4]= {{1, 105, 106, 107},{105, -1, 107, -106},{106, -107, -1, 105},{107, 106, -105, -1}};
     int a, b, k=0, flag_i=0, flag_j=0, flag_k=0, c, t, l, n, count=0;
     scanf("%d", &t);
     for(int k=1; k<=t; k++){
         CLR(ch);
         scanf("%d %d", &l, &n);
         scanf("%s", ch);
         c= (int)ch[0];
         a= (int)ch[0];
         for(int i=1; i<strlen(ch)*n; i++){
                 a= c-104;
                 b= (int)ch[i%strlen(ch)]-104;
 
                 if(ch[0] == 105 && flag_i==0){
                     flag_i=1;
                     c= 104;
                     a=0;
                 }
                 if(mat[a][b] == 105 || mat[a][b] == -105){
                     if(mat[a][b]<0)
                         count++;
                     c= 105;
                 if(flag_i ==0 && count%2==0){
                     flag_i=1;
                     c= 104;
                 }
                 }else if(mat[a][b] == 106 || mat[a][b] == -106){
                     if(mat[a][b]<0)
                         count++;
                     c= 106;
                 if(flag_i ==1 && flag_j==0 && count%2==0){
                     flag_j=1;
                         c= 104;
                 }
                 }else if(mat[a][b] == 107 || mat[a][b] == -107){
                     if(mat[a][b]<0)
                         count++;
                     c= 107;
                 if(flag_j ==1 && flag_k==0 && count%2==0 && i%strlen(ch)== strlen(ch)-1){
                     flag_k=1;
                 }
                 }else if(mat[a][b] == 1 || mat[a][b] == -1){
                     if(mat[a][b]<0)
                         count++;
                     c= 104;
                 }
 
             }
         if(flag_i == 1 && flag_j == 1 && flag_k == 1 && count%2==0)
             printf("Case #%d: YES\n", k);
         else
             printf("Case #%d: NO\n", k);
         flag_i=0; flag_j=0; flag_k=0; count=0;
     }
     return 0;
 }
