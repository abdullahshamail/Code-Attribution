#include <algorithm>
 #include <iostream>
 #include <sstream>
 #include <string>
 #include <vector>
 #include <queue>
 #include <set>
 #include <map>
 #include <cstdio>
 #include <cstdlib>
 #include <cctype>
 #include <cmath>
 #include <numeric>
 
 using namespace std;
 
 template< typename type > type readOne()
 {
     type res;
     char inp[5000];
     gets( inp );
     stringstream ss( inp );
     ss >> res;
     return res;
 }
 
 template< typename type > vector<type> readMulti()
 {
     vector<type> res;
     char inp[500000];
     gets( inp );
     stringstream ss( inp );
     for ( type t; ss >> t; ) res.push_back( t );
     return res;
 }
 
 int doCase(){
     // vector<int> item  = readMulti<int>();
     vector<string> item2  = readMulti<string>();
     for(int i = 0; i < item2.size(); i++) 
         cout << item2[i];
     cout << endl;
     return 0;
 }
 
 int gcd(int x, int y) {
 
     if (y == 0) return x;
     else        return gcd(y, x % y);
 }
 
 int soinsu( vector<int> num ){
 
     int ret = 1;
     
     /* divided by 2 */
     int flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 2 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 2;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 2;
 	}
     }
 
     /* divided by 3 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 3 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 3;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 3;
 	}
     }
 
     /* divided by 5 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 5 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 5;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 5;
 	}
     }
 
     /* divided by 7 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 7 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 7;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 7;
 	}
     }
 
     /* divided by 11 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 11 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 11;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 11;
 	}
     }
 
     /* divided by 13 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 13 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 13;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 13;
 	}
     }
 
     /* divided by 17 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 17 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 17;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 17;
 	}
     }
 
     /* divided by 19 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 19 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 19;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 19;
 	}
     }
 
     /* divided by 23 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 23 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 23;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 23;
 	}
     }
 
     /* divided by 29 */
     flag = 0;
     while( 1 ){
 	for( int i = 0; i < num.size(); i++ ){
 	    if( num[i] % 29 != 0 ) flag = 1;
 	}
 	if( flag == 1 ) break;
 	ret *= 29;
 	for( int i = 0; i < num.size(); i++ ){
 	    num[i] /= 29;
 	}
     }
 
     return ret;
 }
 
 int doit( vector<int> event ){
 
     vector <int> tmp;
     for( int i = 0; i < event.size(); i++ ){
 	for( int j = i + 1; j < event.size(); j++ ){
 	    tmp.push_back( abs(event[i] - event[j] ) );
 	}
     }
 
     int min = (1<<29);
     if( tmp.size() < 2 ) {
 	min = tmp[0];
     } else {
 	for( int i = 0; i < tmp.size(); i++ ){
 	    for( int j = i + 1; j < tmp.size(); j++ ){
 		int foo = gcd( tmp[i], tmp[j] );
 		if( min > foo ) min = foo;
 	    }
 	}
     }
 
     int min_event = (1<<29);
 
     for( int i = 0; i < event.size(); i++ ){
 	if( min_event > event[i] ) min_event = event[i];
     }
 
     int foo = 0;
     while( 1 ){
 	foo += min;
 	if( foo > min_event ) break;
     }
 
     /*
     printf( "min = %d, ans = %d\n", min, (event[0] / min + 1) * min - event[0] );
     */
 
     return foo - min_event;
 
 #if 0
 
     int base = 1;
     vector <int> tmp = event;
 
     while( 1 ){
 
 	int min_y = (1<<29);
 	int prev_base = base;
 	for( int i = 0; i < tmp.size(); i++ ){
 	    min_y = min( min_y, tmp[i] );
 	}
 
 	int cnt = 0;
 	for( int i = 0; i < min_y; i++ ){
 	    vector <int> tmptmp;
 	    for( int j = 0; j < tmp.size(); j++ ){
 		tmptmp.push_back( tmp[j] + i );
 	    }
 	    int tmp_base = soinsu( tmptmp );
 	    //printf("tmp_base: %d\n", tmp_base);
 
 	
 	    /*
 	      for( int j = 0; j < tmp.size(); j++ ){
 		printf("tmp: %d, i: %d, tmp_base: %d, min_y: %d\n", tmp[j], i, tmp_base, min_y );
 	    }
 	    */
 	    
 	    
 	    if( tmp_base != 1 ){
 		for( int j = 0; j < tmp.size(); j++ ){
 		    tmp[j] = tmptmp[j] / tmp_base;
 		}
 		base *= tmp_base;
 		break;
 	    }
 	    cnt++;
 	    //if( cnt > (1<<16) ) break;
 	}
 
 	printf("base: %d\n", base );
 	
 	
 	for( int j = 0; j < tmp.size(); j++ ){
 	    printf("tmp: %d, ", tmp[j] );
 	}
 	printf("\n");
 	      
 	
 	if( prev_base == base ) break;
     }
 
     //printf(" base: %d, tmp: %d\n", base, tmp[0] );
 
     return base * tmp[0] - event[0];
 #endif
 
 }
 
 long long stringToInt( string s ){
 
     long long ret = 0;
     long long base = 1;
 
     for( int i = s.length() - 1; i >= 0; i-- ){
 	ret += (s[i] - '0') * base;
 	//cout << ret << endl;
 	base*=10;
     }
     
     return ret;
 }
 
 
 int main()
 {
     int cases = readOne<int>(); // cases
     for (int caseno = 1; caseno <= cases; caseno++){
 	vector<int> line = readMulti<int>();
 	vector<int> data;
 	set <int> s;
 	for( int i = 1; i < line.size(); i++ ){
 	    //data.push_back( line[i] );
 	    s.insert( line[i] );
 	}
 	set<int>::iterator it = s.begin();
 	while( it != s.end() ) {
 	    data.push_back( *it );
 	    ++it;
 	}
         cout << "Case #" << caseno << ": " << doit( data ) << endl; // call doCase()
     }
     return 0;
 }
