#include<algorithm>
 #include<cstdio>
 using namespace std;
 const int L=100000,inf=1000000000;
 
 int dp[L];
 
 void dfs()
 {
     
     
 }
 
 main()
 {
     int i,j,k,n,m,T;
     int num[1000];
     for(scanf("%d",&T);T--;)
     {
         scanf("%d %d",&m,&n);
         for(i=0;i<L;i++)
             dp[i]=inf;
 
         for(i=0;i<n;i++)
         {
             scanf("%d",&num[i]);
             dp[num[i]]=1;
         }
         for(i=1;i<L;i++)
         {
             if(dp[i]==inf)
                 for(j=0;j<n;j++)
                     if(i-num[j]>=0)
                         dp[i]<?=dp[i-num[j]]+1;
         }
         for(i=0;i<100;i++)
             printf("(%d,%d)\n",i,dp[i]);
         
     }
 }
 /*
 9
 100 3
 3 9 5
 
 */
