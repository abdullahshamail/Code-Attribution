#include <iostream>
 #include <fstream>
 #include <string>
 #include <vector>
 
 using namespace std;
 
 static const string inFileName("A-small-attempt2.in");
 static const string outFileName("A-small-attempt2.out");
 
 int main()
 {
 	fstream inFileStream(inFileName.c_str(),ios_base::in);
 	string strline;
 
 	getline(inFileStream, strline);
 	int caseNum = atoi(strline.c_str());
 	strline.clear();
 
 	vector<int> switchNum(caseNum);
 
 	for ( int caseCount=0; caseCount < caseNum; caseCount++)
 	{
 		switchNum[caseCount] = 0;
 		//engineName search enginesname
 
 		getline(inFileStream,strline);
 		int searchEngineNum = atoi(strline.c_str());
 		strline.clear();
 		
 		//ֵ
 		vector<string> engineName(searchEngineNum);
 		//ű־λ
 		//bitset< searchEngineNum> flag(0);
 		vector<bool> flag( searchEngineNum);
 		
 		//ʼͱ־λ
 		for (int i=0; i< searchEngineNum; i++ )
 		{
 			getline(inFileStream, strline);
 			engineName[i] = strline;
 			flag[i] = 0;
 			strline.clear();
 		}
 		//ʣµļqueryɨ
 		//query
 		getline(inFileStream, strline);
 		int queryNum = atoi(strline.c_str());
 		strline.clear();
 
 		int matchCount = 0;
 		//ÿһ
 		for (int i=0; i<queryNum; i++)
 		{
 			getline(inFileStream, strline);
 			//queryengineNameÿԱȣֱҵͬ
 			for (int j=0; j<searchEngineNum; j++)
 			{
 				//ҵͬengineʱ
 				if (engineName[j] == strline)
 				{
 					//ȼmatch֮ǰǷ⵽ûм⵽˵match
 					if ( flag[j] == 0)
 					{
 						//ҵengineСܵengineʱҪswitch־λĶ
 						if ( matchCount < searchEngineNum-1)
 						{
 							flag[j] = 1;
 							matchCount++;
 						//	break;
 						}
 						else //ƥengineѾܵengineҪswitch
 							//swith֮ǰõһƥengineһƥqueryʱswith
 						{
 							switchNum[caseCount]++;
 							for (int k=0;k<searchEngineNum;k++)
 								flag[k] = 0;
 							//һֵҵһmatchswitch֮ĵһmatch
 							flag[j] = 1;
 							matchCount = 1;
 						//	break;
 						}
 					} 
 				//  else matchѾǰҵ
 				//  һquery matchengineҵ󣬾ͲҪѭmatch
 					break;
 				}// else ûҵmatchѭҡ
 			}
 		}
 	}
 	inFileStream.close();
 	fstream outFileStream(outFileName.c_str(), ios_base::out);
 	for (int i=0;i< caseNum;i++)
 		outFileStream << "Case #" << i+1 <<": " << switchNum[i] << endl;
 	outFileStream.close();
 }