// CandySpilit.cpp : Defines the entry point for the console application.
 //
 
 #include "stdafx.h"
 #include "math.h"
 #include <vector>
 
 
 int XORAdd(int x, int y)
 {
 	int iSum = 0;
 
 	int iPos = 0;
 
 	while(1)
 	{
 		int iBit = x%2  ^ y%2;
 
 		iSum = iSum + iBit * (pow(2.0, iPos));
 		iPos++;
 
 		x = x/2;
 		y = y/2;
 
 		if(( x == 0) && ( y == 0))
 		{
 			break;
 		}
 	}
 
 	return iSum;
 }
 
 int patricAdd(std::vector<int>pile)
 {
 	int iSum = pile.front();
 
 	for(int i = 1; i < pile.size(); i++)
 	{
 		int iAdd = pile.at(i);
 
 		iSum = XORAdd(iSum, iAdd);
 	}
 
 	return iSum;
 
 }
 
 
 
 int AddNormal(std::vector<int>pile)
 {
 	int iSum = pile.front();
 
 	for(int i = 1; i < pile.size(); i++)
 	{
 		int iAdd = pile.at(i);
 
 		iSum = iSum + iAdd;
 	}
 
 	return iSum;
 
 }
 
 
 FILE *in = fopen( "input.txt" , "r" );
 FILE *out = fopen( "output.txt" , "w" );
 
 int _tmain(int argc, _TCHAR* argv[])
 {
 	std::vector<int>sean;
 	std::vector<int>patrick;
 	std::vector<int>input;
 
 	int TestCase;
 	fscanf(in, "%d", &TestCase);
 
 	for(int T = 0; T < TestCase; T++)
 	{
 
 		input.clear();
 		int N;
 
 		fscanf(in, "%d", &N); 
 
 
 		for(int i = 0; i < N ; i++)
 		{
 			int element;
 			fscanf(in, "%d", &element); 
 			input.push_back(element);
 
 		}
  
 
 		int MaxSean = 0;
 
 		for(int i = 1 ; i < pow(2.0, N) -1 ; i++)
 		{ 
 			int TargetNum = i;
 
 
 
 			for(int j = 0; j < N; j++)
 			{
 				if(TargetNum%2 == 0)
 				{
 					sean.push_back(input.at(j)); /// 0 
 				}else
 				{
 					patrick.push_back(input.at(j)); ///1
 				}
 
 				TargetNum = TargetNum/2;
 
 			}
 
 
 
 			if(patricAdd(sean) == patricAdd(patrick))
 			{
 				if(AddNormal(sean) > MaxSean)
 				{
 					MaxSean = AddNormal(sean);
 				}
 
 			}
 
 
 
 
 			sean.clear();
 			patrick.clear();
 
 
 		} 
 
 
 		int Answer = MaxSean;
 		if(Answer == 0)
 		fprintf(out, "Case #%d: NO\r\n", T+1, Answer);
 		else
 		fprintf(out, "Case #%d: %d\r\n", T+1, Answer);
 	}
 
 	fclose(in);
 	fclose(out);
 	return 0;
 }
