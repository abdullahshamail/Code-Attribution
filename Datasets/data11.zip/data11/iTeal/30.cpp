#include <iostream>
 
 using namespace std;
 
 int phash[10000] = {0};
 int prime[1000];
 int pcount = 0;
 
 int main (int argc, char const *argv[])
 {
 	int current = 2;
 	phash[0] = phash[1] = phash[2] = 1;
 	while (current < 1000) {
 		prime[pcount++] = current;
 		for(int i = 1; i * current < 1000; i++) {
 			phash[i*current] = 1;
 		}
 		while (current < 1000 && phash[current]) current++;
 	}
 	int t;
 	cin >> t;
 	for(int index = 1; index <= t; index++) {
 		int hash[1000] = {0};
 		int n;
 		cin >> n;
 		if (n == 1) {
 			cout << "Case #" << index << ": " << 0 << endl;
 			continue;
 		}
 		int min = 0;
 		int max = 1;
 		for(int i = 1; i <= n; i++) {
 			int x = i;
 			int count = 0;
 			int current = 0;
 			int flag = 0;
 			while (x != 1) {
 				if (x%prime[current] == 0) {
 					count++;
 					x /= prime[current];
 				} else {
 					if (hash[current] < count) {
 						flag = 1;
 						hash[current] = count;
 					}
 					current ++;
 					count = 0;
 				}
 			}
 			if (hash[current] < count) {
 				flag = 1;
 				hash[current] = count;
 			}
 			if (flag) max++;
 		}
 		
 		memset(hash,0,sizeof(hash));
 		for(int i = 0; prime[i] <= n && i < pcount; i++) {
 			min++;
 		}
 		cout << "Case #" << index << ": " << max - min << endl;
 	}
 	return 0;
 }