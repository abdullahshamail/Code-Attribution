#include<bits/stdc++.h>
 using namespace std;
 int main()
 {
     FILE *fr=fopen("B-small-attempt1.in","r");
     FILE *fw=fopen("Output.txt","w");
     int tc,n,i;
     fscanf(fr,"%d",&tc);
     int ctr=1;
     while(tc--)
     {
         int arr[100005];
         fscanf(fr,"%d",&n);
         for(i=0;i<n;i++)
            fscanf(fr,"%d",&arr[i]);
         int ans=1000,sec=0;
         while(sec<ans)
         {
             priority_queue<int > q;
             for(i=0;i<n;i++)
                 q.push(arr[i]);
             for(int j=1;j<=sec;j++)
             {
                 int a=q.top(); q.pop();
                 int b=a/2;
                 if(a&1) b++;
                 q.push(b);q.push(a/2);
                 //cout<<sec<<q.top()<<endl;
 
             }
             ans=min(ans,sec+q.top());
             sec++;
         }
         fprintf(fw,"Case #%d: %d\n",ctr++,ans);
 
     }
 
     return 0;
 }
