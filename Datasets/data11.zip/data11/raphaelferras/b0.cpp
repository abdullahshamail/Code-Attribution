#include <cstdio>
 #include <cstdlib>
 #include <string>
 #include <cstring>
 
 using namespace std;
 
     int hand[100][3];
     int usado[100];
     int deck[100][3];
     int i,j,k,t,tur,m,n;
     long long s,maxx;
 
 void vai(){
     int kk;
     if(tur){
     for( i = 0 ; i < n; i++){
         if( !usado[i]){
             tur--;
             usado[i] = 1;
             s+=hand[i][1];
             if( s > maxx ) maxx = s;
             tur+=hand[i][2];
             kk = n;
             for( int x =  0; x < hand[i][0] && n != m; x++ ){
                 n++;
             }
             vai();
             
             n = kk;
             tur-=hand[i][2];
             s-=hand[i][1];            
             usado[i] = 0;
             tur++;
         }
     }
     }
 }
 
 int main(){
 
     scanf("%d", &t);
     
     for( k =1; k <=t; k++){
         scanf("%d", &n);
         for( i =0; i <n; i++){
             scanf("%d %d %d", &hand[i][0], &hand[i][1], &hand[i][2]);
         }
         scanf("%d", &m);
         for( i =0; i <m; i++){
             scanf("%d %d %d", &hand[n+i][0], &hand[n+i][1], &hand[n+i][2]);
         }
         m+=n;
         maxx = s = 0;
         tur = 1;
         memset(usado,0,sizeof(usado));
         vai();
 
 
         
         printf("Case #%d: %lld\n", k , maxx);
     }
 }
