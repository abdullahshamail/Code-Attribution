#include <iostream>
 #include <vector>
 
 using namespace std;
 
 unsigned computeBestResult( vector< unsigned > vectPoints, unsigned numOfSurprises, unsigned minExpectedScore )
 {
 
   //Compute for 'NotSuprises' !!
   vector< vector< unsigned > > notSuprises;
   for( unsigned k = 0; k < vectPoints.size(); ++k ) {
     unsigned point = vectPoints[ k ];
     vector< unsigned > tempVect;tempVect.clear();
     if( point % 3 == 0 ) {
       tempVect.push_back( point / 3 );
       tempVect.push_back( point / 3 );
       tempVect.push_back( point / 3 );
     }else if( point - 2 >=0 && ( point - 2 ) % 3 == 0 ){
       tempVect.push_back( ( point - 2 ) / 3 );
       tempVect.push_back( ( ( point - 2 ) / 3 ) + 1 );
       tempVect.push_back( ( ( point - 2 ) / 3 ) + 1 );
     }
     else if( point - 1 >=0 && ( point - 1 ) % 3 == 0 ){
       tempVect.push_back( ( point - 1 ) / 3 );
       tempVect.push_back( ( point - 1 ) / 3  );
       tempVect.push_back( ( ( point - 1 ) / 3 ) + 1 );
     }
     notSuprises.push_back( tempVect );
   }//for( k );
 
   unsigned numNS( 0 );
   vector< unsigned > indexNotSuprisesWithMinExp;
   for( unsigned k = 0; k < notSuprises.size(); ++k ) {
     bool status = false;
     for( unsigned m = 0; m < notSuprises[ k ].size(); ++m ) {
       if( notSuprises[ k ][ m ] >= minExpectedScore ) {
         indexNotSuprisesWithMinExp.push_back( k );
         status = true;
         numNS++;
         break;
       }
     }
     if( ! status )
       indexNotSuprisesWithMinExp.push_back( 5 );
   }
 
   cout<<"----------------------"<<endl;
 
   //Compute for 'Suprises' !!
   vector< vector< unsigned > > suprises;
   for( unsigned k = 0; k < vectPoints.size(); ++k ) {
     unsigned point = vectPoints[ k ];
     if( point == 0 ) continue;
     vector< unsigned > tempVect;tempVect.clear();
     if( point - 4 >= 0 && ( point - 4 ) % 3  == 0 ) {
       tempVect.push_back( ( point - 4 ) / 3  );
       tempVect.push_back( ( point - 4 ) / 3 + 2 );
       tempVect.push_back( ( point - 4 ) / 3 + 2 );
     }else if( point - 2 >= 0 && ( point - 2 ) % 3 == 0 ) {
       tempVect.push_back( ( point - 2 ) / 3 );
       tempVect.push_back( ( point - 2 ) / 3 );
       tempVect.push_back( ( point - 2 ) / 3 + 2 );
     }else if( point - 3 >= 0 && ( point - 3 ) % 3 == 0 ) {
       tempVect.push_back( ( point - 3 ) / 3 );
       tempVect.push_back( ( point - 3 ) / 3 + 1 );
       tempVect.push_back( ( point - 3 ) / 3 + 2 );
     }
     if( tempVect.size() >= 0 )suprises.push_back( tempVect );
   }//for( k );
 
   unsigned numS( 0 );
   vector< unsigned > indexSuprisesWithMinExp;
   for( unsigned k = 0; k < suprises.size(); ++k ) {
     bool status = false;
     for( unsigned m = 0; m < suprises[ k ].size(); ++m ) {
       if( suprises[ k ][ m ] >= minExpectedScore ) {
         indexSuprisesWithMinExp.push_back( k );
         status = true;
         numS++;
         break;
       }
     }
     if( ! status )
       indexSuprisesWithMinExp.push_back( 5 );
   }
 
   unsigned totalNumDancers = vectPoints.size();
 
   if( totalNumDancers == 1 ) 
   {
     if( numOfSurprises == 0 ) {
       return numNS;
     }
     if( numOfSurprises == 1 ) {
       if( numS ) return 1;
       else return 0;
     }
   }
   else if( totalNumDancers == 2 ) 
   {
     if( numOfSurprises == 0 ) {
       return numNS;
     }
     else if( numOfSurprises == 1 ) {
       unsigned max = 0;
       unsigned kount = 0;
       if( indexSuprisesWithMinExp.size() >= 1 && indexSuprisesWithMinExp[0] == 0 ) {
         ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 2 && indexNotSuprisesWithMinExp[1] == 1 )
         ++kount;
         max = ( max < kount ) ? kount: max;
       }
       kount = 0;
       if( indexSuprisesWithMinExp.size() >= 2 && indexSuprisesWithMinExp[1] == 1 ) {
         ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 1 && indexNotSuprisesWithMinExp[0] == 0 )
         ++kount;
         max = ( max < kount ) ? kount: max;
       }
       return ( ( max >= numOfSurprises ) ? max: 0 );
     }else if( numOfSurprises == 2 ) {
       if( numS == 2 ) return 2;
       else return 0;
     }
   }else if( totalNumDancers == 3 ) 
   {
     if( numOfSurprises == 0 ) {
       return numNS;
     }
     else if( numOfSurprises == 1 ) {
 
       unsigned max = 0;
       unsigned kount = 0;
       if( indexSuprisesWithMinExp.size() >= 1 && indexSuprisesWithMinExp[0] == 0 ) {
         ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 2 && indexNotSuprisesWithMinExp[1] == 1 )
           ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 3 && indexNotSuprisesWithMinExp[2] == 2 )
           ++kount;
         max = ( max < kount ) ? kount: max;
       }
       kount = 0;
       if( indexSuprisesWithMinExp.size() >= 2 && indexSuprisesWithMinExp[1] == 1 ) {
         ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 1 && indexNotSuprisesWithMinExp[0] == 0 )
           ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 3 && indexNotSuprisesWithMinExp[2] == 2 )
           ++kount;
         max = ( max < kount ) ? kount: max;
       }
       kount = 0;
       if( indexSuprisesWithMinExp.size() >= 3 && indexSuprisesWithMinExp[2] == 2 ) {
         ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 1 && indexNotSuprisesWithMinExp[0] == 0 )
           ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 2 && indexNotSuprisesWithMinExp[1] == 1 )
           ++kount;
         max = ( max < kount ) ? kount: max;
       }
       return ( ( max >= numOfSurprises ) ? max: 0 );
     }else if( numOfSurprises == 2 ) {
       unsigned kount = 0;
       unsigned max = 0;
       if( indexSuprisesWithMinExp.size() >= 1 && indexSuprisesWithMinExp[0] == 0 ) {
         ++kount;
         if( indexSuprisesWithMinExp.size() >= 2 && indexSuprisesWithMinExp[1] == 1 )
           ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 3 && indexNotSuprisesWithMinExp[2] == 2 )
           ++kount;
         max = ( max < kount ) ? kount: max;
       }
       kount = 0;
       if( indexSuprisesWithMinExp.size() >= 1 && indexSuprisesWithMinExp[0] == 0 ) {
         ++kount;
         if( indexSuprisesWithMinExp.size() >= 3 && indexSuprisesWithMinExp[2] == 2 )
           ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 2 && indexNotSuprisesWithMinExp[1] == 1 )
           ++kount;
         max = ( max < kount ) ? kount: max;
       }
        kount = 0;
        if( indexSuprisesWithMinExp.size() >= 2 && indexSuprisesWithMinExp[1] == 1 ) {
         ++kount;
         if( indexSuprisesWithMinExp.size() >= 3 && indexSuprisesWithMinExp[2] == 2 )
           ++kount;
         if( indexNotSuprisesWithMinExp.size() >= 1 && indexNotSuprisesWithMinExp[0] == 0 )
           ++kount;
         max = ( max < kount ) ? kount: max;
       }
       return ( ( max >= numOfSurprises ) ? max: 0 );
     }else if( numOfSurprises == 3 ) {
        if( numS == 3 ) return 3;
         else return 0;
     }
   }
   return 0;
 }
 
 int main()
 {
   unsigned numOfTestCases( 0 );
   cin >> numOfTestCases;
 
   vector< unsigned > finalResult;
   for( unsigned k = 0; k < numOfTestCases; ++k ) {
     unsigned numOfGooglers( 0 );
     cin >> numOfGooglers;
 
     unsigned numOfSurprises( 0 );
     cin >> numOfSurprises;
 
     unsigned minExpectedScore( 0 );
     cin >> minExpectedScore;
 
     vector< unsigned > vectPoints;
     for( unsigned m = 0; m < numOfGooglers; ++m ) {
       unsigned totalPoints( 0 );
       cin >> totalPoints;
       vectPoints.push_back( totalPoints );
     }
     finalResult.push_back( computeBestResult( vectPoints, numOfSurprises, minExpectedScore ) );
   }//for( numOfTestCases );
 
   for( unsigned k = 0; k < finalResult.size(); ++k )
     cout<<"Case #"<<k + 1<<": "<<finalResult[ k ]<<endl;
   cout<<"\n\n";
   return 0;
 }