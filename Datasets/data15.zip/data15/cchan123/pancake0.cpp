#include <string>
 #include <iostream>
 #include <vector>
 using namespace std;
 int main()
 {
 
 	int n;
 	cin>>n;
 	for(int y=0;y<n;y++)
 	{
 		int k;
 		cin>>k;
 		vector<int> stack=vector<int>();
 		for(int x=0;x<k;x++)
 		{
 			int temp;
 			cin>>temp;
 			stack.push_back(temp);
 		}
 		int min=0;
 		int truemin=9999999;
 		while(true)
 		{
 			bool lolz=true;
 			for(int x=0;x<stack.size();x++)
 			{
 				if(stack[x]!=1)
 				{
 					lolz=false;
 					break;
 				}
 			}
 			
 			int max=-1;
 			int index=0;
 			for(int x=0;x<stack.size();x++)
 			{
 				if(stack[x]>max)
 				{
 					max=stack[x];
 					index=x;
 				}
 			}
 			if(max+min<truemin)
 				truemin=max+min;
 			if(lolz)
 				break;
 			stack.push_back(stack[index]/2);
 			stack[index]=(stack[index]+1)/2;
 			min++;
 		}
 		cout<<"Case #"<<y+1<<": "<<truemin<<endl;
 	}
 	return 0;
 }