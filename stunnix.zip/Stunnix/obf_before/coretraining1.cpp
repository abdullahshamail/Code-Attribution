#include<bits/stdc++.h>
 using namespace std;
 inline void read(int &x){
     register char c=getchar();
     x=0;
     while(c<'0'||c>'9') c=getchar();
     for(;c>='0'&&c<='9';c=getchar())
         x=(x<<1)+(x<<3)+(c-'0');
 }
 inline void reaf(double &z){
     int x,y;
     read(x);read(y);
     z=x+y/10000.0;
 }
 double p[55],q[55],f[55][55];
 int n,k;
 double check(double u,double v){
     int i,j;
     double l,r,m,w;
     for(i=1;i<=n;++i) p[i]=q[i],f[0][i]=0.0;
     l=0.0;r=1.0;
     for(i=0;i<55;++i){
         m=(l+r)/2;
         w=0.0;
         for(j=1;j<k;++j)
             if(p[j]<m)
                 w+=m-p[j];
         if(u<w) r=m; else l=m;
     }
     for(j=1;j<k;++j) if(p[j]<m) p[j]=m;
     l=0.0;r=1.0;
     for(i=0;i<55;++i){
         m=(l+r)/2;
         w=0.0;
         for(j=k;j<=n;++j)
             if(p[j]<m)
                 w+=m-p[j];
         if(v<w) r=m; else l=m;
     }
     for(j=k;j<=n;++j) if(p[j]<m) p[j]=m;
     f[0][0]=1.0;
     for(i=1;i<=n;++i){
         f[i][0]=f[i-1][0]*(1.0-p[i]);
         for(j=1;j<=n;++j)
             f[i][j]=f[i-1][j]*(1.0-p[i])+f[i-1][j-1]*p[i];
     }
     w=0.0;
     for(i=n+1-k;i<=n;++i) w+=f[n][i];
     return w;
 }
 int main(){
     freopen("input.in","r",stdin);
     freopen("output.out","w",stdout);
     cout<<fixed<<setprecision(15);
     int tt,t,i,j;
     double u,l,r,m1,m2;
     read(t);
     for(tt=1;tt<=t;++tt){
         read(n);read(k);k=n+1-k;
         reaf(u);
         for(i=1;i<=n;++i) reaf(q[i]); sort(q+1,q+1+n);
         l=0.0;r=u;
         for(i=0;i<105;++i){
             m1=(l+l+r)/3.0;
             m2=(l+r+r)/3.0;
             if(check(m1,u-m1)>check(m2,u-m2)) r=m2; else l=m1;
         }
         cout<<"Case #"<<tt<<": "<<check(l,u-l)<<"\n";
     }
 }
#include<bits/stdc++.h>
 using namespace std;
 inline void read(int &x){
     register char c=getchar();
     x=0;
     while(c<'0'||c>'9') c=getchar();
     for(;c>='0'&&c<='9';c=getchar())
         x=(x<<1)+(x<<3)+(c-'0');
 }
 inline void reaf(double &z){
     int x,y;
     read(x);read(y);
     z=x+y/10000.0;
 }
 double p[55],q[55],f[55][55];
 int n,k;
 double check(double u,double v){
     int i,j;
     double l,r,m,w;
     for(i=1;i<=n;++i) p[i]=q[i],f[0][i]=0.0;
     l=0.0;r=1.0;
     for(i=0;i<55;++i){
         m=(l+r)/2;
         w=0.0;
         for(j=1;j<k;++j)
             if(p[j]<m)
                 w+=m-p[j];
         if(u<w) r=m; else l=m;
     }
     for(j=1;j<k;++j) if(p[j]<m) p[j]=m;
     l=0.0;r=1.0;
     for(i=0;i<55;++i){
         m=(l+r)/2;
         w=0.0;
         for(j=k;j<=n;++j)
             if(p[j]<m)
                 w+=m-p[j];
         if(v<w) r=m; else l=m;
     }
     for(j=k;j<=n;++j) if(p[j]<m) p[j]=m;
     f[0][0]=1.0;
     for(i=1;i<=n;++i){
         f[i][0]=f[i-1][0]*(1.0-p[i]);
         for(j=1;j<=n;++j)
             f[i][j]=f[i-1][j]*(1.0-p[i])+f[i-1][j-1]*p[i];
     }
     w=0.0;
     for(i=n+1-k;i<=n;++i) w+=f[n][i];
     return w;
 }
 int main(){
     freopen("input.in","r",stdin);
     freopen("output.out","w",stdout);
     cout<<fixed<<setprecision(15);
     int tt,t,i,j;
     double u,l,r,m1,m2;
     read(t);
     for(tt=1;tt<=t;++tt){
         read(n);read(k);k=n+1-k;
         reaf(u);
         for(i=1;i<=n;++i) reaf(q[i]); sort(q+1,q+1+n);
         l=0.0;r=u;
         for(i=0;i<105;++i){
             m1=(l+l+r)/3.0;
             m2=(l+r+r)/3.0;
             if(check(m1,u-m1)>check(m2,u-m2)) r=m2; else l=m1;
         }
         cout<<"Case #"<<tt<<": "<<check(l,u-l)<<"\n";
     }
 }
