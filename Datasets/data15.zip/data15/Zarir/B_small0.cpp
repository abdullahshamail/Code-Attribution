#include<iostream>
 #include<cstdio>
 #include<queue>
 
 using namespace std;
 
 int main(){
 	//freopen("B-small-2.in","r",stdin);
 	int t,c=1,d,p,x,m,s;
 	cin>>t;
 	while(c<=t){
 		s = 0;
 		priority_queue<int> nPie;
 		cin>>d;
 		while(d--){
 			cin>>p;
 			nPie.push(p);
 		}
 		while(nPie.top()>3){
 			x = nPie.top();
 			nPie.pop();
 			m = x%3;
 			if(m==0 || m==2){
 				nPie.push(3);
 				nPie.push(x-3);
 			}else{
 				m = x/2;
 				nPie.push(m);
 				nPie.push(x-m);
 			}
 			s++;
 		}
 		s += nPie.top();
 		cout<<"Case #"<<c++<<": "<<s<<endl;
 	}
 	return 0;
 }
