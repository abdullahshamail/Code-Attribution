#include <iostream>
 #include <string.h>
 #include <queue>
 
 using namespace std;
 
 struct test
 {
 	int x,y;
 };
 queue<test>io;
 int pre[101][101][2];
 int answer[101][101];
 int pro[101][101];
 int ax[4]={-1,1,0,0};
 int ay[4]={0,0,1,-1};
 int h,w;
 
 
 bool check(int x,int y)
 {
 	if(x>=w||y>=h||x<0||y<0)
 		return false;
 	return true;
 }
 
 int main()
 {
 	freopen("f.in","r",stdin);
 	freopen("f.out","w",stdout);
 	int t;
 	int ooo=1;
 	int i,j;
 	scanf("%d",&t);
 	while(t--)
 	{
 		memset(pre,-1,sizeof(pre));
 		memset(answer,-1,sizeof(answer));
 		scanf("%d%d",&h,&w);
 		for(i=0;i<h;i++)
 			for(j=0;j<w;j++)
 			{
 				scanf("%d",&pro[i][j]);
 			}
 		int cnt=0;
 		for(i=0;i<h;i++)
 		{
 			for(j=0;j<w;j++)
 			{
 				test mn,temp,ip;
 				if(answer[i][j]==-1)
 				{
 					mn.x=j;
 					mn.y=i;
 					io.push(mn);
 					while(!io.empty())
 					{
 						temp=io.front();
 						io.pop();
 						int max_x,max_y,max=pro[temp.y][temp.x];
 						bool ui=false;
 						for(int v=0;v<4;++v)
 						{
 							int xx=temp.x+ax[v],yy=temp.y+ay[v];
 							if(check(xx,yy))
 							{
 								if(pro[yy][xx]<max)
 								{
 									ui=true;
 									max_x=xx;max_y=yy;
 									max=pro[yy][xx];
 								}
 							}
 						}
 							if(ui)
 							{
 								pre[max_y][max_x][0]=temp.x;pre[max_y][max_x][1]=temp.y;
 								if(answer[max_y][max_x]!=-1)
 								{
 									while(1)
 									{
 										int ux=max_x,uy=max_y;
 										if(pre[max_y][max_x][0]==-1)
 											break;
 										answer[pre[max_y][max_x][1]][pre[max_y][max_x][0]]=answer[max_y][max_x];
 										max_y=pre[uy][ux][1],max_x=pre[uy][ux][0];
 										
 									}
 								}
 								else
 								{
 									mn.x=max_x;mn.y=max_y;
 									io.push(mn);
 								}
 							}
 							else
 							{
 								answer[temp.y][temp.x]=cnt++;
 								while(1)
 								{
 									int ux=temp.x,uy=temp.y;
 									if(pre[temp.y][temp.x][0]==-1)
 										break;
 									answer[pre[temp.y][temp.x][1]][pre[temp.y][temp.x][0]]=answer[temp.y][temp.x];
 									temp.y=pre[uy][ux][1],temp.x=pre[uy][ux][0];
 									
 								}
 							}
 						
 					}
 				}
 			}
 		}
 		printf("Case #%d:\n",ooo++);
 		for(i=0;i<h;i++)
 		{
 			for(j=0;j<w-1;j++)
 				printf("%c ",answer[i][j]+'a');
 			printf("%c\n",answer[i][w-1]+'a');
 		}
 	}
 }