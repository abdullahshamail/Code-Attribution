#include<bits/stdc++.h>
 using namespace std;
 #define max(a,b) (a>b)?(a):(b)
 int main()
 {
 	long long int i,t,n,a,j,p,r,ans,time;
 	vector <long long int> arr;
 	cin>>t;
 	for(i=1;i<=t;i++)
 	{
 		ans=0;
 		time=0;
 		cin>>n;
 		for(j=0;j<n;j++)
 		{
 			cin>>a;
 			arr.push_back(a);
 		}
 		sort(arr.begin(),arr.end());
 		ans=arr[n-1];
 		if(n==1)
 		{
 			j=n-1;
 			p=arr[j]/2;
 			r=max(p,arr[j]-p);
 			if((r+time+1)<ans)
 			{
 				ans=r+time+1;
 				time++;
 //				cout<<p<<" "<<arr[j]<<endl;
 				arr.push_back(arr[j]-p);
 				arr[j]=p;
 				sort(arr.begin(),arr.end());
 //				cout<<p<<" "<<arr[j]<<endl;
 				n++;
 			}
 		}
 //		cout<<time<<" "<<ans<<endl;
 		if(n>1)
 		{
 			while(arr[n-1]!=1)
 			{
 				j=n-1;
 				p=arr[j]/2;
 				r=max(p,arr[j]-p);
 //				cout<<arr[j-1]<<"*********"<<endl;
 				if(((max(arr[j-1],r))+time+1)<=ans)
 				{
 //					cout<<"$$$$$$$$$$"<<time<<endl;
 //					cout<<"########"<<(max(arr[j-1],r))<<"########"<<((max(arr[j-1],r))+time+1)<<endl;
 					ans=((max(arr[j-1],r))+time+1);
 				}
 				time+=1;
 				arr.push_back(arr[j]-p);
 				arr[j]=p;
 				n++;
 				sort(arr.begin(),arr.end());
 			}
 		}
 		cout<<"Case #"<<i<<": "<<ans<<endl;
 		arr.clear();
 	}
 }
