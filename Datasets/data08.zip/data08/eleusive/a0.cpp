#include <vector>
 #include <list>
 #include <map>
 #include <set>
 #include <queue>
 #include <stack>
 #include <bitset>
 #include <algorithm>
 #include <functional>
 #include <numeric>
 #include <utility>
 #include <sstream>
 #include <iostream>
 #include <fstream>
 #include <iomanip>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <ctime>
 #include <cctype>
 using namespace std;
 
 #define llong long long
 
 int n;
 
 vector<int> need[1001];
 bool type[1001];
 int bads[1001];
 
 int ret;
 
 int solve(int node) {
 	ret=max(ret,bads[node]+1);
 	//cout<<node<<' '<<1+bads[node]<<"***"<<endl;
 	for(int i=0;i<need[node].size();i++) solve(need[node][i]);
 }
 
 int main() {
 	int cases;
 	cin>>cases;
 	string s,ss;
 	for(int tc=1;tc<=cases;tc++) {
 		for(int i=0;i<1001;i++) need[i].clear();
 		memset(type,0,sizeof(type));
 		memset(bads,0,sizeof(bads));
 		map<string,int> mm;
 		cout<<"Case #"<<tc<<": ";
 		cin>>n;
 		int m;
 		int idx=0;
 		for(int i=0;i<n;i++) {
 			cin>>ss;
 			if(!mm.count(ss)) {
 				type[idx]=1;
 				mm[ss]=idx;
 				idx++;
 			}
 			cin>>m;
 			for(int j=0;j<m;j++) {
 				cin>>s;
 				if(!mm.count(s)) {
 					mm[s]=idx;
 					idx++;
 				}
 				if(islower(s[0])) continue;
 				bads[mm[ss]]++;
 				need[mm[ss]].push_back(mm[s]);
 			}
 		}
 		ret=1;
 		solve(0);
 		cout<<ret<<endl;
 	}
 }
