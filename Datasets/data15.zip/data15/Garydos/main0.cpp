#include <iostream>
 #include <cmath>
 
 using namespace std;
 
 int getMaxValueIndex(int *a, int length) {
     int maxValue = 0, maxValueIndex = 0;
     for (int i = 0; i < length; i++) {
         if (a[i] > maxValue) {
             maxValue = a[i];
             maxValueIndex = i;
         }
     }
 
     return maxValueIndex;
 }
 
 int getMaxValue(int *a, int length) {
     return a[getMaxValueIndex(a, length)];
 }
 
 int getMinutes(int *diners, int length, int specialMinutes) {
     int maxValue = getMaxValue(diners, length);
     if (maxValue  <= 3) {
             return maxValue + specialMinutes;
     }
 
     int halfOne = maxValue / 2;
     int halfTwo = maxValue / 2 + maxValue % 2;
 
     int *temp = new int[length + 1];
     int maxValIndex = getMaxValueIndex(diners, length);
 
     int j = 0;
     for (int i = 0; i < length + 1; i++) {
         if (i == maxValIndex) {
             temp[i] = halfOne;
             i++;
             temp[i] = halfTwo;
         }
         else {
             temp[i] = diners[j];
         }
         j++;
     }
 
     int tempMinutes = getMinutes(temp, length + 1, specialMinutes + 1);
     delete temp;
 
     return (int)fmin((float)tempMinutes, maxValue + specialMinutes);
 }
 
 int getMinutes(int *diners, int length) {
     return getMinutes(diners, length, 0);
 }
 
 int main()
 {
     int T;
     cin >> T;
 
     for (int k = 1; k <= T; k++) {
         int D;
         cin >> D;
         int diners[D];
         for (int i = 0; i < D; i++)
             cin >> diners[i];
         cout << "Case #" << k << ": " << getMinutes(diners, D) << endl;
     }
 }
