#include <iostream>
 using namespace std;
 
 struct node{
 	int a;
 	int b;
 } wire[1002];
 
 int n;
 
 int func()
 {
 	int num;
 
 	if (n == 1)
 	{
 		return 0;
 	}
 	num = 0;
 	if(n == 2){
 		if ((wire[0].a - wire[1].a) * (wire[0].b - wire[1].b) < 0)
 		{
 			num = 1;
 		}
 	}
 	return num;
 }
 
 int main()
 {
 	//freopen("A-small-attempt0.in", "r", stdin);
 	//freopen("out.txt", "w", stdout);
 	int t;
 	int i, j, result;
 	cin>>t;
 	for(j = 1; j <= t; j++)
 	{
 		cin>>n;
 		for (i = 0; i < n; i++)
 		{
 			cin>>wire[i].a>>wire[i].b;
 		}
 		
 		result = func();
 		cout<<"Case #"<<j<<": "<<result<<endl;
 	}
 	return 0;
 }