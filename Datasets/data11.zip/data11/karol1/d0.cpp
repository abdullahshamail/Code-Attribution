#include <string>
 #include <string.h>
 #include <iostream>
 #include <sstream>
 #include <vector>
 #include <cmath>
 #include <cctype>
 #include <cstdio>
 #include <algorithm>
 #include <queue>
 #include <map>
 #include <set>
 #include <cassert>
 using namespace std;
 
 /*PREWRITTEN CODE BEGINS HERE*/
 
 #define FOR(i,a,b) for(int i=(a),_b=(b); i<=_b; ++i)
 #define RESET(a,c) memset(a,(c),sizeof(a))
 
 
 /*PREWRITTEN CODE ENDS HERE*/
 inline int RI() { int xx; scanf("%d",&xx); return xx; }
 typedef long double LD;
 const int INF = 1010000000;
 const double EPS = 1e-9;
 /*SOLUTION BEGINS HERE*/
 
 int t[2000], vis[2000];
 
 void solve()
 {
 	int N;
 	scanf("%d", &N);
 	FOR(i,1,N) scanf("%d", &t[i]);
 	RESET(vis, 0);
 	
 	int ret = 0;
 	FOR(i,1, N) if(!vis[i]) {
 		int j = i, cykl_len = 0;
 		while(!vis[j]) {
 			vis[j] = true;
 			j = t[j];
 			cykl_len++;
 		}
 		ret += 2*(cykl_len - 1);
 	}
 	printf("%d.000000\n", ret);
 }
 
 int main(void)
 {
 	int T = RI();
 	FOR(i,1,T) {
 		printf("Case #%d: ", i);
         solve();
 	}
 	return (0);
 }
