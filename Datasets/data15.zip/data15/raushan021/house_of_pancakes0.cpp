#include<bits/stdc++.h>
 
 using namespace std;
 typedef long long big;
 
 int main(){
     int test;
     scanf("%d",&test);
     for(int t=1;t<=test;t++){
         int D;
         scanf("%d",&D);
         //int inp_arr[D];
         int maxm=0;
         for(int i=0;i<D;i++){
             int temp;
             scanf("%d",&temp);
             maxm=max(maxm,temp);
             //inp_arr[i]=temp;
         }
         int dp[1005]={};
         dp[1]=1;
         for(int i=2;i<=maxm;i++){
             if(i%2==0){
                 int index = i/2;
                 dp[i]=dp[index]+1;
             }
             else{
                 int index = (i/2)+1;
                 dp[i]=dp[index]+1;
             }
         }
         printf("Case #%d: %d\n",t,dp[maxm]);
     }
     return 0;
 }
