#include <cstdio>
 #include <cstdlib>
 #include <cmath>
 #include <string>
 #include <vector>
 #include <iostream>
 #include <map>
 #include <set>
 #include <algorithm>
 #include <queue>
 #include <sstream>
 using namespace std;
 typedef long long ll;
 typedef pair<int,int> pii;
 #define SZ(x) (int)(x.size())
 #define F0(i,n) for(i=0;i<n;i++)
 #define F1(i,n) for(i=1;i<=n;i++)
 const int inf = 1000000009;
 const double pi = atan(1.0)*4.0;
 const double eps = 1e-8;
 
 typedef vector<int> vi;
 typedef vector<ll> vll;
 typedef vector<string> vs;
 typedef vector<double> vd;
 
 #define _CRT_SECURE_NO_WARNINGS
 #define For(i,a,b) for (int i(a),_b(b); i <= _b; ++i)
 #define Ford(i,a,b) for (int i(a),_b(b); i >= _b; --i)
 #define Rep(i,n) for (int i(0),_n(n); i < _n; ++i)
 #define Repd(i,n) for (int i((n)-1); i >= 0; --i)
 #define Fill(a,c) memset(&a, c, sizeof(a))
 #define MP(x, y) make_pair((x), (y))
 #define All(v) (v).begin(), (v).end()
 
 template<typename T, typename S> T cast(S s) {
 	stringstream ss;
 	ss << s;
 	T res;
 	ss >> res;
 	return res;
 }
 
 template<typename T> inline T sqr(T a) { return a*a; }
 template<typename T> inline int Size(const T& c) { return (int)c.size(); }
 template<typename T> inline void checkMin(T& a, T b) { if (b < a) a = b; }
 template<typename T> inline void checkMax(T& a, T b) { if (b > a) a = b; }
 
 ll gcd(ll x, ll y) { return y ? gcd(y, x%y) : x; }
 
 int v[3][3];
 double check(int i,int j)
 {
 	double x=abs(v[i][0]-v[j][0]);
 	double y=abs(v[i][1]-v[j][1]);
 	double d=sqr(x*x+y*y);
 	return d+v[i][2]+v[j][2];
 }
 void solve(int test)
 {
 	int N;
 	cin>>N;
 	For(i,1,N)
 	{
 		cin>>v[i][0];
 		cin>>v[i][1];
 		cin>>v[i][2];
 	}
 	if(N==1){
 		double ans=(double)v[0][2];
 	fprintf(stderr,"test=%d\n",test);
 	cout<<"Case #"<<test<<": ";
 	printf("%.7f\n",ans);
 	}
 		if(N==2){
 		double ans=(double)v[0][2];
 		checkMax(ans,(double)v[1][2]);
 	fprintf(stderr,"test=%d\n",test);
 	cout<<"Case #"<<test<<": ";
 	printf("%.7f\n",ans);
 	}
 	if(N==3){
 		double ans=100000.0;
 		For(i,0,2)
 		{
 			int j,k;
 			if(i==0) j=1,k=2; 
 						if(i==2) j=1,k=0; 
 									if(i==1) j=0,k=2; 
 			double tem=check(j,k);
 			checkMax(tem,(double)v[i][2]);
 			checkMin(ans,tem);
 		}
 
 	fprintf(stderr,"test=%d\n",test);
 	cout<<"Case #"<<test<<": ";
 	printf("%.7f\n",ans);
 	}
 }
 
 
 int main() {
 	freopen("a.in", "rt", stdin);
 	freopen("output.txt", "wt", stdout);
 	int N;
 	cin>>N;
 	For(test,1,N)
 	{
 		solve(test);	
 	}
 }