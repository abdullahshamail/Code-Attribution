#include <iostream>
 #include <fstream>
 #include <vector>
 #include <limits>
 #include <iterator>
 
 unsigned int minT;
 void maxLoc(const std::vector<unsigned int>& v, unsigned int& m, unsigned int& loc){
   m = 0;
   loc = 0;
 
   for(unsigned int i=0; i<v.size(); i++)
     if( v[i] > m ){
       m = v[i];
       loc = i;
     }
 }
 
 void doMinute( bool doEat, unsigned int Pt, unsigned int t, std::vector< unsigned int > Ds ){
   if( Pt == 0){
     if( t < minT ) minT = t;
     return;
   }
   
   std::vector< unsigned int > DsCpy;
   unsigned int s = Ds.size();
 
   if(doEat){
     Pt = Pt - s;
     /// Clean dinners with 0 pancakes
     for(unsigned int i = 0; i<s; i++)
       if( Ds[i] > 1)
         DsCpy.push_back(Ds[i] - 1);
   } else { // Share
     DsCpy = Ds;
     unsigned int m, loc;
     maxLoc(DsCpy, m , loc);
     if( m/2  > 0 ){
       DsCpy[loc] = DsCpy[loc] - m/2 ;
       DsCpy.push_back(  m/2  );
     } else {
       if( t < minT ) minT = t;
       return;
     }
   }
 
   doMinute(doEat, Pt, t + 1, DsCpy);
   doMinute(!doEat, Pt, t + 1, DsCpy);
 }
 
 
 int main(int argv, char **argc){
 
   unsigned int T;
   unsigned int nD;
   unsigned int t;
   unsigned int Pt;
   std::vector< unsigned int> D;
 
   std::ifstream inputFile("/home/angel/Descargas/B-small-attempt1.in");
   std::ofstream outputFile("output.txt");
 
   inputFile >> T;
 
   bool eat = true;
 
   for(unsigned int i=0; i<T; i++){
     /// Get input
     inputFile >> nD;
 
     Pt = 0;
     D = std::vector< unsigned int>(nD);
     minT = std::numeric_limits<unsigned int>::max();
 
     for(unsigned int d =0; d < nD; d++){
       inputFile >> D[d];
       Pt+= D[d];
     }
 
     t = 1;
 	doMinute(eat, Pt, t, D);
     doMinute(!eat, Pt, t, D);
 
     outputFile << "Case #" 
               << i+1
               << ": "
               << minT 
               << std::endl;
   }
 
   return 0;
 }
 
