#include<iostream>
 #include<string>
 #include<math.h>
 #include<vector>
 #include<queue>
 #include<algorithm>
 #include<cstdio>
 #include<cstdlib>
 #include<string.h>
 #include<map>
 
 using namespace std;
 
 int main()
 {
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
 
 	int t;
 	cin >> t;
 	for (int ii = 1; ii <= t; ii++)
 	{
 		int x, r, c;
 		cin >> x >> r >> c;
 		if (x == 1)
 			cout << "Case #" << ii << ": " << "GABRIEL" << endl;
 		else if (x == 2)
 		{
 			if ((r*c) % 2 ==0 )
 				cout << "Case #" << ii << ": " << "GABRIEL" << endl;
 			else
 				cout << "Case #" << ii << ": " << "RICHARD" << endl;
 		}
 		else if (x == 3)
 		{
 			if (((r*c) % 2 == 0 && r % 2 == 0 && c % 2 != 0) || ((r*c) % 2 == 0 && r % 2 != 0 && c % 2 ==0))
 			{
 				cout << "Case #" << ii << ": " << "GABRIEL" << endl;
 			}
 			else
 				cout << "Case #" << ii << ": " << "RICHARD" << endl;
 		}
 		else 
 			cout << "Case #" << ii << ": " << "RICHARD" << endl;
 
 		
 	}
 	return 0;
 }
 
