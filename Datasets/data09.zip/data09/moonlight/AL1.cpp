#include<iostream>
 #include<queue>
 using namespace std;
 typedef struct node{
 	int s;
 	int step;
 	node(){}
 	node(int ss,int sp):s(ss),step(sp){}
 }node;
 
 
 char c[50][50];
 
 char flag[100000000];
 
 int l[50];
 
 int main()
 {
 	freopen("1.txt","r",stdin);
 	freopen("2.txt","w",stdout);
 	int ca,cas;
 	scanf("%d",&cas);
 	for(ca=1;ca<=cas;ca++)
 	{
 		int i,j;
 		int n;
 		scanf("%d",&n);
 		int s=0;
 		for(i=0;i<n;i++)
 		{
 			scanf("%s",c[i]);
 			for(j=n-1;j&&c[i][j]=='0';j--);
 			l[i+1] = j+1;
 			s = s*10 + j+1;
 		}
 		int num = 0;
 		for(i=1;i<=n;i++)
 		{
 			if(l[i]>i)
 				for(j=i+1;;j++)
 					if(l[j]<=i)
 						break;
 			for(j--;j>=i;j--)
 			{
 				swap(l[j],l[j+1]);
 				num++;
 			}
 		}
 		printf("Case #%d: %d\n",ca,num);
 	}
 }