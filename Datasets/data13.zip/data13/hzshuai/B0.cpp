#include <cstdio>
 
 int main()
 {
     int t, n, x, y, cas = 1;
     int m;
     freopen("B-small-attempt6.in", "r", stdin);
     freopen("B-small-attempt0.out", "w", stdout);
     scanf("%d", &t);
     while ( t -- )
     {
         scanf("%d %d %d", &n, &x, &y);
         if ( x <= 0 )
             m = y - x;
         else m = x + y;
         for (int  i = 0; i < m; i += 2)
             n = n - (( i + 1) * 2 - 1);
         double ans = 0.0;
         //printf("m = %d, n = %d\n", m, n);
         if ( n >= ( m + 1) * 2 - 1)
             ans = 1.0;
         else if ( n >= (y+1) )
         {
             if ( x == 0 )
             {
                 if ( n == ( m + 1) * 2 - 1 )
                     ans = 1.0;
                 else ans = 0.0;
             }
             else {
                // printf("!!\n");
                 double tmp = 1.0;
                 double up = 0.0, down = 0.0;
                 int k = y + 1;
                 int begin = n - m > 0 ? n - m : 0;
                 for ( int i = 1; i <= begin; i ++)
                     tmp = tmp * (n - i + 1) / (i * 2);
                 for ( int i = begin + 1; i <= n; i ++)
                     tmp = tmp / 2;
                 down = tmp;
                 if ( begin >= ( y + 1 ))
                     up = tmp;
                 for ( int i = begin + 1; i <= (m <= n ? m : n); i ++ )
                 {
                     tmp = tmp * (n - i + 1) / i;
                     down += tmp;
                     if ( i >= y + 1 )
                         up += tmp;
                 }
                 ans = up / down;
             }
         }
         printf("Case #%d: %.6lf\n", cas ++, ans );
     }
     return 0;
 }
 /*
 10
 1 0 0
 1 0 2
 3 0 0
 3 2 0
 3 1 1
 4 1 1
 4 0 2
 5 0 2
 6 0 2
 7 0 2
 */
