#include<cstdio>
 const int H = 100, W = 100;
 const int Silk = 0, North = -1, West = -2, East = +2, South = 1;
 
 int tabAlt[H][W], h, w;
 int tabWhere[H][W];
 char labels[H][W];
 char label;
 
 int makeSet(int y, int x){
     int alt = tabAlt[y][x];
     int min = alt, result;
     if(y){
         min = tabAlt[y - 1][x];
         result = North;
     }
     if(x && tabAlt[y][x - 1] < min){
         result = West;
         min = tabAlt[y][x - 1];
     }
     if(y + 1 < h && tabAlt[y + 1][x] < min){
         result = South;
         min = tabAlt[y + 1][x];
     }
     if(x + 1 < w && tabAlt[y][x + 1] < min){
         result = East;
         min = tabAlt[y][x + 1];
     }
     if(alt > min){
         return result;
     }
 
     return Silk;
 }
 
 char Find(int y, int x){
     int direct = tabWhere[y][x];
     if(direct == Silk)return labels[y][x];
     if(direct == North || direct == South)y += direct;
     else x += direct/2;
     char result = Find(y, x);
     return result;
 }
 
 int main(){
     int T;
     scanf("%d", &T);
     for(int t = 1; t <= T; ++t){
         label = 'a';
         printf("Case #%d:\n", t);
         scanf("%d %d", &h, &w);
         for(int y = 0; y < h; ++y){
             for(int x = 0; x < w; ++x){
                 scanf("%d", &tabAlt[y][x]);
             }
         }
         for(int y = 0; y < h; ++y){
             for(int x = 0; x < w; ++x){
                 tabWhere[y][x] = makeSet(y, x);
             }
         }
         for(int x = 0; x < w; ++x)
             for(int y = 0; y< h; ++y)
                 if(tabWhere[y][x]==Silk)labels[y][x] = label++;
         for(int y = 0; y < h; ++y){
             for(int x = 0; x < w; ++x){
                 labels[y][x] = Find(y, x);
             }
         }
         for(int y = 0; y < h; ++y){
             for(int x = 0; x < w; ++x){
                 printf("%c ", labels[y][x]);
             }
             printf("\b\n");
         }
     }
     return 0;
 }
