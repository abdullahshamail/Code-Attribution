#include <iostream>
 #include <cstdio>
 
 using namespace std;
 
 int main(){
 	//freopen("D-small-attempt2.in","r",stdin);
 	int n=1,t;
 	cin>>t;
 	while(n<=t){
 		int x,r,c,e,w;
 		cin>>x>>r>>c;
 		if(x==1){
 			if(r*c==1) w = 0;
 			else w = 1;
 		}else if(x==2){
 			if(r*c==2 || (r*c)%2==1) w = 0;
 			else w = 1;
 		}else if(x==3){
 			if((r<2 || c<2) || ((r*c)%3!=0)) w = 0;
 			else w = 1;
 		}else if(x==4){
 			if(r==4 && c==4) w = 1;
 			else w = 0;
 		}
 		if(w){
 			cout<<"Case #"<<n++<<": GABRIEL"<<endl;
 		}else{
 			cout<<"Case #"<<n++<<": RICHARD"<<endl;
 		}
 	}
 	return 0;
 }
