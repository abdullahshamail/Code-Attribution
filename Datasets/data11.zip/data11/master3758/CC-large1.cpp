#include <vector>
 #include <list>
 #include <map>
 #include <set>
 #include <deque>
 #include <queue>
 #include <bitset>
 #include <algorithm>
 #include <functional>
 #include <numeric>
 #include <utility>
 #include <complex>
 #include <sstream>
 #include <iostream>
 #include <iomanip>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <cstring>
 #include <ctime>
 #include <cassert>
 #include <string>
 #define REP(i,n) for(int i=0;i<n;i++)
 #define For(i,a,b) for(int i=a;i<=b;i++)
 #define tr(i,x) for(typeof(x.begin()) i=x.begin();i!=x.end();i++)
 #define all(x) x.begin(),x.end()
 #define pb push_back
 using namespace std;
 const int inf=~0U>>1;
 typedef vector<int> vi;
 typedef vector<vi> vvi;
 typedef pair<int,int> ii;
 typedef long long LL;
 template<class T> bool get_max(T&a,T&b){return b>a?a=b,1:0;}
 template<class T> bool get_min(T&a,T&b){return b<a?a=b,1:0;}
 
 LL a[10005];
 int n;
 
 LL gcd(LL a,LL b){
     if(b==0) return a;
     else return gcd(b,a%b);
 }
 
 LL lcm(LL a,LL b){
     return a/gcd(a,b)*b;
 }
 
 bool check(LL num){
     bool flag=true;
     for(int i=0;i<n;i++){
         if(a[i]!=0&&num%a[i]==0) continue;
         if(a[i]%num==0) continue;
         flag=false;
         break;
     }
     if(flag) return true;
     else return false;
 }
 
 int main()
 {
     freopen("C-large.in","r",stdin);
     freopen("C-large.out","w",stdout);
     int T;
     cin>>T;
     int tt=1;
     LL l,h;
     while(T--){
         cin>>n>>l>>h;
         for(int i=0;i<n;i++){
             cin>>a[i];
         }
         printf("Case #%d: ",tt++);
         sort(a,a+n);
         LL ans=a[0];
         bool ok = check(ans);
         if(ok){
             if(ans>=l&&ans<=h) {
                 cout<<ans<<endl;
                 continue;
             }
         }else{
             if(n==1){
                 printf("NO\n");
                 continue;
             }
         }
         ok=false;
         for(int i=0;i<n;i++){
             LL t=a[i];
             for(int j=i-1;j>=0;j--){
                 t=lcm(t,a[j]);
             }
             if(check(t)){
                 if(t>=l&&t<=h){
                     cout<<t<<endl;
                     ok=true;
                     break;
                 }
             }
         }
         if(!ok){
             printf("NO\n");
         }
     }
     return 0;
 }
 
