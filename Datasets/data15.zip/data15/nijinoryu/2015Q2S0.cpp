#include<stdio.h>
 
 using namespace std;
 
 int main(){
 	int T, D, P[2004], i, j, k, Max, res[2004], ans, point, division;
 
 //	printf("START:INPUT NUMBER OF TEST CASES\n");
 	scanf("%d", &T);
 
 	for(i=0;i<T;i++){
 //		printf("INPUT NUMBER OF DINERS IN CASE %d\n", i+1);
 		scanf("%d", &D);
 
 		for(j=0;j<2004;j++){
 			P[j] = 0;
 			res[j] = 1001;
 		}
 //		printf("INPUT NUMBER OF PANCAKES ON EACH\n");
 		for(j=0;j<D;j++){
 			scanf("%d", &P[j]);
 		}
 
 //		printf("EXCECUTING PROGRAM\n");
 		division = 0;
 		Max = 0;
 		while(Max!=1 && division < 1000){
 			Max = 0;
 			for(k=0;k<D+division+1;k++){
 				if(Max<P[k]){
 					point = k;
 					Max = P[k];
 				}
 			}
 
 			res[division] = Max + division;
 //			printf("DIVISION %d: res = %d, Max = %d\n", division, res[division], Max);
 
 			j++;
 			if(Max%2==1){
 				P[j] = P[point]/2+1;
 				P[point] = P[point]/2;
 			}
 			else{
 				P[j] = P[point]/2;
 				P[point] = P[point]/2;
 			}
 			division++;
 		}
 
 		res[division] = division + Max;
 
 		ans = 1001;
 		for(j=0;j<division+1;j++){
 //			printf("res[%d] = %d\n", j, res[j]);
 			if(ans > res[j]){
 				ans = res[j];
 			}
 		}
 
 		printf("Case #%d: %d\n", i+1, ans);
 	}
 
 	return 0;
 }