#include<stdio.h>
 #include<queue>
 
 using namespace std;
 
 int min(int a,int b) {
     if(a<b)
         return a;
     return b;
 }
 
 int main() {
     FILE* fin = fopen("B-small-attempt2.in","r");
     FILE* fout = fopen("out.txt","w");
     int c=1,t;
     fscanf(fin,"%d",&t);
     priority_queue<int> pq;
     while(c<=t) {
         int ans=0;
         int n;
         fscanf(fin,"%d",&n);
         pq = priority_queue<int>();
         for(int i=0;i<n;i++) {
             int x;
             fscanf(fin,"%d",&x);
             pq.push(x);
         }
         int mx=pq.top();
         while(true) {
             int tp = pq.top();
             pq.pop();
             if(tp<=3) {
                 ans+=tp;
                 break;
             }
             pq.push(tp/2);
             pq.push(tp-tp/2);
             ans++;
         }
         fprintf(fout,"Case #%d: %d\n",c,min(ans,mx));
         c++;
     }
     fclose(fin);
     fclose(fout);
     return 0;
 }
